# DevSecOps Toolboxes: Web, CLI e Desktop

Este repositório contém imagens Docker e pipelines Jenkins de referência para segurança no SDLC.

## Imagens

- `devsecops/web-toolbox:local`: Web/API, incluindo ZAP, Nuclei, Schemathesis, Semgrep, Gitleaks, Trivy, Syft, Grype e OSV-Scanner.
- `devsecops/cli-toolbox:local`: CLI, incluindo Semgrep, Gitleaks, Trivy, Syft, Grype, OSV-Scanner, Bandit, pip-audit, gosec e ShellCheck.
- `devsecops/desktop-toolbox:local`: Desktop/native, incluindo Semgrep, Gitleaks, Trivy, Syft, Grype, OSV-Scanner, Cppcheck, clang-tidy, Flawfinder, ClamAV e BinSkim quando disponível.

## Build local

```bash
docker compose build
```

## Execução local

Web/API:

```bash
cp .env.example .env
TARGET_URL="https://homologacao.exemplo.com" OPENAPI_FILE="openapi.yaml" docker compose run --rm web-scan
```

CLI:

```bash
docker compose run --rm cli-scan
```

Desktop:

```bash
DIST_DIR="dist" docker compose run --rm desktop-scan
```

## Configuração recomendada

- Defina `SEMGREP_CONFIG=config/semgrep-minimal.yml` se quiser evitar depender do registry externo do Semgrep.
- Defina `TARGET_URL` somente para ambientes autorizados.
- Use `ZAP_MODE=baseline` no CI padrão e `ZAP_MODE=full` em janela controlada/noturna.
- Use `ENFORCE_SECURITY_GATE=false` durante adoção inicial para gerar relatório sem quebrar builds.
- Use `ENFORCE_SECURITY_GATE=true` quando o time já tiver tratado o backlog inicial de vulnerabilidades.
- Para Trivy, mantenha cache persistente para reduzir downloads de base de vulnerabilidades.

## Observações

- ZAP full scan é ativo e pode alterar estado da aplicação. Use apenas em ambiente autorizado e isolado.
- Nuclei e sqlmap, se adicionados, devem ser usados com escopo explícito.
- Assinatura de binários desktop deve usar chaves protegidas fora da imagem, preferencialmente Vault/HSM/secret manager.
