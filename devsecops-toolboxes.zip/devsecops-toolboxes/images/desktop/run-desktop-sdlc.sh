#!/usr/bin/env bash
set -uo pipefail

WORKDIR="${WORKDIR:-/work}"
REPORT_DIR="${REPORT_DIR:-/reports}"
SEMGREP_CONFIG="${SEMGREP_CONFIG:-auto}"
TRIVY_SEVERITY="${TRIVY_SEVERITY:-HIGH,CRITICAL}"
TRIVY_SCANNERS="${TRIVY_SCANNERS:-vuln,secret,misconfig}"
GRYPE_FAIL_ON="${GRYPE_FAIL_ON:-high}"
DIST_DIR="${DIST_DIR:-dist}"
CLAMAV_UPDATE_DB="${CLAMAV_UPDATE_DB:-false}"
ENFORCE_SECURITY_GATE="${ENFORCE_SECURITY_GATE:-true}"

mkdir -p "$REPORT_DIR"
cd "$WORKDIR"

failures=0
run_step() {
  local name="$1"; shift
  echo ""
  echo "==================== ${name} ===================="
  bash -lc "$*"
  local rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "[WARN] ${name} returned exit code ${rc}"
    failures=$((failures+1))
  fi
}

has_files() {
  find . -type f \( $1 \) -not -path './.git/*' -print -quit | grep -q .
}

run_step "gitleaks secret scan" \
  "gitleaks detect --source . --no-banner --redact --report-format sarif --report-path '${REPORT_DIR}/gitleaks.sarif'"

run_step "semgrep sast" \
  "semgrep scan --config '${SEMGREP_CONFIG}' --json --output '${REPORT_DIR}/semgrep.json' ."

run_step "trivy filesystem scan" \
  "trivy fs --scanners '${TRIVY_SCANNERS}' --severity '${TRIVY_SEVERITY}' --format json --output '${REPORT_DIR}/trivy-fs.json' ."

run_step "syft sbom" \
  "syft dir:. -o cyclonedx-json > '${REPORT_DIR}/sbom.cdx.json'"

run_step "grype sbom vulnerability scan" \
  "grype 'sbom:${REPORT_DIR}/sbom.cdx.json' --fail-on '${GRYPE_FAIL_ON}' -o json > '${REPORT_DIR}/grype.json'"

run_step "osv-scanner dependency scan" \
  "osv-scanner --recursive . --format json > '${REPORT_DIR}/osv-scanner.json'"

if has_files "-name '*.c' -o -name '*.cc' -o -name '*.cpp' -o -name '*.h' -o -name '*.hpp'"; then
  run_step "cppcheck c/c++" \
    "cppcheck --enable=warning,style,performance,portability,information --inline-suppr --xml --xml-version=2 . 2> '${REPORT_DIR}/cppcheck.xml'"

  run_step "flawfinder c/c++" \
    "flawfinder --dataonly --sarif . > '${REPORT_DIR}/flawfinder.sarif'"
fi

if [[ -f "compile_commands.json" ]]; then
  run_step "clang-tidy c/c++" \
    "find . -type f \( -name '*.c' -o -name '*.cc' -o -name '*.cpp' \) -not -path './.git/*' -print0 | xargs -0 -r clang-tidy -p . > '${REPORT_DIR}/clang-tidy.txt'"
else
  echo "[INFO] compile_commands.json not found; skipping clang-tidy."
fi

if [[ -d "$DIST_DIR" ]]; then
  if command -v binskim >/dev/null 2>&1; then
    run_step "binskim binary analysis" \
      "binskim analyze '${DIST_DIR}/**/*' --recurse --output '${REPORT_DIR}/binskim.sarif' --sarif-output-version Current"
  else
    echo "[INFO] binskim command not available; skipping binary hardening analysis."
  fi

  if [[ "$CLAMAV_UPDATE_DB" == "true" ]]; then
    run_step "clamav database update" "freshclam || true"
  fi

  run_step "clamav artifact scan" \
    "clamscan -r --infected --log='${REPORT_DIR}/clamav.log' '${DIST_DIR}'"
else
  echo "[INFO] DIST_DIR='${DIST_DIR}' not found; skipping binary, installer and malware artifact checks."
fi

if [[ "$ENFORCE_SECURITY_GATE" == "true" && $failures -gt 0 ]]; then
  echo "[FAIL] Security gate failed with ${failures} failing step(s). Reports: ${REPORT_DIR}"
  exit 1
fi

echo "[OK] Desktop DevSecOps scan finished. Reports: ${REPORT_DIR}"
