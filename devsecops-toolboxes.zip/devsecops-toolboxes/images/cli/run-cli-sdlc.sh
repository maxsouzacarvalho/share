#!/usr/bin/env bash
set -uo pipefail

WORKDIR="${WORKDIR:-/work}"
REPORT_DIR="${REPORT_DIR:-/reports}"
SEMGREP_CONFIG="${SEMGREP_CONFIG:-auto}"
TRIVY_SEVERITY="${TRIVY_SEVERITY:-HIGH,CRITICAL}"
TRIVY_SCANNERS="${TRIVY_SCANNERS:-vuln,secret,misconfig}"
GRYPE_FAIL_ON="${GRYPE_FAIL_ON:-high}"
ENFORCE_SECURITY_GATE="${ENFORCE_SECURITY_GATE:-true}"
FUZZ_TARGET="${FUZZ_TARGET:-}"

mkdir -p "$REPORT_DIR"
cd "$WORKDIR"

failures=0
run_step() {
  local name="$1"; shift
  echo ""
  echo "==================== ${name} ===================="
  bash -lc "$*"
  local rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "[WARN] ${name} returned exit code ${rc}"
    failures=$((failures+1))
  fi
}

has_files() {
  find . -type f \( $1 \) -not -path './.git/*' -print -quit | grep -q .
}

run_step "gitleaks secret scan" \
  "gitleaks detect --source . --no-banner --redact --report-format sarif --report-path '${REPORT_DIR}/gitleaks.sarif'"

run_step "semgrep sast" \
  "semgrep scan --config '${SEMGREP_CONFIG}' --json --output '${REPORT_DIR}/semgrep.json' ."

run_step "trivy filesystem scan" \
  "trivy fs --scanners '${TRIVY_SCANNERS}' --severity '${TRIVY_SEVERITY}' --format json --output '${REPORT_DIR}/trivy-fs.json' ."

run_step "syft sbom" \
  "syft dir:. -o cyclonedx-json > '${REPORT_DIR}/sbom.cdx.json'"

run_step "grype sbom vulnerability scan" \
  "grype 'sbom:${REPORT_DIR}/sbom.cdx.json' --fail-on '${GRYPE_FAIL_ON}' -o json > '${REPORT_DIR}/grype.json'"

run_step "osv-scanner dependency scan" \
  "osv-scanner --recursive . --format json > '${REPORT_DIR}/osv-scanner.json'"

if has_files "-name '*.py'"; then
  run_step "bandit python sast" \
    "bandit -r . -f json -o '${REPORT_DIR}/bandit.json' || test \$? -eq 1"
fi

if [[ -f "requirements.txt" || -f "pyproject.toml" ]]; then
  run_step "pip-audit python dependency scan" \
    "pip-audit --progress-spinner off --format json --output '${REPORT_DIR}/pip-audit.json'"
fi

if [[ -f "go.mod" ]]; then
  run_step "gosec go sast" \
    "gosec -fmt=json -out='${REPORT_DIR}/gosec.json' ./..."
fi

if has_files "-name '*.sh' -o -name '*.bash'"; then
  run_step "shellcheck shell scripts" \
    "find . -type f \( -name '*.sh' -o -name '*.bash' \) -not -path './.git/*' -print0 | xargs -0 -r shellcheck -f json > '${REPORT_DIR}/shellcheck.json'"
fi

if [[ -n "$FUZZ_TARGET" ]]; then
  echo "[INFO] FUZZ_TARGET=${FUZZ_TARGET} configured, but generic fuzzing requires a project-specific harness."
  echo "[INFO] Add an AFL++/libFuzzer/honggfuzz harness to the project and call it from Jenkins before this toolbox or extend this image."
fi

if [[ "$ENFORCE_SECURITY_GATE" == "true" && $failures -gt 0 ]]; then
  echo "[FAIL] Security gate failed with ${failures} failing step(s). Reports: ${REPORT_DIR}"
  exit 1
fi

echo "[OK] CLI DevSecOps scan finished. Reports: ${REPORT_DIR}"
