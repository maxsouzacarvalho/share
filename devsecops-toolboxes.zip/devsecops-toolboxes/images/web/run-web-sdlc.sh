#!/usr/bin/env bash
set -uo pipefail

WORKDIR="${WORKDIR:-/work}"
REPORT_DIR="${REPORT_DIR:-/reports}"
SEMGREP_CONFIG="${SEMGREP_CONFIG:-auto}"
TRIVY_SEVERITY="${TRIVY_SEVERITY:-HIGH,CRITICAL}"
TRIVY_SCANNERS="${TRIVY_SCANNERS:-vuln,secret,misconfig}"
GRYPE_FAIL_ON="${GRYPE_FAIL_ON:-high}"
TARGET_URL="${TARGET_URL:-}"
OPENAPI_FILE="${OPENAPI_FILE:-}"
IMAGE_TO_SCAN="${IMAGE_TO_SCAN:-}"
NUCLEI_UPDATE_TEMPLATES="${NUCLEI_UPDATE_TEMPLATES:-false}"
ZAP_MODE="${ZAP_MODE:-baseline}" # baseline | full
ZAP_FAIL_ON_WARN="${ZAP_FAIL_ON_WARN:-false}"
ENFORCE_SECURITY_GATE="${ENFORCE_SECURITY_GATE:-true}"

mkdir -p "$REPORT_DIR"
cd "$WORKDIR"

failures=0
run_step() {
  local name="$1"; shift
  echo ""
  echo "==================== ${name} ===================="
  bash -lc "$*"
  local rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "[WARN] ${name} returned exit code ${rc}"
    failures=$((failures+1))
  fi
}

run_step "gitleaks secret scan" \
  "gitleaks detect --source . --no-banner --redact --report-format sarif --report-path '${REPORT_DIR}/gitleaks.sarif'"

run_step "semgrep sast" \
  "semgrep scan --config '${SEMGREP_CONFIG}' --json --output '${REPORT_DIR}/semgrep.json' ."

run_step "trivy filesystem scan" \
  "trivy fs --scanners '${TRIVY_SCANNERS}' --severity '${TRIVY_SEVERITY}' --format json --output '${REPORT_DIR}/trivy-fs.json' ."

run_step "syft sbom" \
  "syft dir:. -o cyclonedx-json > '${REPORT_DIR}/sbom.cdx.json'"

run_step "grype sbom vulnerability scan" \
  "grype 'sbom:${REPORT_DIR}/sbom.cdx.json' --fail-on '${GRYPE_FAIL_ON}' -o json > '${REPORT_DIR}/grype.json'"

run_step "osv-scanner dependency scan" \
  "osv-scanner --recursive . --format json > '${REPORT_DIR}/osv-scanner.json'"

if [[ -n "$IMAGE_TO_SCAN" ]]; then
  run_step "trivy container image scan: ${IMAGE_TO_SCAN}" \
    "trivy image --severity '${TRIVY_SEVERITY}' --format json --output '${REPORT_DIR}/trivy-image.json' '${IMAGE_TO_SCAN}'"
fi

if [[ -n "$OPENAPI_FILE" && -f "$OPENAPI_FILE" && -n "$TARGET_URL" ]]; then
  run_step "schemathesis api fuzzing" \
    "schemathesis run '${OPENAPI_FILE}' --base-url '${TARGET_URL}' --checks all --max-examples '${SCHEMATHESIS_MAX_EXAMPLES:-50}' --junit-xml '${REPORT_DIR}/schemathesis.xml'"
fi

if [[ -n "$TARGET_URL" ]]; then
  if [[ "$NUCLEI_UPDATE_TEMPLATES" == "true" ]]; then
    run_step "nuclei template update" "nuclei -update-templates"
  fi

  run_step "nuclei web template scan" \
    "nuclei -u '${TARGET_URL}' -jsonl -o '${REPORT_DIR}/nuclei.jsonl' || test \$? -eq 1"

  if [[ "$ZAP_MODE" == "full" ]]; then
    ZAP_CMD="zap-full-scan.py -t '${TARGET_URL}' -r '${REPORT_DIR}/zap-full.html' -J '${REPORT_DIR}/zap-full.json' -x '${REPORT_DIR}/zap-full.xml'"
  else
    ZAP_CMD="zap-baseline.py -t '${TARGET_URL}' -r '${REPORT_DIR}/zap-baseline.html' -J '${REPORT_DIR}/zap-baseline.json' -x '${REPORT_DIR}/zap-baseline.xml'"
  fi

  if [[ "$ZAP_FAIL_ON_WARN" != "true" ]]; then
    ZAP_CMD="${ZAP_CMD} -I"
  fi

  run_step "owasp zap ${ZAP_MODE} scan" "$ZAP_CMD"
else
  echo "[INFO] TARGET_URL not set; skipping Nuclei, ZAP and Schemathesis runtime scans."
fi

if [[ "$ENFORCE_SECURITY_GATE" == "true" && $failures -gt 0 ]]; then
  echo "[FAIL] Security gate failed with ${failures} failing step(s). Reports: ${REPORT_DIR}"
  exit 1
fi

echo "[OK] Web DevSecOps scan finished. Reports: ${REPORT_DIR}"
