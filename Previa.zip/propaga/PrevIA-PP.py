import tkinter as Tk  
from tkinter import *
import easygui
import os
from tkinter import messagebox
import shutil
import sys
from pathlib import Path

# Obtém o caminho do executável ou do script
if getattr(sys, 'frozen', False):
    # Se estiver rodando como executável (empacotado)
    application_path = Path(sys.executable).parent
else:
    # Se estiver rodando como script Python
    application_path = Path(__file__).parent
# Configura a pasta de trabalho para o diretório do executável/script
os.chdir(application_path)


master = Tk() 
master.title('PrevIA-PP 2.9.0')
master.geometry('670x620+50+50')
master.iconbitmap('config\\previa.ico')

global vpath,vpath2,vpath3

InpDados = StringVar(master)
InpInc =  StringVar(master)
InpProp = StringVar(master) 


def sel():
    i=1 

def montar():        

    # ==============================
    # CHECAGEM DE ARQUIVOS DE ENTRADA
    # ==============================

    modo_inc = var1.get()        # 1=auto, 2=manual
    modo_prop = v4.get()         # 1=prever montante
    reserv = var.get()

    # Dados anteriores
    if not os.path.isfile(InpDados.get()):
        messagebox.showinfo("Lembrete:", "Falta indicar os dados de entrada")
        return

    lercsv('varx.txt', vpath)

    # Montante (somente se NÃO prever automaticamente)
    if modo_prop == 0:
        if not os.path.isfile(InpProp.get()):
            messagebox.showinfo("Lembrete:", "Falta indicar os dados para propagar")
            return
        lercsv('Propagar.txt', vpath3)

    # Incrementais manuais
    if modo_inc == 2:
        if not os.path.isfile(InpInc.get()):
            messagebox.showinfo("Lembrete:", "Falta indicar as incrementais")
            return
        lercsv('Inc.txt', vpath2)

    # ==============================
    # ESCREVE incprop.txt
    # ==============================

    with open('incprop.txt', 'w') as f:

        # Incrementais
        if modo_inc == 2:
            f.write('0\n0\n')
        else:
            f.write('1\n')
            f.write(f"{var2.get()}\n")

        # Prever montante
        f.write('1\n' if modo_prop == 1 else '0\n')

        # Previsão incremental
        f.write('1\n' if v5.get() == 1 else '0\n')

        # Previsão montante
        f.write('1\n' if v6.get() == 1 else '0\n')

    # ==============================
    # ESCREVE temp.txt
    # ==============================

    with open('temp.txt', 'w') as f:
        f.write(f"{asc.get()}  {dsc.get()}")

    # ==============================
    # CÓPIA DE TABELAS
    # ==============================

    tabelas = {
        1: ("tabelas\\tabelasqtvusb.txt", "configprop\\configpropusb.txt"),
        2: ("tabelas\\tabelasqtvuit.txt", "configprop\\configpropuit.txt"),
        3: ("tabelas\\tabelasqtvube.txt", "configprop\\configpropube.txt"),
        4: ("tabelas\\tabelasqtvupe.txt", "configprop\\configpropupe.txt"),
    }

    tab, cfg = tabelas.get(reserv, (None, None))

    if not os.path.isfile(tab):
        messagebox.showerror("Erro:", f"Falta arquivo {tab}")
        return

    if not os.path.isfile(cfg):
        messagebox.showerror("Erro:", f"Falta arquivo {cfg}")
        return

    shutil.copyfile(tab, "tabelasqtv.txt")
    shutil.copyfile(cfg, "configprop.txt")

    # ==============================
    # FINALIZA
    # ==============================

    txtRun.delete("1.0", "end")
    txtRun.insert(END, "Arquivos montados.")
    BtnRodar["state"] = "active"

def lercsv(arq,path):
  if path==' ':
        messagebox.showinfo("Lembrete:", "Falta indicar os dados para propagar")
  else:
        arquivo1=open(arq,"w+")
        arquivo2=open(path, "r")
        j = 1
        for l in arquivo2:
            l=l.strip()
            l= l.replace(',','.')
            l=l.replace(';',',')
            l=l.strip(",")
            arquivo1.write(l+'\n')
            j=j+1
  
  arquivo2.close
  arquivo1.close

def incremental():
  global vpath2

  ArqInc.delete(0,END)
  vpath2 = easygui.fileopenbox(default="dados/*.csv")
  vpth = str(vpath2)
  if not os.path.isfile(vpth):
      return
  ArqInc.insert(END,vpath2)

def propagar():
  global vpath3

  ArqProp.delete(0,END)
  vpath3 = easygui.fileopenbox(default="dados/*.csv")
  vpth = str(vpath3)
  if not os.path.isfile(vpth):
      return
  ArqProp.insert(END,vpath3)  

def dados():
  global vpath

  ArqDados.delete(0,END)
  vpath = easygui.fileopenbox(default="dados/*.csv")
  vpth = str(vpath)
  if not os.path.isfile(vpth):
      return  
  ArqDados.insert(END,vpath) 

def selinc():
    global vpath2
    i=var1.get()
    if i==1:        
        IncPer3["state"]='active'
        IncPer2["state"]='active'
        IncPer1["state"]='active'
        BtnArqInc["state"]='disabled'
#        ArqInc["state"]='disabled'
        txtasc["state"]='normal'
        txtdsc["state"]='normal'
        #Usaprev1["state"]='normal'
        ArqInc.delete(0,END)
        vpath2='relat\\inc-auto.csv'
        ArqInc.insert(END,'relat\\inc-auto.csv')

    if i==2:
        BtnArqInc["state"]='normal'
        ArqInc["state"]='normal'
        IncPer3["state"]='disabled'
        IncPer2["state"]='disabled'
        IncPer1["state"]='disabled'
        txtasc["state"]='disabled'
        txtdsc["state"]='disabled'
        #Usaprev1.deselect() 
        #Usaprev1["state"]='disabled'        

def rodar():

    dir = './relat'
    if os.path.isdir(dir):
        a=1
    else:       
        os.mkdir(dir)
  
    dir = './plan'
    if os.path.isdir(dir):
        a=1
    else:       
        os.mkdir(dir)
  
    dir = './auxi'
    if os.path.isdir(dir):
        a=1
    else:       
        os.mkdir(dir)

    dir = './config'
    if os.path.isdir(dir):
        a=1
    else:       
        os.mkdir(dir)

    dir = './configprop'
    if os.path.isdir(dir):
        a=1
    else:       
        os.mkdir(dir)
        
    txtRun.delete("1.0","end")
    p=os.popen("PP.exe")
    for l in p:
        txtRun.insert(END,l)
        txtRun.update_idletasks()
        BtnRelat["state"]="active"
        BtnCsv["state"]="active"
        BtnRodar["state"]="disabled"
    i=var1.get()    
    if i==1:
        BtnAbrePrv["state"]="active"
    i=v4.get()     
    if i==1:
        BtnAbreProp["state"]="active"
def relat():
    nome = 'relat\\propaga.html'
    os.startfile(nome)

def planilha():
    nome = 'plan\\relat_propaga.csv'
    os.startfile(nome) 

def abrirprev():
    ipath='relat\\inc-auto.csv'
    if not os.path.isfile(ipath):
        messagebox.showwarning("Não existe!","Não existem previsões na pasta RELAT.")
        return
    i = v4.get()
    if i==0:
        messagebox.showinfo("Lembrete:", "Se modificar as previsões e quiser usá-las,\n"
                        "rodar novamente escolhendo a opção manual, indicando o arquivo .csv para incrementais.")
    if i==1:
        messagebox.showinfo("Lembrete:", "Se modificar as previsões e quiser usá-las,\n"
                        "rodar novamente escolhendo a opção manual, indicando os arquivos .csv "
                        "para incrementais e para vazões de montante a propagar")                            
    nome = 'relat\\inc-auto.csv'
    os.startfile(nome) 
    

def checkP1():
    global vpath3
    i=v4.get()
    if i == 1:
        BtnArqProp ["state"]="disabled"
#        ArqProp["state"]="disabled"
        vpath3='relat\\propagar-auto.csv'
        ArqProp.delete(0,END) 
        ArqProp.insert(END,'relat\\propagar-auto.csv')
        #Usaprev2["state"]='normal'
        
    else:
        BtnArqProp ["state"]="active"
        ArqProp["state"]="normal"
        #Usaprev2["state"]='disabled'
        #Usaprev2.deselect()   
def helpb():
        nome = 'config\\ajuda.html'
        os.startfile(nome) 
def abrirprop():

    nome = 'relat\\propagar-auto.csv'
    os.startfile(nome)     

texto = Label(master,text="PrevIA-PP", font=("Courier",20,'bold'),relief="ridge",width=40,bg="lightblue")
texto.grid(column=0, row=0, padx=10, pady=0,columnspan = 4)
lblt=Label(master, text="Modelo Híbrido para Previsão de Vazões", font=("Courier",10), width="80",background="#d3d3d3")
lblt.grid(column=0, row=1, padx=10, pady="2",columnspan = 4)

label = Label(master,text="Reservatório:",font=('Courier','10','bold'))
label.grid(row=2,column=0,padx="10",pady="2",columnspan=4,sticky=W)

var = IntVar()
var.set(1)

R1 = Radiobutton(master, text="Sobradinho", variable=var, value=1,command=sel,font=('Courier','10'))
                
R1.grid(row=3,column=0,sticky=W,padx="10",pady="2")                  

R2 = Radiobutton(master, text="Itaparica", variable=var, value=2,
                  command=sel,font=('Courier','10'))
R2.grid(row=3,column=1,sticky=W,padx="10",pady="2")  

R3 = Radiobutton(master, text="Boa Esperança", variable=var, value=3,
                  command=sel,font=('Courier','10'))
R3.grid(row=3,column=2,sticky=W,padx="10",pady="2")
                 

R4 = Radiobutton(master, text="Pedra", variable=var, value=4,
                  command=sel,font=('Courier','10'))
R4.grid(row=3,column=3,sticky=W,padx="10",pady="2")


label = Label(master,text="Dados anteriores:",font=('Courier','10','bold'))
label.grid(row=4,column=0,padx="10",pady="2",columnspan=4,sticky=W)


ArqDados = Entry(master,width=85,textvariable=InpDados)
ArqDados.insert(END,'')
vpath = ''
ArqDados.grid(row=5,column=0,sticky=W,padx="10",pady="2",columnspan=3)
BtnArqDados = Button(master,bg="lightgrey",width=10,text='Buscar',command=dados,font=('Courier','10'))
BtnArqDados.grid(row=5,column=3,sticky=W,padx="10",pady="2")

label = Label(master,text="Para propagar:",font=('Courier','10','bold'))
label.grid(row=6,column=0,padx="10",pady="2",columnspan=4,sticky=W)

v4 = IntVar()
PropP1 = Checkbutton(master, text="Prever montante", variable=v4,font=("Courier",10),state="active",onvalue=1,offvalue=0,command=checkP1)
PropP1.grid(row=6,column=1,padx="10",pady="2",columnspan=4,sticky=W)

v6 = IntVar()
#Usaprev2 = Checkbutton(master, text="Usar previsão 1\npara prever", variable=v6,font=("Courier",10),state="disabled",onvalue=1,offvalue=0)
#Usaprev2.grid(row=6,column=2,padx="10",pady="2",columnspan=4,sticky=W)

ArqProp = Entry(master,width=85,textvariable=InpProp)
ArqProp.grid(row=7,column=0,sticky=W,padx="10",pady="2",columnspan=3)
ArqProp.insert(END,'')
vpath3=''

BtnAbreProp = Button(master,bg="lightgrey",width=10,text='Planilha',command=abrirprop,state='disabled',font=('Courier','10'))
BtnAbreProp.grid(row=6,column=3,sticky=W,padx="10",pady="2")
BtnArqProp = Button(master,bg="lightgrey",width=10,text='Buscar',command=propagar,font=('Courier','10'))
BtnArqProp.grid(row=7,column=3,sticky=W,padx="10",pady="2")

label = Label(master,text="Incrementais:",font=('Courier','10','bold'))
label.grid(row=8,column=0,padx="10",pady="2",columnspan=4,sticky=W)

var1 = IntVar()
var1.set(1)

IncRd1 = Radiobutton(master, text="Manual", variable=var1, value=2,command=selinc,font=('Courier','10'))               
IncRd1.grid(row=9,column=0,sticky=W,padx="10",pady="2")                  

IncRd2 = Radiobutton(master, text="Automática", variable=var1, value=1,command=selinc,font=('Courier','10'))
IncRd2.grid(row=9,column=1,sticky=W,padx="10",pady="2")

v5 = IntVar()
#Usaprev1 = Checkbutton(master, text="Usar previsão 1\npara prever", variable=v5,font=("Courier",10),state="disabled",onvalue=1,offvalue=0)
#Usaprev1.grid(row=9,column=2,padx="10",pady="2",columnspan=4,sticky=W)

BtnAbrePrv = Button(master,bg="lightgrey",width=10,text='Planilha',command=abrirprev,state='disabled',font=('Courier','10'))
BtnAbrePrv.grid(row=9,column=3,sticky=W,padx="10",pady="2")
asc = StringVar()  
dsc = StringVar()

lbl2=Label(master,text="Taxa de Ascensão (%):",state='disabled',font=('Courier','10'))
lbl2.grid(row=11,column=0,sticky=W,padx="10",pady="2",columnspan=4)
txtasc=Entry(master,width=10,textvariable=asc)
txtasc.grid(row=11,column=1,sticky=W,padx="10",pady="2",columnspan=4)

lbl2=Label(master,text="Taxa de Recessão (%):",state='disabled',font=('Courier','10')) 
lbl2.grid(row=11,column=2,sticky=W,padx="10",pady="2",columnspan=4)
txtdsc=Entry(master,width=10,textvariable=dsc)
txtdsc.grid(row=11,column=3,sticky=W,padx="10",pady="2",columnspan=4)

txtasc.insert(END,"10000")  #primeiro insere o texto e depois desabilita
txtdsc.insert(END,"10000")

txtasc["state"]='disabled'
txtdsc["state"]='disabled'

ArqInc = Entry(master,width=85,textvariable=InpInc)
ArqInc.grid(row=10,column=0,sticky=W,padx="10",pady="2",columnspan=4)
BtnArqInc = Button(master,bg="lightgrey",width=10,text='Buscar',command=incremental,font=('Courier','10'))
BtnArqInc.grid(row=10,column=3,sticky=W,padx="10",pady="2")
vpath2='relat\\Inc-auto.csv'


var2 = IntVar()
var2.set(3)
IncPer1 = Radiobutton(master, text="Período Úmido", variable=var2, value=1,font=('Courier','10'),state='disabled')               
IncPer1.grid(row=12,column=2,sticky=W,padx="10",pady="2") 
IncPer2 = Radiobutton(master, text="Período Seco", variable=var2, value=2,font=('Courier','10'),state='disabled')               
IncPer2.grid(row=12,column=1,sticky=W,padx="10",pady="2")
IncPer3 = Radiobutton(master, text="Período Total", variable=var2, value=3,font=('Courier','10'),state='disabled')               
IncPer3.grid(row=12,column=0,sticky=W,padx="10",pady="2")


BtnMontar = Button(master,bg="lightgrey",width=10,text='Montar',command=montar,font=('Courier','10'))
BtnMontar.grid(row=13,column=0,sticky=E,padx="5",pady="0")
BtnRodar = Button(master,bg="lightgrey",width=10,text='Rodar',state='disabled',command=rodar,font=('Courier','10'))
BtnRodar.grid(row=13,column=1,sticky=W,padx="5",pady="0")
BtnRelat = Button(master,bg="lightgrey",width=10,text='Relatório',state='disabled',font=('Courier','10'),command=relat)
BtnRelat.grid(row=14,column=0,sticky=E,padx="5",pady="0")
BtnCsv = Button(master,bg="lightgrey",width=10,text='Planilha',state='disabled',font=('Courier','10'),command=planilha)
BtnCsv.grid(row=14,column=1,sticky=W,padx="5",pady="0")
txtRun=Text(master,font=("Courier",10),height=8,width=35)
txtRun.grid(column=2, row=13, padx=5, pady="3",sticky=W,rowspan=3,columnspan=4)

BtnHelp = Button(master,bg="lightgrey",width=10,text='Ajuda',font=('Courier','10'),command=helpb)
BtnHelp.grid(row=15,column=0,sticky=E,padx="5",pady="0")
BtnFechar = Button(master,bg="lightgrey",width=10,text='Fechar',font=('Courier','10'),command=master.destroy)
BtnFechar.grid(row=15,column=1,sticky=W,padx="5",pady="0")

selinc()

# Create Label and add some text
Lower_left = Label(master,text ='Desenvolvido pelo Centro de Pesquisas de Energia Elétrica - CEPEL',
                        borderwidth = 2,
                        background="#d3d3d3")
 
# using place method we can set the position of label
Lower_left.place(relx = 0.01,
                 rely = 0.99,
                 anchor ='sw')


mainloop() 