      SUBROUTINE loess_smoothing(x, y, n, span, smooth_y)
      Include  'paramprev.dim' 
      INTEGER*2 n
      Dimension x(nmp+nmd), y(nmp),smooth_y(nmp+nmd)
      INTEGER i, j
      REAL dist, weight, sum_weight, sum_weighted_y,span
      
      DO i = 1, n
         sum_weighted_y = 0.0
         sum_weight = 0.0
         DO j = 1, n
            dist = ABS(x(j) - x(i))
            IF (dist .LT. span) THEN
               weight = (1.0 - (dist/span)**3)**3 ! Tri-cube weighting function
               sum_weighted_y = sum_weighted_y + weight * y(j)
               sum_weight = sum_weight + weight
            END IF
         END DO
         smooth_y(i) = sum_weighted_y / sum_weight
      END DO
      END 

