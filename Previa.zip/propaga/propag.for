        PROGRAM PROPAGACHESF
        Include  'propag.dim'   
        Include  'paramprev.dim' 
        INTEGER*2 HORA,MINUTO,SEG,DECSEG,ANO,MES,DIA,IINC,NPREV
        INTEGER*2 NNOM,PRIMPREV,UPI,UPM,INCPREV
        integer ftipo
        character*2 hh,mm,dd,ms,XNOME,acl
        character*4 aa
        character*20 nomeres,nomecoef,nomeconfig,A
        dimension yp(nmp)
        CHARACTER*149 EMPRESA
        character*250 linha

 
         NITER  = 10000
         PRECISAO  = 0.0001
         NPREV = 0
                         
         call le_licenca(empresa,ftipo)
         close(12)
         close(11)
        
        
        CALL GETTIM(HORA,MINUTO,SEG,DECSEG)
        CALL GETDAT(ANO,MES,DIA)
        
        write(hh,'(i2)')hora
        write(mm,'(i2)')minuto
        write(dd,'(i2)')dia
        write(ms,'(i2)')mes
        write(aa,'(i4)')ano
        
        
        OPEN (UNIT=2,FILE='CONFIGPROP.TXT',ERR=2001,STATUS='OLD')
        
        
        OPEN (UNIT=12,FILE='RELAT\PROPAGA.HTML',ERR=2001)
        write(12,*)'<html><head>'
        write(12,*)'<link rel="stylesheet" type="text/css" ',
     *   'href="..\config\classe.css" media="screen" />'

        write(12,*)'<noscript>O navegador nao suporta javascript!
     *    </noscript>'      
        write(12,*)'</head><body>'
        
        write(12,*)'<h1>PrevIA-PP</H1>'
        write(12,*)'<h4>Desenvolvido pelo Centro de Pesquisas de Energia 
     *   El&eacute;trica - CEPEL</H4>'
        write(12,*)'<hr><font size=2>Data: '
        write(12,*)dia,'/',mes,'/',ano, '<br>Hora:'
        write(12,'(2(i2,a1),i2,a4)')hora,':',minuto,':',seg,'<br>'
        write(12,*)'</font><hr>'       
c        write(*,*)
c        write(*,'(///30x,70(''-''),/,60x,''PROPAGA-CHESF'')')
c        write(*,'(30x,''Desenvolvido pelo Centro de Pesquisa de Energia 
C     *Eletrica - CEPEL'',/,30x,70(''-''))') 
c        write(*,*)                                             
            
C LE AS TABELAS VAZAO X TV            
            
         OPEN (UNIT=9,FILE='INCPROP.TXT',ERR=2001,STATUS='OLD')
         READ(9,*)IINC  ! SE FOR 1, VAI TER PREVISAO DE INCREMENTAL
         READ(9,*)IPER   !LE O PERIODO: 1- UMIDO; 2- SECO;3-TOTAL ! SE IINC = 0 NAO VAI PRECISAR, PODE SER QUALQUER
         READ(9,*)PRIMPREV
         READ(9,*)UPI   ! USA PREVISAO PARA PREVER INCREMENTAIS
         READ(9,*)UPM   ! USA PREVISAO PARA PREVER MONTANTE
         CLOSE(9)
            
         OPEN(UNIT=5, FILE='VARX.TXT',ERR=2001,STATUS='OLD')
            
         READ(2,*)
         READ(2,*,err=100)nomeres
         READ(2,*)
         READ(2,*,err=100)NUMTRECHOS
         NMTR = NUMTRECHOS
         
         READ(2,*)          
         DO J = 1, NUMTRECHOS
            READ(2,*,err=100)NFASE(J) 
         END DO
         
         READ(2,*)
         NBOQ=0
         DO J = 1, NUMTRECHOS
            READ(2,*,err=100)TBOQ(J)
            NBOQ=NBOQ+TBOQ(J) 
         END DO
         READ(2,*)
         NFLO=0
            READ(2,*,err=100)NFLO  !numero de postos tipo floresta. Vai somar na jusante, nao eh ligadao a trecho                 
         READ(2,*)                 
         READ(2,*,err=110)(SIGLA(I),(SBOQ(I,K),K=1,TBOQ(I)),         
     *   I=1,NMTR),(SFLO(K),K=1,NFLO),SIGLA(NMTR+1)         
                    
         READ(5,*)
         I=1
         DO            
            READ(5,*,END=20)dia,mes,ano,D,(DADO(J),(DBOQ(J,K,I),
     *      K=1,TBOQ(J)),J=1,NUMTRECHOS),(DFLO(J,I),J=1,NFLO),
     *      QJU(I) 
            
                      
            DO J = 1, NUMTRECHOS
            QBOQ1=0
            SSOMA(J)=' '
               DO K = 1,TBOQ(J)
                   QBOQ1 =QBOQ1+DBOQ(J,K,I)
               END DO 
               QP(J,I)= DADO(J) ! SO EH IMPORTANTE PRA IMPRESSAO            
               Entr(J,0,I)=DADO(J)+QBOQ1
               IF (QBOQ1.GT.0)TTEM(J)=1         
            END DO

            I = I+1
            
         END DO
        
   20    NDADOS=I-1
         
         
        write(12,*)'<script>'
        write(12,*)'function dataFormatada(i){'
        write(12,'(A,I0,A,I0,A,I0,A)') '    var data = new Date(', ano, 
     * ', ', mes-1, ', ', dia, ');'                                        ! no javascript, o m�s come�a com "0". Janeiro = "0", por isso o "-1". 
        write(12,*)'    data.setDate(data.getDate() + i);'
        write(12,*)'    var dia = data.getDate();'
        write(12,*)'    if (dia.toString().length == 1){'
        write(12,*)'        dia = "0"+dia;'
        write(12,*)'    }'
        write(12,*)'    var mes = data.getMonth()+1;'
        write(12,*)'    if (mes.toString().length == 1){'
        write(12,*)'        mes = "0"+mes;'
        write(12,*)'    }'
        write(12,*)'    var ano = data.getFullYear();  '        
        write(12,*)'    return dia+"/"+mes+"/"+ano;'
        write(12,*)'}      '
        write(12,*)'</script>'         
         
         DO J=1,NMTR  
            DO I=1, NFASE(J)
              Entr(J,I,1)= Entr(J,0,1)
            END DO
         END DO            
            
         OPEN(UNIT=4,FILE='TABELASQTV.TXT',ERR=2001,STATUS='OLD') 
            
         READ(4,*)
         READ(4,*)
            
         DO ITR = 1, NMTR           
            READ(4,*)
            READ(4,*)ITRECHO,NDTRECHO
            NDT(ITRECHO)=NDTRECHO                  
            DO INDT = 1, NDTRECHO
               READ(4,*)X1,Y1                
               QxT(ITRECHO,INDT,1)=X1  ! VAZAO EH DADO TIPO 1
               QxT(ITRECHO,INDT,2)=Y1  ! TEMPO EH DADO TIPO 2
            END DO                        
         END DO
         
         CLOSE(4)
                    
         OPEN(UNIT=3,FILE='RELAT\RELAT_PROPAGA.TXT', ERR=2001)     
            
   21    CONTINUE             
         
         WRITE(*,*)'AQUECENDO...'
         
         ! FORA DO DO DOS TRECHOS, IMPRIME O MONTANTE DE PRIMPREV = 1
         IARQ = 0  
         IF(PRIMPREV.EQ.1)THEN
                 IARQ = IARQ+1
                 NNOM = 50+IARQ
                 WRITE (xnome,'(I2)') NNOM
                 OPEN (UNIT=NNOM,FILE='PINC'//XNOME//'.TXT')  !ARQUIVOS DE POSTOS TIPO BOQUEIRAO, FLORESTA E MONTANTE COME�AM EM 51
                 WRITE(NNOM,*)'POSTO MONTANTE: ',SIGLA(1) 
                 
                 DO JJ=1,NDADOS
                    WRITE(NNOM,*)'1,1,1,',NINT(QP(1,JJ))           
                 END DO                                     
                 CLOSE(NNOM)
         END IF         
         
         DO IP = 1, NMTR
                        
            NF=NFASE(IP) 
                     
            DO IFASE = 1, NF                                                                          
               DO IDADO = 2, NDADOS            
                  ITER = 0                                                           
                  O1=Entr(IP,IFASE,IDADO-1)                                               
                  I1 = Entr(IP,IFASE-1,IDADO-1)          
                  I2 = Entr(IP,IFASE-1,IDADO)             
                  Im = (I1 + I2) / 2  
                  CALL PROPAGA(O2,O1,Im,PRECISAO,ITER,NITER,
     *                         IP,TS,QxT,NDT,NF)             
10                Entr(IP,IFASE,IDADO)=NINT(O2)
               END DO  ! END DO IDANI             
            END DO  ! END DO IFASE

C        O DINC COMECA NO POSTO 2. O POSTO 1 EH A PROGRAMADA JA TOTAL, SOMADA COM INC DE MONTANTE.

             
            WRITE(3,*)'POSTO' ,IP            
            WRITE (xnome,'(I2)') IP+20                 
            OPEN (UNIT=20+IP,FILE='PINC'//XNOME//'.TXT')
            IF (IP.EQ.NMTR)THEN
            WRITE(IP+20,*)'TRECHO:',IP,',',SIGLA(IP),',',(SBOQ(IP,K),','
     *      ,K=1,TBOQ(IP)),'PROP-EM-',SIGLA(IP+1),',',
     *      (SFLO(K),',',K=1,NFLO),
     *      SIGLA(IP+1),',','INC-EM-',SIGLA(IP+1)
            ELSE           
            WRITE(IP+20,*)'TRECHO:',IP,',',SIGLA(IP),',',(SBOQ(IP,K),','
     *      ,K=1,TBOQ(IP)),'PROP-EM-',SIGLA(IP+1),',',SIGLA(IP+1),',',
     *      'INC-EM-',SIGLA(IP+1)
            END IF
            
                       
            
            DO I=1, NDADOS 
               IFAS=NFASE(IP)               
                ! SOMA OS POSTOS TIPO BOQUEIRAO
                QBOQ1 = 0
                QFLO=0
                DO L = 1, TBOQ(K)
                     QBOQ1=QBOQ1+DBOQ(IP,L,I)
                END DO
                ! SOMA DOS TIPO FLORESTA
                IF(IP.EQ.NMTR)THEN
                DO L = 1, NFLO
                     QFLO=QFLO+DFLO(L,I)
                END DO
                END IF                          
               IF(IP.EQ.NMTR)QP(IP+1,I)=QJU(I)
               DINC(I,IP+1)=NINT(QP(IP+1,I))-NINT(Entr(IP,IFAS,I))
               IF(IP.EQ.NMTR)DINC(I,IP+1)=DINC(I,IP+1)-QFLO
        
               WRITE (3,1500)NINT(QP(IP,I)),
     *         (NINT(DBOQ(IP,L,I)),L=1,TBOQ(IP)), 
     *         (NINT(Entr(IP,J,I)),J=1,IFAS),               
     *         NINT(DINC(I,IP+1)),
     *         NINT(QP(IP+1,I))
1500           FORMAT(100I7)     
               IF(IP.EQ.NMTR)THEN
               WRITE(IP+20,*)'1,1,1,',NINT(QP(IP,I)),
     *         (',',NINT(DBOQ(IP,L,I)),L=1,TBOQ(IP)),',',               
     *         NINT(Entr(IP,IFAS,I)),',',
     *         (NINT(DFLO(L,I)),',',L=1,NFLO),NINT(QP(IP+1,I)),',',
     *         NINT(DINC(I,IP+1))
               ELSE
               WRITE(IP+20,*)'1,1,1,',NINT(QP(IP,I)),
     *         (',',NINT(DBOQ(IP,L,I)),L=1,TBOQ(IP)),',',               
     *         NINT(Entr(IP,IFAS,I)),',',
     *         NINT(QP(IP+1,I)),',',
     *         NINT(DINC(I,IP+1))
               END IF
     
            END DO
            CLOSE(IP+20) 
            
            DO K = 1,TBOQ(IP)
            
                 IARQ = IARQ+1
                 NNOM = 50+IARQ
                 WRITE (xnome,'(I2)') NNOM
                 OPEN (UNIT=NNOM,FILE='PINC'//XNOME//'.TXT')  !ARQUIVOS DE POSTOS TIPO BOQUEIRAO, FLORESTA E MONTANTE COME�AM EM 51
                 
                 IF(IP.EQ.NMTR)THEN
                 WRITE(NNOM,*)'TIPO BOQ ',K,',',SIGLA(IP),
     *           ',PROP-EM-',SIGLA(IP+1),
     *           ',','INC-EM-',SIGLA(IP+1),',',
     *           (SFLO(L),',',L=1,NFLO),
     *           SIGLA(IP+1),',',(SBOQ(IP,L),',',L=1,K)                  
                 ELSE
                 WRITE(NNOM,*)'TIPO BOQ ',K,',',SIGLA(IP),
     *           ',PROP-EM-',SIGLA(IP+1),',INC-EM-',SIGLA(IP+1),
     *           ',',SIGLA(IP+1),',',(SBOQ(IP,L),',',L=1,K)  
                 END IF
                 
                 DO JJ=1,NDADOS
                    IF(IP.EQ.NMTR)THEN
                    WRITE(NNOM,*)'1,1,1,',NINT(QP(IP,JJ)),',',
     *              NINT(Entr(IP,IFAS,JJ)),',',
     *              NINT(DINC(JJ,IP+1)),',',
     *              (NINT(DFLO(L,JJ)),',',L=1,NFLO),
     *               NINT(QJU(JJ)),',',
     *              (NINT(DBOQ(IP,L,JJ)),L=1,K)
                    ELSE
                    WRITE(NNOM,*)'1,1,1,',NINT(QP(IP,JJ)),',',
     *              NINT(Entr(IP,IFAS,JJ)),',',NINT(DINC(JJ,IP+1)),
     *              NINT(QP(IP+1,JJ)),',',
     *             (NINT(DBOQ(IP,L,JJ)),L=1,K)
                    END IF                      
                 END DO   
                                  
                 CLOSE(NNOM)                                    
            END DO
                                    
                                  
         END DO ! IP
         
         ! posto tipo floresta, fora do DO do trecho
        IP = NMTR 
        DO K = 1,NFLO            
                 IARQ = IARQ+1
                 NNOM = 50+IARQ
                 WRITE (xnome,'(I2)') NNOM
                 OPEN (UNIT=NNOM,FILE='PINC'//XNOME//'.TXT')  !ARQUIVOS DE POSTOS TIPO BOQUEIRAO, FLORESTA E MONTANTE COME�AM EM 51
                 WRITE(NNOM,*)'TIPO FLO ',K,',',SIGLA(IP),',',
     *           (SBOQ(IP,L),',',L=1,TBOQ(IP)),
     *           'PROP-EM-',SIGLA(IP+1),',',     
     *           'INC-EM-',SIGLA(IP+1),',',SIGLA(IP+1),',',SFLO(K)
 
                 
                 DO JJ=1,NDADOS
                    WRITE(NNOM,*)'1,1,1,',NINT(QP(IP,JJ)),',',
     *              (NINT(DBOQ(IP,L,JJ)),',',L=1,TBOQ(IP)),
     *              NINT(Entr(ip,IFAS,JJ)),     
     *              ',', DINC(JJ,IP+1),',',NINT(QP(IP+1,JJ)),
     *              ',',NINT(DFLO(K,JJ))                          
                 END DO                                     
                 CLOSE(NNOM)                                    
        END DO         
         
              
                 
C PROPAGAR E SOMAR AS INCREMENTAIS

c PREVISAO DAS INCREMENTAIS SE IINC = 1

         INCPREV = 0  ! VARIAVEL PRA SABER SE VAI TER PREVISAO DE INCREMENTAIS E/OU MONTANTE
         IF(IINC.EQ.1)INCPREV = 1
         IF(PRIMPREV.EQ.1)INCPREV = 1

         NLINHAS = 0
         IF (IINC.EQ.1)THEN
           DO J = 1, NMTR
                NLINHAS = NLINHAS +1                
                DO JJ = 1, TBOQ(J)
                    NLINHAS = NLINHAS + 1
                END DO            
           END DO
           DO JJ = 1, NFLO
                NLINHAS = NLINHAS + 1
           END DO
         END IF
         IF (PRIMPREV.EQ.1)NLINHAS = NLINHAS +1
         
         IF (INCPREV.EQ.1)THEN   !PARA ENTRAR SEMPRE QUE HOUVER ALGUMA PREVISAO (INC OU MONT)
            WRITE(*,*)'PREVENDO INCREMENTAIS...'
            DO J=1, IPER-1    !PULA AS LINHAS PARA IR NO PERIODO IPER CORRETO
                READ(2,'(A20)')A
                DO JJ = 1, NLINHAS
                    READ(2,'(A20)')A
                END DO   
            END DO
                         
            IARQ = 0
            READ(2,*,ERR=115) ! titulo
            
            IF(PRIMPREV.EQ.1)THEN   ! FORA DO DO DOS TRECHOS, PRIMPREV.
                 WRITE(*,*)'PREVENDO MONTANTE...'
                 OPEN(UNIT=4,FILE='PROPAGAR.TXT')
                 WRITE(4,*)'DUMMY DUMMY DUMMY PROP'
                 IARQ=IARQ+1                                                                    
                 READ(2,*,ERR=115)NOMECOEF,NOMECONFIG                                  
                 CALL PREVINC(IARQ+30,YP,NPREV,NOMECOEF,NOMECONFIG,UPM) ! + 30 PQ LA NA PREVINC SOMA 20                  
                 DO JJ=1,NPREV                        
                     WRITE(4,*)'1  1  1 ',NINT(YP(JJ))!VAI LER EM DPROP
                     DPROP(NDADOS+JJ)=NINT(YP(JJ))
                 END DO
                 CLOSE(4) ! ARQUIVO PROPAGAR PREENCHIDO COM AS PREVISOES PARA MONTANTE   
            END IF
                                   
            DO J = 1, NMTR                              
               READ(2,*,err=115)NOMECOEF,NOMECONFIG            
               CALL PREVINC(J,YP,NPREV,NOMECOEF,NOMECONFIG,UPI)   !NA PREVINC VAI SOMAR + 20 NO J PRA ABRIR O ARQUIVO. COME�AM EM 21                
               DO JJ=1,NPREV
                 DINC(NDADOS+JJ,J+1)=YP(JJ)
c                 write(88,*)'em',sigla(j+1),yp(jj) 
               END DO               
               IFAS = NFASE(J)              
               DO K = 1, TBOQ(J)                 
                 IARQ=IARQ+1                                                   
                 READ(2,*,ERR=115)NOMECOEF,NOMECONFIG                                  
                 CALL PREVINC(IARQ+30,YP,NPREV,NOMECOEF,NOMECONFIG,UPI) ! + 30 PQ LA NA PREVINC SOMA 20                  
                 DO JJ=1,NPREV
                        DBOQ(J,K,NDADOS+JJ)=YP(JJ)                        
                        TOTFLO(NDADOS+JJ)=0 !APROVEITANDO O LOOP PRA ZERAR O TOTALIZADOR DE FLO
c                        write(88,*)'em',sboq(j,k),yp(jj) 
                 END DO                                                  
               END DO ! do k 
            END DO  !do j
            
            DO K = 1, NFLO
                 IARQ=IARQ+1                                                   
                 READ(2,*,ERR=115)NOMECOEF,NOMECONFIG                                  
                 CALL PREVINC(IARQ+30,YP,NPREV,NOMECOEF,NOMECONFIG,UPI) ! + 30 PQ LA NA PREVINC SOMA 20                  
                 DO JJ=1,NPREV
                        DFLO(K,NDADOS+JJ)=YP(JJ)
                        TOTFLO(NDADOS+JJ)=TOTFLO(NDADOS+JJ)+YP(JJ)
c                        write(88,*)'em',sflo(k),yp(jj) 
                 END DO                                                 
            END DO ! do flo
            
            DO JJ = 1, NPREV
              DINCJU(NDADOS+JJ)=DINC(NDADOS+JJ,NMTR+1)
            END DO
            
         END IF   !if inc
         
         CLOSE(2)
         CLOSE(4)                  
         
         
         IF(IINC.EQ.1)THEN
         OPEN(UNIT=34,FILE='RELAT\INC-AUTO.CSV',err=120)
         WRITE(34,*)'DUMMY;DUMMY;DUMMY;',((SBOQ(J,K),';',K=1,TBOQ(J)),
     *   'INC-',SIGLA(J+1),';',J=1,NMTR-1),
     *   (SBOQ(NMTR,K),';',K=1,TBOQ(NMTR)),
     *   'INC-',SIGLA(NMTR+1),';',(SFLO(K),';',K=1,NFLO)
         DO JJ = 1, NPREV
         ND = NDADOS+JJ
         WRITE(34,1503)'1;1;1;',((NINT(DBOQ(J,K,ND)),';',K=1,
     *          TBOQ(J)),NINT(DINC(ND,J+1)),';',J=1,NMTR-1),
     *          (NINT(DBOQ(NMTR,K,ND)),';',K=1,TBOQ(NMTR)),
     *          NINT(DINCJU(ND)),';',(NINT(DFLO(K,ND)),';',K=1,NFLO)
         END DO
1503     FORMAT(A7,100(I7,A1))         
         CLOSE(34)
         END IF
         
         IF(PRIMPREV.EQ.1)THEN
         OPEN (UNIT=34,FILE='RELAT\PROPAGAR-AUTO.CSV',ERR=121)
         WRITE(34,*)'DUMMY;DUMMY;DUMMY;',SIGLA(1)
         DO JJ = 1,NPREV
         ND = NDADOS+JJ
         WRITE(34,*)'1;1;1;',NINT(DPROP(ND))
         END DO
         CLOSE(34)
         END IF
         
         
         I = NDADOS+1        
         
         

         WRITE(*,*)'PROPAGANDO...'
         
         WRITE(3,*)    
         WRITE(3,*)'PROPAGACAO:'
   
         
         OPEN (UNIT=2,FILE='PROPAGAR.TXT')
         READ(2,*)
         
         IF(IINC.EQ.0)THEN 
           OPEN (UNIT=5,FILE='INC.TXT')
           READ(5,*)
         END IF 
                   
         DO 
              
            READ(2,*,END=200)D,D,D,DPROP(I)
            IF (IINC.EQ.0)THEN
                READ(5,*,END=200)D,D,D,((DBOQ(J,K,I),K=1,
     *          TBOQ(J)),DINC(I,J+1),J=1,NMTR-1),
     *          (DBOQ(NMTR,K,I),K=1,TBOQ(NMTR)),
     *          DINCJU(I),(DFLO(K,I),K=1,NFLO)
                DINC(I,NMTR+1) = DINCJU(I)   
                NPREV = NPREV+1
            END IF
            
            
            
c            WRITE(*,*)'Dia ',i
            DO K = 1, NUMTRECHOS
                QBOQ1=0
                ! SOMA OS POSTOS TIPO BOQUEIRAO
                DO L = 1, TBOQ(K)
                     QBOQ1=QBOQ1+DBOQ(K,L,I)
                END DO 
                          
                IF (K.EQ.1)THEN                    
                    Entr(K,0,I)=DPROP(I)+QBOQ1
                ELSE
                    Entr(K,0,I)=Entr(K-1,NFASE(K-1),I)+DINC(I,K)+QBOQ1
                END IF
                
                DO J = 1, NFASE(K)
                    NF=NFASE(K)                             
                    I1 = Entr(K,J-1,I-1) !ENTRADA  DA FASE J-1 DO INTERVALO ANTERIOR
                    I2 = Entr(K,J-1,I) !ENTRADA  DA FASE J-1 DO INTERVALO ANTERIOR
                    O1 = Entr(K,J,I-1) !PROPAGADA DA FASE J DO INTERVALO ANTERIOR
                    Im = (I1+I2)/2                    
                    ITER=0
                    O2=O1
                    CALL PROPAGA(O2,O1,Im,PRECISAO,ITER,NITER,
     *                   K,TS,QxT,NDT,NF)
                         
                    Entr(K,J,I)=NINT(O2) 
                                       
                END DO                            
            END DO                          
         I = I +1
         
         END DO       
200      CONTINUE

         I = I-1
         
         NUMTOTAL=I
         
         DO K = 1,NMTR  
         WRITE(3,*)'PROPAGACAO TRECHO ',K          
            DO J = NDADOS+1, NUMTOTAL
                WRITE(3,'(100i7)')(NINT(Entr(K,IFAS,J)),IFAS=0,NFASE(K))
            END DO         
         END DO
         
        
         
ccccc    PREVISAO DA JUSANTE

         WRITE(3,*)'PREVISAO JUSANTE:'

         DO J = NDADOS+1,NUMTOTAL
            TOTFLO(J)=0
            DO K = 1,NFLO
            TOTFLO(J)=TOTFLO(J)+DFLO(K,J)
            END DO
            QJU(J)= Entr(NMTR,NFASE(NMTR),J)+DINCJU(J)+TOTFLO(J)      
            WRITE(3,*)NINT(QJU(J))               
         END DO  


         CLOSE(3)
         OPEN(UNIT=3,FILE='PLAN\RELAT_PROPAGA.CSV',ERR=122,
     *    ACCESS = 'SEQUENTIAL', ACTION='WRITE')

         WRITE(3,*)'PrevIA-PP'
         WRITE(3,*)'Desenvolvido pelo Centro de Pesquisas de Energia 
     *   Eletrica - CEPEL'
         WRITE(3,*)'Data: ',dia,'/',mes,'/',ano
         WRITE(3,*)'Hora:',hora,':',minuto,':',seg
         WRITE(3,1501)'DATA',';',(SIGLA(J),';',(SBOQ(J,K),';',
     *   K=1,TBOQ(J)),(sigla(j),'*;',XX=1,TTEM(J)),
     *   SIGLA(J),('*',XX=1,TTEM(J)),' em ',SIGLA(J+1),
     *   ';','INC ',SIGLA(J),' - ',
     *   SIGLA(J+1),';',J=1,NMTR),(SFLO(K),';',K=1,NFLO),SIGLA(NMTR+1)

1501     FORMAT(100A10)
         DT=0   
         acl='a'      
         WRITE(12,*)'<H2>',NOMERES,'</H2>'
         IF(PRIMPREV.EQ.1)THEN
            WRITE(12,*)'FAZ PREVISAO DE MONTANTE: COEFICIENTES'
             IF(IPER.EQ.1)WRITE(12,*)'PER&Iacute;ODO &Uacute;MIDO)'
             IF(IPER.EQ.2)WRITE(12,*)'PER&Iacute;ODO SECO)'
             IF(IPER.EQ.3)WRITE(12,*)'PER&Iacute;ODO TOTAL)'             
             IF(UPM.EQ.1)WRITE(12,*)'<br>Usa previs&atilde;o para prever
     * montante'
         END IF
         IF(IINC.EQ.1)THEN
             WRITE(12,*)'INCREMENTAIS MODO AUTOM&Aacute;TICO:  
     *(COEFICIENTES '             
             IF(IPER.EQ.1)WRITE(12,*)'PER&Iacute;ODO &Uacute;MIDO)'
             IF(IPER.EQ.2)WRITE(12,*)'PER&Iacute;ODO SECO)'
             IF(IPER.EQ.3)WRITE(12,*)'PER&Iacute;ODO TOTAL)'
             IF(UPI.EQ.1)WRITE(12,*)'<br>Usa previs&atilde;o para prever
     * incrementais' 
             write(12,*)'<br><br>'
         ELSE
             WRITE(12,*)'INCREMENTAIS MODO MANUAL <br><br>'             
         END IF
c         WRITE(12,*)'<H3>RESULTADO DA PROPAGA&Ccedil&Atilde;O:</H3>'
         WRITE(12,*)'<TABLE><TR><TH>DATA</TH>'
         WRITE(12,*)('<TH COLSPAN=',3+TBOQ(J)+TTEM(J),
     *   '>TRECHO ',J,'</th>', J=1, NMTR),'<TH COLSPAN=',
     *   1+NFLO,'>JUSANTE</TH></TR>'
         WRITE(12,*)'<TR class="titcol"><TD>DATA</TD>',(
     *   '<TD>',SIGLA(J),'</TD>',
     *   ('<TD>',SBOQ(J,K),'</TD>',K=1,TBOQ(J)), 
     *   ('<td>',SIGLA(J),'*</td>',XX=1,TTEM(J)),    
     *   '<TD>',SIGLA(J),('*',XX=1,TTEM(J)),' em ',SIGLA(J+1),'</TD>',
     *   '<TD> INC em ',SIGLA(J+1),'</TD>',J=1,NMTR),
     *   ('<TD>',SFLO(K),'</TD>',K=1,NFLO),
     *   '<TD>',SIGLA(NMTR+1),'</TD></TR>'
         
         DT = -1*(NPREV+1) !RELATORIO RESUMIDO
         INI = i-(nprev*2) !RELATORIO RESUMIDO
         
         open(unit=99,file='mostratudo.txt',STATUS='OLD',err=99)!SE EXISTIR ESSE ARQUIVO, ELE VAI MOSTRAR TUDO.
         DT = -1*NDADOS !RELATORIO COMPLETO
         INI = 1        !RELATORIO COMPLETO
         
99       DO K = INI, i 
         
            ! SOMA OS POSTOS TIPO BOQUEIRAO e RETIRA OS VALORES DAS Entr FASE 0.
            DO J=1, NMTR
            QBOQ1=0
            DO L = 1, TBOQ(J)
                 QBOQ1=QBOQ1+DBOQ(J,L,K)
            END DO
            QP(J,K)=Entr(J,0,K)-QBOQ1
            END DO 
                                                     
            DT = DT+1
            aa = 'T'
            if(DT.ge.0)aa='T+'
            WRITE(3,1502)aa,DT,';',(NINT(QP(J,K)),';',
     *      (NINT(DBOQ(J,L,K)),';',L=1,TBOQ(J)),
     *      (NINT(Entr(j,0,K)),';',L=1,TTEM(j)),
     *      NINT(Entr(J,NFASE(J),K)),';',
     *      NINT(DINC(K,J+1)),';',J=1,NMTR),
     *      (NINT(DFLO(J,K)),';',J=1,NFLO),NINT(QJU(K))

1502        FORMAT(A2,I4,A1,I7,A1,100(I7,A1),I7)
            
            IF (K.EQ.NDADOS+1)THEN   !REPETE O CABECALHO PRA FICAR MAIS FACIL VISUALIZAR
            
         WRITE(12,*)'<TR><TH>DATA</TH>'
         WRITE(12,*)('<TH COLSPAN=',3+TBOQ(J)+TTEM(J),
     *   '>TRECHO ',J,'</th>', J=1, NMTR),'<TH COLSPAN=',
     *   1+NFLO,'>JUSANTE</TH></TR>'
         WRITE(12,*)'<TR class="titcol"><TD>DATA</TD>',(
     *   '<TD>',SIGLA(J),'</TD>',
     *   ('<TD>',SBOQ(J,KK),'</TD>',KK=1,TBOQ(J)), 
     *   ('<td>',SIGLA(J),'*</td>',XX=1,TTEM(J)),    
     *   '<TD>',SIGLA(J),('*',XX=1,TTEM(J)),' em ',SIGLA(J+1),'</TD>',
     *   '<TD> INC em ',SIGLA(J+1),'</TD>',J=1,NMTR),
     *   ('<TD>',SFLO(KK),'</TD>',KK=1,NFLO),
     *   '<TD>',SIGLA(NMTR+1),'</TD></TR>'
            
            acl='n'
            
            END IF
            
            IF(K.LT.NDADOS+1)THEN
              WRITE(12,*)'<TR CLASS="antigo">'
            ELSE
              WRITE(12,*)'<TR CLASS="novo">'
            END IF
            WRITE(12,*)'<TD><script>document.write(dataFormatada(',
     *     (DT),'))</script></TD>',('<TD class="',acl,'">',
     * NINT(QP(J,K)),'</TD>',('<TD class="',acl,'">',NINT(DBOQ(J,L,K)),
     * '</TD>',L=1,TBOQ(J)), ('<td class="',acl,'">',nint(Entr(j,0,K)),
     *     '</td>',l=1,ttem(j)),'<TD>',NINT(Entr(J,NFASE(J),K)),'</TD>',
     *      '<TD>',NINT(DINC(K,J+1)),'</TD>',J=1,NMTR),
     *      ('<TD class="',acl,'">',NINT(DFLO(J,K)),'</TD>',J=1,NFLO),
     *      '<TD class="',acl,'">',NINT(QJU(K)),'</TD></TR>'           
         
         END DO  
         WRITE(12,*)'</TABLE>'
         WRITE(3,*)'* Soma dos postos do trecho.'
         WRITE(12,*)'<H4>* Soma dos postos do trecho.</H4>'                                     
         
         WRITE(*,*)'FIM'
         
         stop
110     write(12,*)'<h3>Erro no arquivo de configura&ccedil;&atilde;o
     *     </h3>Verifique os dados. <br>         
     *     Certifique-se de que os tipos <i>CHARACTER</i> est&atilde;o  
     *     entre ap&oacute;strofos " '' ".'
        write(*,*)'Ocorreu um erro. Olhar relatorio de saida.'
        write(*,*)'Fim.'

         stop
         
115     write(12,*)'<h3>Erro no arquivo de configura&ccedil;&atilde;o
     *     </h3>Verifique os dados. <br>  
     * Certifique-se de que os nomes dos arquivos de configura&ccedil;&o            
     *tilde;es das redes est&atilde;o completos e  
     * entre ap&oacute;strofos " '' ". <BR>'
        write(*,*)'Ocorreu um erro. Olhar relatorio de saida.'
        write(*,*)'Fim.'

         stop         

100     write(12,*)'<h3>Erro no arquivo de configura&ccedil;&atilde;o
     *     </h3>Verifique os dados. <br>         
     *     Certifique-se de que os dados dos trechos est&atilde;o
     *     completos e corretos.'  
        write(*,*)'Ocorreu um erro. Olhar relatorio de saida.'
        write(*,*)'Fim.'
         stop  
         
120     write(12,*)'<h3>Erro tentando abrir o arquivo de incrementais 
     *autom&aacute;ticas. <br>Verifique se a planilha INC-AUTO.CSV  
     *est&aacute; aberta.</h3>'   
        write(*,*)'Ocorreu um erro. Olhar relatorio de saida.'
        write(*,*)'Fim.'
         stop 
121     write(12,*)'<h3>Erro tentando abrir o arquivo de propaga&ccedil; 
     *&atilde;o. <br>Verifique se a planilha PROPAGAR-AUTO.CSV  
     *est&aacute; aberta.</h3>'  
        write(*,*)'Ocorreu um erro. Olhar relatorio de saida.'
        write(*,*)'Fim.'
      
122     write(12,*)'<h3>Erro tentando abrir a planilha de relat&oacute;i
     *o. <br>Verifique se a planilha RELAT_PROPAGA.CSV  
     *est&aacute; aberta.</h3>'     
         write(*,*)'Ocorreu um erro. Olhar relatorio de saida.'
        write(*,*)'Fim.'
         stop
         
 2001   write(*,'(''Erro abrindo arquivos. Use a interface'')')
        write(*,'(''Pressione ENTER'')')
        READ(*,*)                  

         END
             
        SUBROUTINE PROPAGA (O2,O1,Im,PRECISAO,ITER,NITER,
     *                      IP,TS,QxT,NDT,NF)  
     
         INCLUDE 'PROPAG.DIM'   
         

         O2 = O1 
           
 100     Om = (O2 + O1) / 2

         CALL TEMPO_ARMAZ (IP,TS,QxT,Om,
     *                     NDT,NF)
              
         O2 = O1+(Im-O1)*24/(TS+24/2)

C CALCULO DE 
         Err = O2 - Om
         
              
C         IF(ITER.GE.5000)WRITE(55,*)'CHEGOU A 5000'
              
         IF(ITER.GT.NITER)GOTO 10
              
         IF (ABS(Err).LT.PRECISAO)THEN
            GOTO 10
         ELSE        
            ITER = ITER + 1
            GOTO 100        
         END IF
          

  10     CONTINUE

         END
                 
         SUBROUTINE TEMPO_ARMAZ(IP,TS,QxT,Om,
     *                          NDT,NF)
         INCLUDE 'PROPAG.DIM'
         
        
         DO I = 1, NDT(IP)         
            IF(Om.LT.QxT(IP,I,1))THEN
                if(i.eq.1)goto 10                         
                X1 = QxT(IP,I-1,1)
                X2 = QxT(IP,I,1)
                Y1 = QxT(IP,I-1,2)
                Y2 = QxT(IP,I,2)                
                DELTAX = X2-X1
                DELTAY = Y2-Y1                                               
                TS=Y1+(Om-X1)*DELTAY/DELTAX
                TS=TS/NF
                GOTO 20           
            END IF         
         END DO                  
 
 10     WRITE(12,*)'<H3>TRECHO ',IP,': VAZ&Atilde;O FORA DO INTERVALO 
     * DA TABELA (',OM,') </H3>'
         write(12,*)'<b>Poss&iacute;veis solu&ccedil;&otilde;es:</b>'
         WRITE(12,*)'<br><br>1) Verifique os dados de entrada.'
         WRITE(12,*)'<br>2) Se est&aacute; fazendo previs&atilde;o de  
     *  incrementais autom&aacute;ticas, verifique as previs&otilde;es 
     *  para este trecho no arquivo INC-AUTO.CSV.<br> &nbsp;&nbsp;&nbsp; 
     *  Modifique as previs&otilde;es para valores mais adequados  
     *  e use a op&ccedil;&atilde;o de entrada manual de incrementais.'
         WRITE(12,*)'<br>3) Se est&aacute; fazendo previs&atilde;o de  
     *  montante, verifique as previs&otilde;es 
     *  para este trecho no arquivo PROPAGAR-AUTO.CSV.<br> &nbsp;&nbsp; 
     *  &nbsp;Modifique as previs&otilde;es para valores mais adequados  
     *  e desmarque a op&ccedil;&atilde;o prever montante.'
        write(*,*)'Ocorreu um erro. Olhar relatorio de saida.'
        write(*,*)'Fim.'
         stop

 20      CONTINUE               
         END
         

         
