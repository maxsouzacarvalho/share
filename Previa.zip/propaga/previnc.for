        subroutine previnc(iunit,yp,d2,nomecoef,
     *  nomeconfig,usaprev)       

        Include  'paramprev.dim'        
        integer*2 n1,d1,d2,icam,iprint,nnt,iprev,ip,t1,t2
        integer*2 nn,z,pj,p(nmp,mmax),g(nmp,mmax),n3,gj,q,ypstotal  
        INTEGER*2 ANO,MES,DIA,HORA,MINUTO,SEG,DECSEG,USAPREV
        dimension y(nmd),x(nmd,nmx),q(nmp),zprev(nmp),yps(nmd+nmp)
        dimension w(mmax),zz(mmax),yp(nmp),smooth_y(nmp+nmd)
        real max, min,asc,dsc,L95(nmp),ud,yy,xr(nmd+nmp)
        dimension itree(10,mmax),tree(10,mmax,6)
        dimension itr(2*nmm), yloess(nmp+nmd)
        CHARACTER*3 a
        character*2 hh,mm,dd,ms,uiposto
        character*4 aa
        character*8 aasc, adsc
        character*20 nomecoef, nomeconfig
        character*80 tit1, tit2        
        
        
        write(uiposto,'(I2)') 20+iunit
                
        open (unit=8, file='pinc'//uiposto//'.txt')       
        open (unit=7, file='configprop\'//nomeconfig,status='old',
     *   err=117)
        open (unit=11, file='ddp.txt')
        open (unit=13,file='temp.txt')
        open (unit=16, file='configprop\'//nomecoef,status='old',
     *  err=116)                        
                

        read(7,'(a80)',err=107)tit1
        read(16,'(a80)',err=106)tit2

        if(tit1.ne.tit2)then
          WRITE(12,*)'T&iacute;tulo do caso n&atilde;o '
          write(12,*)'coincicide entre coeficientes e 
     *configura&ccedil;&atilde;o. Calibra&ccedil;&otilde;es diferentes.'
          write(12,*)'</font><hr>'
          write(*,*)'Arquivos: ',nomeconfig,' ',nomecoef
          stop
        else
c          WRITE(12,*)'T&iacute;tulo do caso: ', tit1
c          write(12,*)'</font><hr>'  
        end if
                
        
        read(13,*)asc,dsc                    
        read(7,*,err=107)nn,d2              
        read(8,*) !pula a linha
        
        pj = 0  !maxima defasagem           
        do l = 1, d2
            q(l)=0!quantidade de entradas
            read(7,*,err=107)(g(l,j),p(l,j),j=nn,1,-1)                       
            do i = 1, nn            
               if(g(l,i).eq.0)then
                    if(p(l,i).gt.0)then
                        write(12,*)'<h2>Erro nas configuracoes: 
     *   inicio nao pode ser 0</h2>'
                    stop                
                    end if
               else
                    q(l) = q(l) + p(l,i)-g(l,i)+1
                    if(pj.lt.p(l,i))pj=p(l,i)
               end if                  
            end do
            if(q(l).gt.mmax)goto 108
        end do                                                       

     
        
        n1=1        
        Do 
        if(pj.lt.d2)pj=d2            
            Read(8,*,End=10,Err=100)dmy,dmy,dmy,(x(n1,j),j=nn,1,-1)
            y(n1)=x(n1,1)
            xr(n1)=n1
            yloess(n1)=y(n1)
            n1 = n1+1
        End Do
        
10      n1=n1-1

        ud=y(n1)
        
        if (n1.lt.pj)goto 102 
        if (n1.gt.15000)goto 101        
        
!       suavizando entradas
!        span = 3
!        call loess_smoothing (xr, yloess, n1, span, smooth_y)
!        do j = 1, n1
!            write(78,*)y(j),nint(smooth_y(j))
!            y(j)=smooth_y(j)
!        end do
!        do j =1, nn
!          do jloess = 1, n1
!              yloess(jloess) = x(jloess,j)
!          end do
!          call loess_smoothing(xr, yloess, n1, span, smooth_y)
!          do jloess = 1, n1
!              write(78,*)x(jloess,j),nint(smooth_y(jloess)) 
!              x(jloess,j)= nint(smooth_y(jloess)) 
!          end do
!        end do
        
!       preparando o arquivo para previsao
       
        
        if(usaprev.eq.1)then
        
        do i = 1, d2
        write(11,*)i,q(1)
        z=0
        do j = 1, nn
           if(g(1,j).gt.0)then
           do jj =g(1,j), p(1,j)
           z = z+1                
             w(z)= x(n1-jj+1,j)
           end do 
           end if
        end do
        write(11,*)i,(w(k),k=1,q(1))
        end do
        
        else
                                      
        do i = 1, d2
        write(11,*)i,q(i)
        z=0
        do j = 1, nn
           if(g(i,j).gt.0)then
           do jj =g(i,j), p(i,j)
           z = z+1                
             w(z)= x(n1-jj+1,j)
           end do 
           end if
        end do
        write(11,*)i,(w(k),k=1,q(i))
        end do
        
        end if
ccccccccccccccccccccccccccccc
        rewind(11)
               
        ! a normaliza��o � feita dentro do lecomp
        do i = 1, d2
 
           call lecomp(zz,itree,tree,iter,itr,L95(i),
     *                 ibeta,usaprev,inorm,zprev,i)                        
           call comp(zz,yy,itree,tree,iter,itr)
        
        if(inorm.eq.1)then
         amax = ymax
         amin = ymin
        else
         amax = 1
         amin = 0
        end if
        
        if (ud.eq.0)ud=1 ! se for zero, vai travar em zero, ent�o muda pra 1
        
        zzz = ud                
        yy=yy*(amax-amin)+amin   ! troca por amax e amin para preservar as variaveis ymax e ymin (desfaz a normaliza��o)
        
        !if(yy.gt.1.1*ymax)yy=1.1*ymax  !Tentando lidar com instabilidade num�rica
        !if(yy.lt.1.1*ymin)yy=1.1*ymin  !Tentando lidar com instabilidade num�rica
        
        iaux2 = 0
        
        aux = abs(zzz*asc/100.)+zzz
        
        if(yy.gt.aux)then
         yy=aux
         iaux1=1
        end if
        
        aux = zzz-abs(zzz*dsc/100.)
        
        if(yy.lt.aux)then
        yy=aux
        iaux2=1
        end if        
        
        yp(i)=yy
        zprev(i)=yy
        ud=yy
        
        
         
      end do       
       
       
c       preparando o yps
      !ypstotal = n1+d2
       ypstotal = 3+d2  !fazer a suaviza��o apenas com as mais proximas
      yps(1) = y(n1-2)
      yps(2) = y(n1-1)
      yps(3) = y(n1)
       
      do i = 4, d2+3
          yps(i)=yp(i-3)
          xr(i)=i !para a loess
      end do
       
C       SPAN = d2
C       call loess_smoothing(xr, yps, ypstotal, span, smooth_y)
C       write(89,*)'prevb: ', (yps(j), j = 1, ypstotal)
C       write(89,*)'prevss: ', (smooth_y(j), j = 1, ypstotal)
C       
       SPAN = 3 ! � o que est� passando para a propaga��o.
       call loess_smoothing(xr, yps, ypstotal, span, smooth_y)
       write(89,*)'prevs: ', (smooth_y(j), j = 1, ypstotal)
       
       ! aqui suja a variavel com o ultimo loess
       do i = 1, d2
           yp(i)=smooth_y(i+3)
       end do
            
        CLOSE(8)
        CLOSE(7)
        CLOSE(11)
        CLOSE(13)
        
        RETURN               
        
100     continue
        
        write(12,*)'<html><body><h1> Erro no arquivo dos dados</h1>'
        write(12,*)'Linha anterior:',i+1, y(i+1),(x(i+1,j), j=1,nn)
        write(12,*)'<hr><p><font size=2><b>Desenvolvido pelo Centro de 
     *  Pesquisas de Energia El&eacute;trica - CEPEL</b>
     *  </font></p><hr>'
        write(12,*)'</body></html>'
        close(12)
        stop
        
101     continue

        write(12,*)'<html><body><h1>Arquivo com mais de 15 mil dados<br>
     *   Verifique se o &uacute;ltimo dado &eacute; o mais atual</h1>'
        write(12,*)'Linha anterior:',i+1, y(i+1),(x(i+1,j), j=1,nn)
        write(12,*)'<hr><p><font size=2><b>Desenvolvido pelo Centro de 
     *  Pesquisas de Energia El&eacute;trica - CEPEL</b>
     *  </font></p><hr>'
        write(12,*)'</body></html>'
        close(12)
        stop
        
102     continue

        write(12,*)'<html><body><h1>Quantidade de dados insuficiente.<br>
     *   S&atilde;o necess&uacute;rios ', pj, ' dados.</h1>'
        write(12,*)'Linha anterior:',i+1, y(i+1),(x(i+1,j), j=1,nn)
        write(12,*)'<hr><p><font size=2><b>Desenvolvido pelo Centro de 
     *  Pesquisas de Energia El&eacute;trica - CEPEL</b>
     *  </font></p><hr>'
        write(12,*)'</body></html>'
        close(12)
        stop                

107     continue

        write(12,*)'<html><body><h1>Erro no arquivo de configura&ccedil;
     *&atilde;o ',nomeconfig,' </h1>'
        write(12,*)'Verificar se o nome no CONFIGPROPXXX.TXT est&aacute; 
     *  correto.'
        write(12,*)'<hr><p><font size=2><b>Desenvolvido pelo Centro de 
     *  Pesquisas de Energia El&eacute;trica - CEPEL</b>
     *  </font></p><hr>'
        write(12,*)'</body></html>'
        stop 
        
106     continue

        write(12,*)'<html><body><h1>Erro no arquivo de coeficientes
     *',nomecoef,' </h1>'
        write(12,*)'Verificar se o nome no CONFIGPROPXXX.TXT est&aacute; 
     *  correto.'
        write(12,*)'<hr><p><font size=2><b>Desenvolvido pelo Centro de 
     *  Pesquisas de Energia El&eacute;trica - CEPEL</b>
     *  </font></p><hr>'
        write(12,*)'</body></html>'
        stop            

117     continue

        write(12,*)'<html><body><h1>Erro abrindo arquivo de configura&cc
     *edil;&atilde;o ',nomeconfig,' </h1>'
        write(12,*)'Verificar se o nome no CONFIGPROPXXX.TXT est&aacute; 
     *  correto e se o mesmo existe.'
        write(12,*)'<hr><p><font size=2><b>Desenvolvido pelo Centro de 
     *  Pesquisas de Energia El&eacute;trica - CEPEL</b>
     *  </font></p><hr>'
        write(12,*)'</body></html>'
        stop
        
116     continue

        write(12,*)'<html><body><h1>Erro abrindo arquivo de coeficientes
     *  ',nomecoef,' </h1>'
        write(12,*)'Verificar se o nome no CONFIGPROPXXX.TXT est&aacute; 
     *  correto e se o mesmo existe.'
        write(12,*)'<hr><p><font size=2><b>Desenvolvido pelo Centro de 
     *  Pesquisas de Energia El&eacute;trica - CEPEL</b>
     *  </font></p><hr>'
        write(12,*)'</body></html>'
        stop        

108     continue

        write(12,*)'<html><body><h1>Numero de vari&acute;veis maior que 
     *  ',mmax,'</h1>'
        write(12,*)'Horizonte: ',l,'-'
        write(12,*)'Recalibrar a rede diminuindo o n&uacute;mero 
     *  vari&aacute;veis de entradas no config.csv.'
        write(12,*)'<hr><p><font size=2><b>Desenvolvido pelo Centro de 
     *  Pesquisas de Energia El&eacute;trica - CEPEL</b>
     *  </font></p><hr>'
        write(12,*)'</body></html>'
        stop
        end
        
        
        subroutine lecomp(zz,itree,tree,iter,itr,L95,
     *  ibeta,usaprev,inorm,zprev,id)
        
        Include  'paramprev.dim'
        
        dimension zz(mmax),itree(10,mmax),tree(10,mmax,6)
        dimension itr(2*nmm),zprev(nmp)
        integer ibeta,usaprev,inorm
        real L95, asc, dsc,maxx(mmax),minx(mmax)
        integer*2 m,i
               

        read(11,*)dum, m
        read(11,*)dum,(zz(j),j=1,m)

        read(16,*)
        read(16,*)
        read(16,23)m,L95,ibeta,inorm,ymax,ymin,(maxx(j),j=1,m),
     *        (minx(j),j=1,m)
23      FORMAT(i4,1x,F10.3,1X,2(i4,1x),f10.2,1x,f10.2,1x,160(f10.2,1x))
        
        read(16,*) !pula desvio padrao
        read(16,*) !pula vies
        
        do i = 1, m
            zz(i)=(zz(i)-minx(i))/(maxx(i)-minx(i))  !se nao houver normalizacao, ja serao 0 e 1
        end do

        
        read(16,*)iter
        nitr = 2**(iter+1)
        read(16,*)
        read(16,*)(itr(i), i = 1, nitr+1)! mais 1 pq ele sempre escreve 1 no inicio
        read(16,*)         
        do i = 1, iter+1
        read(16,*)(itree(i,k),k=1,m)
        read(16,*)
         do j = 1, m
            read(16,*)(tree(i,j,k),k=1,6)
         end do
        end do  
        
        end
                
        subroutine comp(x,y,itree,tree,iter,itr)


C Rotina desenvolvida pelo professor Fionn Murtagh
c e modificada para o proposito do modelo PrevIA.
c informacoes em: https://mda-sw.github.io/

        
        include 'paramprev.dim'
        dimension x(mmax),itree(10,mmax),work(2*nmm)
        dimension itr(2*nmm),tree(10,mmax,6)
        
        it = iter
        itr(1) = 1
        i = 1
  6     l = 0
        nn = 2**(i-1)
        n1 = 2**i
        nz = 2**(i+1)-1
        j = n1
  4     jj = itr(nn+l)
        xx = itree(iter,jj)
        itr(j) = itree(iter,jj)/100-10
        iz = itree(iter,jj)/100
        itr(j+1) = xx -100*iz - 10
        j = j + 2
        if (j.gt.nz) goto 3
        l = l + 1
        goto 4
  3     if (iter.eq.1) goto 5
        iter = iter -1
        i = i + 1
        goto 6
  5     iter = it
        nz = 2**(iter-1)
        nzz = nz
        n1 = 2**iter
        do 8 j = 1, nzz
           jj1 = itr(nz)
           jj2 = itr(n1)
           jj3 = itr(n1+1)
           wk = tree(1,jj1,1) + tree(1,jj1,2)*x(jj2) + 
     x                                           tree(1,jj1,3)*x(jj3)
           if(isnan(wk))ww=0
           wk = wk + tree(1,jj1,4)*x(jj2)**2 + tree(1,jj1,5)*x(jj3)**2
           if(isnan(wk))ww=0
           wk = wk + tree(1,jj1,6)*x(jj2)*x(jj3)  
           if(isnan(wk))ww=0
           work(j) = wk
           nz = nz + 1
  8     n1 = n1 + 2
        iter = iter -1
        if (iter.ne.0) goto 12
        y = work(1)
        iter = it
        return
  12    i = 2
  18    nz = 2**(iter-1)
        n1 = 2**iter
        nzz = nz
        n11 = n1
        do 13 j = 1, nzz
           jj = 2*j-1
           jj1 = itr(nz)
           jj2 = itr(n1)
           jj3 = itr(n1+1)
           wk = tree(i,jj1,1) + tree(i,jj1,2)*work(jj)
           if(isnan(wk))ww=0
          wk = wk + tree(i,jj1,3)*work(jj+1) + tree(i,jj1,4)*work(jj)**2
          if(isnan(wk))ww=0
           wk = wk + tree(i,jj1,5)*work(jj+1)**2
           if(isnan(wk))ww=0
           wk = wk + tree(i,jj1,6)*work(jj)*work(jj+1)
           if(isnan(wk))ww=0      
           work(n11+j) = wk
           nz = nz + 1
  13    n1 = n1 + 2
        iter = iter - 1
        if (iter.eq.0) goto 15
        do 14 l = 1, nzz
  14    work(l) = work(n11+l)
        i = i + 1
        goto 18
  15    y = work(3)
        iter = it
        return
        end
