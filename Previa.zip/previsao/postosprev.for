        program prevgmdh        
        !DEC$ boundscheck
        Include  'paramprev.dim'        
        integer*2 n1,d1,d2,icam,iprint,nnt,iprev,ip,t1,t2,t3
        integer*2 nn,z,pj,p(nmp,nmx),g(nmp,nmx),n3,gj,nant,ypstotal
        integer ftipo,usaprev,ibeta,iter,liday,limes,liano  
        INTEGER*2 ANO,MES,DIA,HORA,MINUTO,SEG,DECSEG
        dimension y(nmd),x(nmd,nmx),q(nmp),xr(nmp),smooth_y(nmd)
        dimension w(mmax),zz(mmax),yp(nmp),zprev(nmp),dpmes(12)
        dimension vies_mensal(12), my(nmp)
        real max, min,asc,dsc,L95(nmp),ud,ymax,ymin,fator
        dimension itree(10,mmax),tree(10,mmax,6),yps(nmd),viesp(nmp)
        dimension itr(2*nmm),maxy(nmp),miny(nmp),ym(nmp),dpmesp(nmp)
        CHARACTER*3 a
        character*2 hh,mm,dd,ms
        character*4 aa
        character*10 aasc, adsc,ddd(nmp),aaa,bbb,vvv(nmp)
        CHARACTER*149 EMPRESA
        integer   beta(nmp)
        INTEGER M_P(nmp)
        character*80 tit1, tit2
         ! Primeiro criar arrays para armazenar os dados da tabela
         integer*2 prev_b(nmp), prev_s(nmp), prev_m(nmp), r_vies(nmp)
         integer*2 media(nmp), ls50(nmp), li50(nmp), ls70(nmp),li70(nmp)
         integer*2 ls80(nmp), li80(nmp), ls90(nmp), li90(nmp), ls95(nmp)
         integer*2 li95(nmp)
         character*10 dp_str(nmp), vies_str(nmp)
 
        CALL GETTIM(HORA,MINUTO,SEG,DECSEG)
        CALL GETDAT(ANO,MES,DIA)
        
        write(hh,'(i2)')hora
        write(mm,'(i2)')minuto
        write(dd,'(i2)')dia
        write(ms,'(i2)')mes
        write(aa,'(i4)')ano       
        
        
        call le_licenca(empresa,FTIPO) 
        
        open(unit=12,file='relat\relatprev.html')
        
        
        write(12,*)'<html><head>'
        write(12,*)'<meta name="viewport" content="width=device-width,
     * initial-scale=1.0">'
        write(12,*)'<style>'
        write(12,*)'table {border: none; width: 100%;'
        write(12,*)'margin: 20px 0; font-size: 14px;}'
        write(12,*)'th {background-color: #f8f9fa; color: #495057;'
        write(12,*)'padding: 5px 5px; text-align: center;'
        write(12,*)'border-bottom: 2px solid #dee2e6;'
        write(12,*)'font-weight: 600; text-transform: uppercase;'
        write(12,*)'letter-spacing: 0.5px;}'
        write(12,*)'td {padding: 5px 5px; text-align: center;'
        write(12,*)'border-bottom: 1px solid #e9ecef;}'
      write(12,*)'tr:last-child td {border-bottom: 2px solid #dee2e6;}'
        write(12,*)'tr:hover {background-color: #f1f3f4;}'
        write(12,*)'.horizonte {background-color: #e7f5ff;'
        write(12,*)'font-weight: bold; color: #0066cc;}'
        write(12,*)'.intervalo {color: #6c757d; font-size: 12px;}'
        write(12,*)'.valor-principal {font-weight: bold;'
        write(12,*)'color: #198754; font-size: 15px;}'
        write(12,*)'</style>'
        write(12,*)'<script src=../config/grafico.js></script>'
        write(12,*)'</head><body><font face="Calibri">'
        write(12,*)'<script src=../config/grafico.js></script>'
        write(12,*)'</head><body><font face="Calibri">'
        write(12,*)'<hr>'
        write(12,*)'<h1>PrevIA-P</h1>'
        write(12,*)'<h3>Desenvolvido pelo Centro de Pesquisas de Energia
     * El&eacute;trica - CEPEL</H3>'        
        
        open (unit=8, file='varx.txt',status='old',err=9008)        
        open (unit=7, file='config.txt',status='old',err=9008)
        open (unit=5, file='ddp.txt')
        open (unit=13,file='temp.txt')
        open (unit=16, file='coef.txt')
               
        
        open(unit=14,file='plan\relatprev.csv',err=9009)
        write(14,*,err=9009)
        rewind(14)
        
        
        read(13,*)asc,dsc,usaprev,t1,t2
        read(13,*)t3
        
        write(aasc,'(f8.2)')asc
        write(adsc,'(f8.2)')dsc
        
        iread7=1
        read(7,'(a80)',err=107)tit1
        iread7=iread7+1
        read(16,'(a80)')tit2
         

        write(14,*)'PrevIA-P'
        
        write(14,*)'Desenvolvido pelo Centro de Pesquisas de Energia Ele
     *trica - CEPEL '
        WRITE(14,'(a18,i2,a1,i2,a1,i4)')'DATA DA PREVISAO: ',dia,'/',
     *  mes,'/',ano
        WRITE(14,'(a6,i2,a1,i2,a1,i2)')'Hora: ',hora,':',minuto,':',seg
        write(12,*)'<hr><font size=2>Data da previs&atilde;o: '
        write(12,*)dia,'/',mes,'/',ano, '<br>Hora:'
        write(12,'(2(i2,a1),i2,a4)')hora,':',minuto,':',seg,'<br>'      
                

        if(tit1.ne.tit2)then
          WRITE(12,*)'T&iacute;tulo do caso n&atilde;o '
          write(12,*)'coincicide entre coeficientes 
     *e configura&ccedil;&atilde;o'
          write(12,*)'</font><hr>'
          write(*,*)'   Coeficientes e configuracao sao'
          write(*,*)'   de casos diferentes.'
          stop
        else
          WRITE(12,*)'T&iacute;tulo do caso: ', tit1
          write(12,*)'</font><hr>'  
        end if 
        
        
        
        if(t2.eq.1)write(12,*)'<h2>Sobradinho: '
        if(t2.eq.2)write(12,*)'<h2>Itaparica: '
        if(t2.eq.3)write(12,*)'<h2>Boa Esperan&ccedil;a: '
        if(t2.eq.4)write(12,*)'<h2>Pedra: '
        if(t2.eq.5)write(12,*)'<h2>Tr&ecirc;s Marias: '
        if(t2.eq.6)write(12,*)'<h2>Sobradinho Incremental '        
        if(t2.eq.0)write(12,*)'<h2>',tit1,'</h2>'
        if(t1.eq.1)write(12,*)'previs&atilde;o mensal </h2>'
        if(t1.eq.2)write(12,*)'previs&atilde;o semanal </h2>'
        if(t1.eq.3)write(12,*)'previs&atilde;o di&aacute;ria </h2>'
        if(t3.eq.1)write(12,*)'<h5>*Coeficientes para per&iacute;odo
     *  &Uacute;mido. </h5>'
        if(t3.eq.2)write(12,*)'<h5>*Coeficientes para per&iacute;odo
     *  Seco. </h5>'
        if(t3.eq.3)write(12,*)'<h5>*Coeficientes para per&iacute;odo
     *  Total. </h5>'
        
        
        if(t2.eq.1)write(14,*)'SOBRADINHO '
        if(t2.eq.2)write(14,*)'ITAPARICA '
        if(t2.eq.3)write(14,*)'BOA ESPERAN�A '
        if(t2.eq.4)write(14,*)'PEDRA '
        if(t2.eq.5)write(14,*)'TRES MARIAS '
        if(t2.eq.6)write(14,*)'SOBRADINHO INCREMENTAL '
        if(t2.eq.0)write(14,*)'Previsao avulsa'
        if(t1.eq.1)write(14,*)'Previsao Mensal'
        if(t1.eq.2)write(14,*)'Previsao Semanal'
        if(t1.eq.3)write(14,*)'Previsao Diaria'
        
      
        read(7,*,err=107)nn,d2
        iread7=iread7+1              
        
        iread8=1
        read(8,*,err=100) !pula a linha
        iread8=iread8+1
        
        pj = 0  !maxima defasagem           
        do l = 1, d2
            q(l)=0!quantidade de entradas
            read(7,*,err=107)(g(l,j),p(l,j),j=nn,1,-1)
            iread7=iread7+1                                   
            do i = 1, nn
                if(g(l,i).eq.0)then
                    if(p(l,i).gt.0)then
                        write(12,*)'<h2>Erro nas configuracoes: 
     *   inicio nao pode ser 0</h2>'
                    stop                
                    end if
                else
                    q(l)=q(l)+p(l,i)-g(l,i)+1
                    if(pj.lt.p(l,i))pj=p(l,i)
                end if                  
            end do
            if(q(l).gt.mmax)goto 108
        end do                                       
                
     
        
        n1=1
        
        Do           
          Read(8,*,End=10,Err=100)liday,limes,liano,(x(n1,j),j=nn,1,-1)! so vai interessar o ultimo dia, mes e ano.
          iread8 = iread8+1
          y(n1)=x(n1,1)
          n1 = n1+1
          if(n1.gt.nmd)then
              write(*,*)'Numero de dados maior que ',nmd
              write(12,*)'<h5>N&uacute;mero de dados maior que 
     *    ',nmd,'</h5>'
            stop
          end if
        End Do
       

10      n1=n1-1   !somou, foi ler e nao tinha mais. Precisa diminuir
        
        if (t1 .eq. 1) then
            ! Vers�o para dados mensais: soma meses
            write(12,*)'<script>'
            write(12,*)'function dataFormatada(i){'
      write(12,'(A,I0,A,I0,A,I0,A)') '  var data = new Date(', liano, 
     * ', ', limes-1, ', ', liday, ');'
            write(12,*)'    data.setMonth(data.getMonth() + i);'
            write(12,*)'    var dia = data.getDate();'
            write(12,*)'    if (dia.toString().length == 1){'
            write(12,*)'        dia = "0"+dia;'
            write(12,*)'    }'
            write(12,*)'    var mes = data.getMonth()+1;'
            write(12,*)'    if (mes.toString().length == 1){'
            write(12,*)'        mes = "0"+mes;'
            write(12,*)'    }'
            write(12,*)'    var ano = data.getFullYear();  '        
            write(12,*)'    return mes+"/"+ano;'
            write(12,*)'}      '
            write(12,*)'</script>'
        else
            ! Vers�o original para dados di�rios: soma dias
            write(12,*)'<script>'
            write(12,*)'function dataFormatada(i){'
      write(12,'(A,I0,A,I0,A,I0,A)') '  var data = new Date(', liano, 
     * ', ', limes-1, ', ', liday, ');'
            write(12,*)'    data.setDate(data.getDate() + i);'
            write(12,*)'    var dia = data.getDate();'
            write(12,*)'    if (dia.toString().length == 1){'
            write(12,*)'        dia = "0"+dia;'
            write(12,*)'    }'
            write(12,*)'    var mes = data.getMonth()+1;'
            write(12,*)'    if (mes.toString().length == 1){'
            write(12,*)'        mes = "0"+mes;'
            write(12,*)'    }'
            write(12,*)'    var ano = data.getFullYear();  '        
            write(12,*)'    return dia+"/"+mes+"/"+ano;'
            write(12,*)'}      '
            write(12,*)'</script>'
        end if      
    
        if (n1.lt.pj)goto 102 
        if (n1.gt.500)goto 101
         
        if(t1.eq.3)then
          call CALC_MESES_PREV(liday, limes, liano, D2, M_P)
        end if
        
        if(t1.eq.2)then
          call CALC_MESES_SEMANAIS(liday, limes, liano, D2, M_P)
        end if
        
        if(t1.eq.1)then
            
        do i = 1, d2
            j = i
            if((limes+i).le.12)then
              m_p(i) = limes+i
            else
              m_p (i) = (limes+i)-12
            end if 
        end do
            
        end if
        
        if(t1.eq.0)then  !previsao avulsa. N�o d� pra saber o m_p, pois nao sabe o passo de tempo
            do i = 1, d2
                m_p(i)=limes
            end do
        end if            
        
!       preparando o arquivo para previsao
                                      
        do i = 1, d2
        write(5,*)i,q(i)
        z=0
        do j=1, nn
           if(g(i,j).gt.0)then
           do jj =g(i,j), p(i,j)
             z = z+1
             w(z)= x(n1-jj+1,j)
           end do
           end if
        end do
        write(5,*)i,m_p(i),(w(k),k=1,q(i))
c        write(34,*)i,(nint(w(k)),k=1,q(i))
        end do
        
c        stop
ccccccccccccccccccccccccccccc
        rewind(5)
               
        
        nant = d2
        if (n1.lt.d2)nant = n1
        
        
        WRITE(12,*)'<b>&Uacute;LTIMOS DADOS:</b><br>'
        WRITE(14,*)'ULTIMOS DADOS'
        WRITE(14,'(20(a2,i2,a1))')('t-',idado,';', idado=d2-1,0,-1)
        write(12,*)'<table><tr>'        
        idado = nant-1
        do i = n1-nant+1,n1
        !write(12,'(a9,i2,a5)')'<th>t - ',idado,'</th>'
         WRITE(12,'(A,I0,A)') '<TH style="font-size:12px"><script>
     *  document.write(dataFormatada(', -idado, '))</script></TH>'
        idado = idado-1
        end do
        write(12,*)'</tr><tr>'
        
        
        write(14,*)(nint(y(i)),';',i=n1-nant+1, n1)
        
        do i = n1-nant+1, n1
        iyy = nint(y(i))
        write(12,'(a4,i7,a5)')'<td>',iyy,'</td>'
        end do        
        
        ud = y(n1) ! ultimo dado pra calular ascencao e recessao
        
         write(12,*)'</tr></table>'       
         write(12,*)'<hr>'
         WRITE(12,*)'<b>PREVIS&Atilde;O:</b><br>'
         write(14,*)'PREVISAO'
         

         
         ! Agora ler os dados e armazenar nos arrays
         do i = 1, d2
           call lecomp(zz,itree,tree,iter,itr,L95(i),
     *         ibeta,ymax,ymin,usaprev,inorm,zprev,i,dpmes,vies_mensal) 
           call comp(zz,yy,itree,tree,iter,itr)
           
           dpmesp(i)=dpmes(m_p(i))
           viesp(i) = vies_mensal(m_p(i))
           if(dpmesp(i).le.0)dpmesp(i)=l95(i)
           
           WRITE(aaa, '(F10.3)')dpmesp(i)
           WRITE(bbb, '(F10.3)')viesp(i)*100
           
           aaa = ADJUSTL(aaa)
           bbb = ADJUSTL(bbb)
           
          DO ia = 1, LEN(aaa)
              IF (aaa(Ia:Ia) .EQ. '.') THEN
                  aaa(Ia:Ia) = ','
              END IF
          END DO
          
          DO ia = 1, LEN(bbb)
              IF (bbb(Ia:Ia) .EQ. '.') THEN
                  bbb(Ia:Ia) = ','
              END IF
          END DO
          
          ddd(i) = trim(aaa)
          vvv(i) = trim(bbb)
        
           beta(i)=ibeta
           maxy(i)=ymax
           miny(i)=ymin
           
        
           zzz = ud
           if(inorm.eq.1)then
               yy=yy*(ymax-ymin)+ymin
           end if
           
           if(yy.gt.1.1*ymax)yy=1.1*ymax
           if(yy.lt.1.1*ymin)yy=1.1*ymin
        
           iaux1 = 0
           iaux2 = 0
        
           aux = abs(zzz*asc/100.)+zzz
        
           if(yy.gt.aux)then   
               yy=aux
               iaux1=1
           end if
        
           aux = zzz-abs(zzz*dsc/100.)
        
           if(yy.lt.aux)then
               yy=aux
               iaux2=1
           end if
        
           yp(i)=yy
           zprev(i)=yy
           ym(i) = yy
           ud = yy
           
            if(iter.gt.1)then
             do j=(iter-1),1,-1
                 call comp(zz,yy,itree,tree,j,itr)
                 if(inorm.eq.1)yy = yy*(ymax-ymin)+ymin
                 ym(i)=ym(i)+yy
             end do
             ym(i)=ym(i)/iter
            end if
         end do
                   
       ! Preparar yps para suaviza��o
       ypstotal = n1+d2
       do i = 1, n1
         yps(i)=y(i)
       end do
       
       do i = n1+1, ypstotal
          yps(i)=yp(i-n1)
       end do

       span = 3
       call loess_smoothing(yps, ypstotal, span, smooth_y)
       
       ! Armazenar todos os valores nos arrays
       do i = 1, d2
         prev_b(i) = nint(yp(i))
         prev_s(i) = nint(smooth_y(n1+i))
         prev_m(i) = nint(ym(i))
         r_vies(i) = nint(smooth_y(n1+i)/(1+viesp(i)))
         media(i) = nint((smooth_y(n1+i) + r_vies(i) + 
     *                ym(i) + yp(i))/4)
         ls50(i) = nint(yp(i) + 0.674*dpmesp(i))
         li50(i) = nint(yp(i) - 0.674*dpmesp(i))
         ls70(i) = nint(yp(i) + 1.036*dpmesp(i))
         li70(i) = nint(yp(i) - 1.036*dpmesp(i))
         ls80(i) = nint(yp(i) + 1.28*dpmesp(i))
         li80(i) = nint(yp(i) - 1.28*dpmesp(i))
         ls90(i) = nint(yp(i) + 1.645*dpmesp(i))
         li90(i) = nint(yp(i) - 1.645*dpmesp(i))
         ls95(i) = nint(yp(i) + 1.96*dpmesp(i))
         li95(i) = nint(yp(i) - 1.96*dpmesp(i))
         dp_str(i) = ddd(i)
         vies_str(i) = vvv(i)
       end do
       
       ! Primeiro o cabe�alho
       write(12,*)'<table><tr><th>DATA</th>'
       write(12,*)'<th>Prev. B.</th>'
       write(12,*)'<th>Prev. S.</th>'
       write(12,*)'<th>Prev. M.</th>'
       write(12,*)'<th>R. Vies</th>'
       write(12,*)'<th>M�dia</th>'
       write(12,*)'<th>LS 50%</th>'
       write(12,*)'<th>LI 50%</th>'
       write(12,*)'<th>LS 70%</th>'
       write(12,*)'<th>LI 70%</th>'
       write(12,*)'<th>LS 80%</th>'
       write(12,*)'<th>LI 80%</th>'
       write(12,*)'<th>LS 90%</th>'
       write(12,*)'<th>LI 90%</th>'
       write(12,*)'<th>LS 95%</th>'
       write(12,*)'<th>LI 95%</th>'
       write(12,*)'<th>DP</th>'
       write(12,*)'<th>Vi�s(%)</th>'
       write(12,*)'</tr>'
       
       ! Agora para cada horizonte (linha)
       do i = 1, d2
         write(12,*)'<tr>'
         ! Primeira coluna: horizonte
         !write(12,'(a9,i2,a5)')'<td>t+',i,'</td>'
            WRITE(12,*)'<TD style="font-size:12px">
     *     <script>document.write(dataFormatada(',(i),'))</script></TD>'         
         ! Demais colunas: valores das estat�sticas
         write(12,'(a4,i9,a5)')'<td>',prev_b(i),'</td>'
         write(12,'(a4,i9,a5)')'<td>',prev_s(i),'</td>'
         write(12,'(a4,i9,a5)')'<td>',prev_m(i),'</td>'
         write(12,'(a4,i9,a5)')'<td>',r_vies(i),'</td>'
         write(12,'(a4,i9,a5)')'<td>',media(i),'</td>'
         write(12,'(a4,i9,a5)')'<td>',ls50(i),'</td>'
         write(12,'(a4,i9,a5)')'<td>',li50(i),'</td>'
         write(12,'(a4,i9,a5)')'<td>',ls70(i),'</td>'
         write(12,'(a4,i9,a5)')'<td>',li70(i),'</td>'
         write(12,'(a4,i9,a5)')'<td>',ls80(i),'</td>'
         write(12,'(a4,i9,a5)')'<td>',li80(i),'</td>'
         write(12,'(a4,i9,a5)')'<td>',ls90(i),'</td>'
         write(12,'(a4,i9,a5)')'<td>',li90(i),'</td>'
         write(12,'(a4,i9,a5)')'<td>',ls95(i),'</td>'
         write(12,'(a4,i9,a5)')'<td>',li95(i),'</td>'
         write(12,'(a,a,a)')'<td style="font-size:12px">',
     *   dp_str(i),'</td>'
         write(12,'(a,a,a)')'<td style="font-size:12px">',
     *   vies_str(i),'</td>'
         write(12,*)'</tr>'
       end do
       write(12,*)'</table><p></p>'
       
       ! Escrever CSV transposto
       write(14,*)'Horizonte;Prev. B.;Prev. S.;Prev. M.;R. Vies;M�dia;'
     * //'LS 50%;LI 50%;LS 70%;LI 70%;LS 80%;LI 80%;LS 90%;LI 90%;'
     * //'LS 95%;LI 95%;DP;Vi�s(%)'
       
       do i = 1, d2
         write(14,*)
     *   't+',i,';',
     *   prev_b(i),';',
     *   prev_s(i),';',
     *   prev_m(i),';',
     *   r_vies(i),';',
     *   media(i),';',
     *   ls50(i),';',
     *   li50(i),';',
     *   ls70(i),';',
     *   li70(i),';',
     *   ls80(i),';',
     *   li80(i),';',
     *   ls90(i),';',
     *   li90(i),';',
     *   ls95(i),';',
     *   li95(i),';',
     *   dp_str(i),';',
     *   vies_str(i)
       end do
       
       write(12,*)'<h5> Intervalo de confian�a SAZONAL, baseado no desvi
     *o padr�o dos res�duos mensais.</h5>'
       write(12,*)'<table style="width:300px;aling:left"><tr><td>'
       write(12,*)'<font color="red" size="2">',adsc,' %</font></td>
     *         <td><font color="red" size="2">Taxa de Recess&atilde;o
     *         </font></td></tr><tr><td>'
       write(12,*)'<font color="blue" size="2">',aasc,' %</font></td>
     *         <td><font color="blue" size="2">Taxa de Ascens&atilde;o
     *         </font></td></tr></table>'
       
        
       call grafico(y,yp,smooth_y,L95,n1,d2,nant,dpmesp,
     * ymin,ymax,viesp,ym,my)
       
       write(12,*)'<p></p><b>'
       write(12,*)'<font size="2">Dados da calibra&ccedil;&atilde;o:'
       write(12,*)'</b><table><tr>'
       write(12,*)'<th><font size="2">Horizonte</th>'
       write(12,*)'<th><font size="2">Termo independente</th>'
       write(12,*)'<th><font size="2">Observa&ccedil;&atilde;o m&aacute
     *xima</th>'
       write(12,*)'<th><font size="2">Observa&ccedil;&atilde;o m&iacute
     *nima</th>'
       write(12,*)'</tr>'
        
       do i = 1, d2
           write(12,*)'<tr>'
           write(12,*)'<td><font size="2">',i,'</td>'
           if (beta(I).eq.1)then
               write(12,*)'<td><font size="2">COM</td>'
           else
               write(12,*)'<td><font size="2">SEM</td>'
           end if
           write(12,*)'<td><font size="2">',maxy(i),'</td>'
           write(12,*)'<td><font size="2">',miny(i),'</td>'
           write(12,*)'</tr>'
       end do
       write(12,*)'</table>'
       write(12,*)'</body></html>'    
        
       write(*,*)'FIM'
        
       stop            

        
100     continue
        
        write(*,*)'Ocorreu um erro.'
        write(*,*)'Olhar relatorio.'
        write(12,*)'<html><body><h1> Erro no arquivo dos dados</h1>'
        write(12,*)'Linha :',iread8
        write(12,*)'<hr><p><font size=2><b>Desenvolvido pelo Centro de 
     *  Pesquisas de Energia El&eacute;trica - CEPEL</b>
     *  </font></p><hr>'
        write(12,*)'</body></html>'
        close(12)
        stop
        
101     continue
        write(*,*)'Ocorreu um erro.'
        write(*,*)'Olhar relatorio.'
        write(12,*)'<html><body><h1>Arquivo com mais de 1000 dados<br>
     *   Verifique se o &uacute;ltimo dado &eacute;o mais atual</h1>'
        write(12,*)'Linha anterior:',i+1, y(i+1),(x(i+1,j), j=1,nn)
        write(12,*)'<hr><p><font size=2><b>Desenvolvido pelo Centro de 
     *  Pesquisas de Energia El&eacute;trica - CEPEL</b>
     *  </font></p><hr>'
        write(12,*)'</body></html>'
        close(12)
        stop
        
102     continue
        write(*,*)'Ocorreu um erro.'
        write(*,*)'Olhar relatorio.'
        write(12,*)'<html><body>Quantidade de dados insuficiente.<br>
     *  S&atilde;o necess&aacute;rios, no m&iacute;nimo,',
     *  pj,' dados.</h2>'
        write(12,*)'<hr><p><font size=2><b>Desenvolvido pelo Centro de 
     *  Pesquisas de Energia El&eacute;trica - CEPEL</b>
     *  </font></p><hr>'
        write(12,*)'</body></html>'
        close(12)
        stop                

107     continue
        write(*,*)'Ocorreu um erro.'
        write(*,*)'Olhar relatorio.'
        write(12,*)'<html><body><h1>Erro no arquivo de 
     *  configura&ccedil;&otilde;es</h1>'
        write(12,*)'Linha: ', iread7
        write(12,*)'verificar o config.txt e o config.csv'
        write(12,*)'<hr><p><font size=2><b>Desenvolvido pelo Centro de 
     *  Pesquisas de Energia El&eacute;trica - CEPEL</b>
     *  </font></p><hr>'
        write(12,*)'</body></html>'
        stop     

108     continue
        write(*,*)'Ocorreu um erro.'
        write(*,*)'Olhar relatorio.'
        write(12,*)'<html><body><h1>N&uacute;mero de vari&aacute;veis 
     *  maior que ',mmax,' </h1>'
        write(12,*)'Horizonte: ',l
        write(12,*)'<br>Diminuir o numero de entradas no config.csv'        
        write(12,*)'</body></html>'
        stop
        
 9008   write(12,*)'<html><body><h1>Erro abrindo arquivo de dados'
        write(12,*)'<br>Use a interface.</h1>'
        write(*,*)'</body></html>'  
        write(*,*)'Erro abrindo arquivo de dados'
        write(*,*)'Use a interface.'
        stop
        
 9009   write(12,*)'<html><body><h1>Erro abrindo arquivo relatprev.csv'
        write(12,*)'<br>Verifique se o mesmo est� aberto e feche-o</h1>'
        write(12,*)'</body></html>'
        write(*,*)'Erro abrindo arquivo relatprev.csv'
        write(*,*)'Verifique se o mesmo est� aberto e feche-o.'
        stop
               
        end
        
        
        subroutine lecomp(zz,itree,tree,iter,itr,L95,
     *  ibeta,ymax,ymin,usaprev,inorm,zprev,id,dpmes,vies_mensal)
        
        Include  'paramprev.dim'
        
        dimension zz(mmax),itree(10,mmax),tree(10,mmax,6)
        dimension itr(2*nmm),zprev(nmp),dpmes(12),vies_mensal(12)
        integer ibeta,usaprev,iter
        real L95, asc, dsc,ymax,ymin,maxx(mmax),minx(mmax)
        integer*2 m,i
               
        read(5,*)dum,m
        read(5,*)dum,imes,(zz(j),j=1,m)

        read(16,*)
        read(16,*)
        read(16,23)m,L95,ibeta,inorm,ymax,ymin,(maxx(j),j=1,m),
     *        (minx(j),j=1,m)
23     FORMAT(i4,1x,F10.3,1X,2(i4,1x),f10.2,1x,f10.2,1x,160(f10.2,1x))
        read(16,*)(dpmes(j),j=1,12)
        read(16,*)(vies_mensal(j),j=1,12)
        do i = 1, m
            zz(i)=(zz(i)-minx(i))/(maxx(i)-minx(i))  !se nao houver normalizacao, ja serao 0 e 1
        end do

        
        read(16,*)iter
        nitr = 2**(iter+1)
        read(16,*)
        read(16,*)(itr(i), i = 1, nitr+1)! mais 1 pq ele sempre escreve 1 no inicio
        read(16,*)         
        do i = 1, iter+1
        read(16,*)(itree(i,k),k=1,m)
        read(16,*)
         do j = 1, m
            read(16,*)(tree(i,j,k),k=1,6)
         end do
        end do  
        
        
        
        end
                
        subroutine comp(x,y,itree,tree,iter,itr)


C Rotina desenvolvida pelo professor Fionn Murtagh
c e modificada para o proposito do modelo PrevIA.
c informacoes em: https://mda-sw.github.io/

        
        include 'paramprev.dim'
        dimension x(mmax),itree(10,mmax),work(2*nmm)
        dimension itr(2*nmm),tree(10,mmax,6)
        
        it = iter
        itr(1) = 1
        i = 1
  6     l = 0
        nn = 2**(i-1)
        n1 = 2**i
        nz = 2**(i+1)-1
        j = n1
  4     jj = itr(nn+l)
        xx = itree(iter,jj)
        itr(j) = itree(iter,jj)/100-10
        iz = itree(iter,jj)/100
        itr(j+1) = xx -100*iz - 10
        j = j + 2
        if (j.gt.nz) goto 3
        l = l + 1
        goto 4
  3     if (iter.eq.1) goto 5
        iter = iter -1
        i = i + 1
        goto 6
  5     iter = it
        nz = 2**(iter-1)
        nzz = nz
        n1 = 2**iter
        do 8 j = 1, nzz
           jj1 = itr(nz)
           jj2 = itr(n1)
           jj3 = itr(n1+1)
           wk = tree(1,jj1,1) + tree(1,jj1,2)*x(jj2) + 
     x                                           tree(1,jj1,3)*x(jj3)
           if(isnan(wk))ww=0
           wk = wk + tree(1,jj1,4)*x(jj2)**2 + tree(1,jj1,5)*x(jj3)**2
           if(isnan(wk))ww=0
           wk = wk + tree(1,jj1,6)*x(jj2)*x(jj3)
           if(isnan(wk))ww=0
           work(j) = wk
           nz = nz + 1
  8     n1 = n1 + 2
        iter = iter -1
        if (iter.ne.0) goto 12
        y = work(1)
        iter = it
        return
  12    i = 2
  18    nz = 2**(iter-1)
        n1 = 2**iter
        nzz = nz
        n11 = n1
        do 13 j = 1, nzz
           jj = 2*j-1
           jj1 = itr(nz)
           jj2 = itr(n1)
           jj3 = itr(n1+1)
           wk = tree(i,jj1,1) + tree(i,jj1,2)*work(jj)
           if(isnan(wk))ww=0
          wk = wk + tree(i,jj1,3)*work(jj+1) + tree(i,jj1,4)*work(jj)**2
          if(isnan(wk))ww=0
           wk = wk + tree(i,jj1,5)*work(jj+1)**2
           if(isnan(wk))ww=0
           wk = wk + tree(i,jj1,6)*work(jj)*work(jj+1)
           if(isnan(wk))ww=0
           work(n11+j) = wk
           nz = nz + 1
  13    n1 = n1 + 2
        iter = iter - 1
        if (iter.eq.0) goto 15
        do 14 l = 1, nzz
  14    work(l) = work(n11+l)
        i = i + 1
        goto 18
  15    y = work(3)
        iter = it
        return
        
        end
        
      SUBROUTINE loess_smoothing(y, n, span, smooth_y)
      Include  'paramprev.dim' 
      INTEGER*2 n
      Dimension x(n), y(n),smooth_y(n)
      INTEGER i, j
      REAL dist, weight, sum_weight, sum_weighted_y,span
      
      DO i = 1, n
         sum_weighted_y = 0.0
         sum_weight = 0.0
         DO j = 1, n
c            dist = ABS(x(j) - x(i))
            dist = ABS(j - i)!x(j) e x(i) vao ser exatamente j e i.
            IF (dist .LT. span) THEN
               weight = (1.0 - (dist/span)**3)**3 ! Tri-cube weighting function
               sum_weighted_y = sum_weighted_y + weight * y(j)
               sum_weight = sum_weight + weight
            END IF
         END DO
         smooth_y(i) = sum_weighted_y / sum_weight
      END DO
      END 
      SUBROUTINE CALC_MESES_PREV(DIA, MES, ANO, D2, MESES_PREV)
C     ---------------------------------------------------------
C     Subrotina para calcular os meses das previsoes diarias
C     considerando a variacao de dias nos meses e anos bissextos
C
C     Input:
C        DIA   - Dia inicial (ultimo dia observado)
C        MES   - Mes inicial
C        ANO   - Ano inicial
C        D2    - Numero de dias de previsao
C
C     Output:
C        MESES_PREV - Vetor com os meses de cada dia de previsao
C
C     Autor: Adaptado para FORTRAN 77
C     ---------------------------------------------------------
      INTEGER*2 DIA, MES, ANO, D2
      INTEGER MESES_PREV(48)
      INTEGER DIAS_MES(12), DIA_ATUAL, MES_ATUAL, ANO_ATUAL
      INTEGER I, DIAS_NO_MES
      LOGICAL BISSEXTO
      
C     Define numero de dias em cada mes (considerando fev=28 inicialmente)
      DATA DIAS_MES /31,28,31,30,31,30,31,31,30,31,30,31/
      
C     Inicializa variaveis com a data inicial
      DIA_ATUAL = DIA
      MES_ATUAL = MES
      ANO_ATUAL = ANO
      
C     Verifica se o ano e bissexto e ajusta fevereiro
      IF (BISSEXTO(ANO_ATUAL)) THEN
          DIAS_MES(2) = 29
      ELSE
          DIAS_MES(2) = 28
      END IF
      
C     Loop sobre os dias de previsao
      DO 100 I = 1, D2
C         Avanca um dia
          DIA_ATUAL = DIA_ATUAL + 1
          
C         Verifica se passou para o proximo mes
          IF (DIA_ATUAL .GT. DIAS_NO_MES(MES_ATUAL, ANO_ATUAL)) THEN
              DIA_ATUAL = 1
              MES_ATUAL = MES_ATUAL + 1
              
C             Verifica se passou para o proximo ano
              IF (MES_ATUAL .GT. 12) THEN
                  MES_ATUAL = 1
                  ANO_ATUAL = ANO_ATUAL + 1
C                 Atualiza fevereiro para o novo ano
                  IF (BISSEXTO(ANO_ATUAL)) THEN
                      DIAS_MES(2) = 29
                  ELSE
                      DIAS_MES(2) = 28
                  END IF
              END IF
          END IF
          
C         Armazena o mes correspondente a este dia de previsao
          MESES_PREV(I) = MES_ATUAL
100   CONTINUE
      
      RETURN
      END
      
C     Funcao para determinar se um ano e bissexto
      LOGICAL FUNCTION BISSEXTO(ANO)
      INTEGER ANO
      
      BISSEXTO = .FALSE.
      IF (MOD(ANO,4) .EQ. 0) THEN
          IF (MOD(ANO,100) .NE. 0 .OR. MOD(ANO,400) .EQ. 0) THEN
              BISSEXTO = .TRUE.
          END IF
      END IF
      
      RETURN
      END
      
C     Funcao para obter o numero de dias em um mes/ano
      INTEGER FUNCTION DIAS_NO_MES(MES, ANO)
      INTEGER MES, ANO
      INTEGER DIAS_MES(12)
      LOGICAL BISSEXTO
      
      DATA DIAS_MES /31,28,31,30,31,30,31,31,30,31,30,31/
      
      DIAS_NO_MES = DIAS_MES(MES)
      IF (MES .EQ. 2 .AND. BISSEXTO(ANO)) THEN
          DIAS_NO_MES = 29
      END IF
      
      RETURN
      END
      
      SUBROUTINE CALC_MESES_SEMANAIS(DIA, MES, ANO, N_SEMANAS, 
     *  MESES_PREV)
C     ---------------------------------------------------------
C     Subrotina para calcular os meses das previsoes semanais
C     Cada previsao semanal usa o desvio padrao do primeiro dia da semana
C
C     Input:
C        DIA        - Dia inicial (ultimo dia observado)
C        MES        - Mes inicial
C        ANO        - Ano inicial
C        N_SEMANAS  - Numero de semanas de previsao
C
C     Output:
C        MESES_PREV - Vetor com os meses do primeiro dia de cada semana
C
C     Autor: Adaptado para FORTRAN 77
C     ---------------------------------------------------------
      INTEGER*2 DIA, MES, ANO, N_SEMANAS
      INTEGER MESES_PREV(N_SEMANAS)
      INTEGER DIA_ATUAL, MES_ATUAL, ANO_ATUAL
      INTEGER I, DIAS_NO_MES
      LOGICAL BISSEXTO
      
C     Inicializa variaveis com a data inicial
      DIA_ATUAL = DIA
      MES_ATUAL = MES
      ANO_ATUAL = ANO
      
C     Loop sobre as semanas de previsao
      DO 100 I = 1, N_SEMANAS
C         Avanca 7 dias (uma semana)
          DIA_ATUAL = DIA_ATUAL + 7
          
C         Ajusta mes e ano se necessario
200       CONTINUE
          IF (DIA_ATUAL .GT. DIAS_NO_MES(MES_ATUAL, ANO_ATUAL)) THEN
              DIA_ATUAL = DIA_ATUAL - DIAS_NO_MES(MES_ATUAL, ANO_ATUAL)
              MES_ATUAL = MES_ATUAL + 1
              
              IF (MES_ATUAL .GT. 12) THEN
                  MES_ATUAL = 1
                  ANO_ATUAL = ANO_ATUAL + 1
              END IF
              
              GO TO 200
          END IF
          
C         Armazena o mes correspondente ao primeiro dia desta semana
          MESES_PREV(I) = MES_ATUAL
100   CONTINUE
      
      RETURN
      END
