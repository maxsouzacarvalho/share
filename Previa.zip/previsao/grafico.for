
      subroutine grafico(y,yp,smooth_y,L95,n1,d2,nant,dpmesp,
     * ymin,ymax,viesp,ym,my)
      !DEC$ boundscheck
      
      include  'paramprev.dim' 
      dimension y(nmd), yp(nmp), smooth_y(nmd),dpmesp(nmp)
      dimension viesp(nmp),ym(nmp),my(nmp)
      real L95(nmp),fator(nmp),ymin,ymax
      integer*2 n1,d2,nant

      
      write(12,*)'<canvas id="myChart" width="50" height="10"></canvas>'
      write(12,*) ''
      write(12,*) '    <script>'
      write(12,*) '        // Dados j� existentes'
      write(12,*) '       const y1 = ['
      write(12,*)(nint(y(i)),',',i=n1-nant+1, n1)
      write(12,*)']; // Primeiros dados (linha vermelha)'
      write(12,*) '       const y2 = ['
      write(12,*)y(n1),',',(nint(yp(i)),',',i=1, d2)
      write(12,*)']; // Linha azul claro'
      write(12,*) '       const y3 = ['
      write(12,*)y(n1),',',(nint(smooth_y(n1+i)),',',i=1, d2)
      write(12,*)']; // Linha azul'
      
      write(12,*) '       const y7 = ['
      write(12,*)y(n1),',',(nint(ym(i)),',',i=1, d2)
      write(12,*)']; // Linha cinza'
      
      write(12,*) '       const y4 = ['
      do j = 1, d2
          !fator(j) = smooth_y(n1+j)+(dpmesp(j)*1.96)
          fator(j) = yp(j)+(dpmesp(j)*1.96)
          if (fator(j).gt.ymax)fator(j)=ymax
      end do      
      write(12,*)y(n1),',',(nint(fator(i)),',',i=1,d2)          
      write(12,*)']; // Linha verde'
      
      write(12,*) '       const y5 = ['
      do j = 1, d2
          !fator(j) = smooth_y(n1+j)-(dpmesp(j)*1.96)
          fator(j) = yp(j)-(dpmesp(j)*1.96)
          if (fator(j).lt.ymin)fator(j)=ymin
      end do
      write(12,*)y(n1),',',(nint(fator(i)),',',i=1,d2)
      
      write(12,*)']; // Linha purpura'
      write(12,*) '       const y6 = ['
      do j = 1, d2
          if (viesp(j).ne.(-1))then
              fator(j) = smooth_y(n1+j)/(1+viesp(j))
          else
              fator(j) = smooth_y(n1+j)
          end if
          if (fator(j).lt.ymin)fator(j)=ymin
      end do          
      write(12,*)y(n1),',',(nint(fator(i)),',',i=1,d2)      
      
      write(12,*)']; // Linha amarela'
      write(12,*) ''
      write(12,*) '   // Labels para o eixo X (podem ser personalizad
     *os)'
      write(12,*) '        const labels = Array.from({ length: y1.length
     * + y2.length-1}, (_, i) => `t ${i - y1.length+1}`);'
      write(12,*) ''
      write(12,*) '        // Configura��o do gr�fico'
      write(12,*) '        const ctx = document.getElementById("myChart"
     *).getContext("2d");'
      write(12,*) '        const myChart = new Chart(ctx, {'
      write(12,*) '            type: "line",'
      write(12,*) '            data: {'
      write(12,*) '                labels: labels,'
      write(12,*) '                datasets: ['
      write(12,*) '                    {'
      write(12,*) '                        label: "Dados Observados",'
      write(12,*) '                       data: [...y1, ...Array(y1.leng
     *th-1).fill(null)],'
      write(12,*) '                        borderColor: "red",'
      write(12,*) '                        borderWidth: 2,'
      write(12,*) '                        fill: false,'
      write(12,*) '                    },'
      write(12,*) '                    {'
      write(12,*) '                        label: "Previs�o Bruta",'
      write(12,*) '                        data: [...Array(y2.length-2).
     *fill(null), ...y2],'
      write(12,*) '                        borderColor: "lightblue",'
      write(12,*) '                        borderWidth: 2,'
      write(12,*) '                        hidden: false,'
      write(12,*) '                        fill: false,'
      write(12,*) '                    },'
      write(12,*) '                    {'
      write(12,*) '                        label: "Previs�o Suavizada",'
      write(12,*) '                        data: [...Array(y3.length-2).
     *fill(null), ...y3],'
      write(12,*) '                        borderColor: "blue",'
      write(12,*) '                        borderWidth: 2,'
      write(12,*) '                        fill: false,'
      write(12,*) '                    },'
      write(12,*) '                    {'
      write(12,*) '                        label: "Previs�o M�dia",'
      write(12,*) '                        data: [...Array(y7.length-2).
     *fill(null), ...y7],'
      write(12,*) '                        borderColor: "grey",'
      write(12,*) '                        borderWidth: 2,'
      write(12,*) '                        fill: false,'
      write(12,*) '                    },'      
      write(12,*) '                    {'
      write(12,*) '                        label: "Remo��o de Vi�s",'
      write(12,*) '                        data: [...Array(y6.length-2).
     *fill(null), ...y6],'
      write(12,*) '                        borderColor: "purple",'
      write(12,*) '                        borderWidth: 2,'
      write(12,*) '                        fill: false,'
      write(12,*) '                    },'
      write(12,*) '                    {'      
      write(12,*) '                       label: "Limite Superior 95%",'
      write(12,*) '                        data: [...Array(y4.length-2).
     *fill(null), ...y4],'
      write(12,*) '                        borderColor: "green",'
      write(12,*) '                        borderWidth: 1,'
      write(12,*) '       backgroundColor: "rgba(144, 238, 144, 0.1)",'
      write(12,*) '                        fill:"+1",'
      write(12,*) '                        tension: 0.4'
      write(12,*) '                    },'
      write(12,*) '                    {'
      write(12,*) '                       label: "Limite Inferior 95%",'
      write(12,*) '                        data: [...Array(y5.length-2).
     *fill(null), ...y5],'
      write(12,*) '                        borderColor: "orange",'
      write(12,*) '                        borderWidth: 1,'
      write(12,*) '       backgroundColor: "rgba(144, 238, 144, 0.1)",'
      write(12,*) '                        fill:"-1",'
      write(12,*) '                        tension: 0.4'
      write(12,*) '                    }'
      write(12,*) '                ]'
      write(12,*) '            },'
      write(12,*) '            options: { '
      write(12,*) '              responsive: true,'
      write(12,*) '              maintainAspectRatio: true,'
      write(12,*) '                scales: {'
      write(12,*) '                    y: {'
      write(12,*) '                        beginAtZero: false'
      write(12,*) '                    }'
      write(12,*) '                }'
      write(12,*) '            }'
      write(12,*) '        });'
      write(12,*) '    </script>'

      
      end