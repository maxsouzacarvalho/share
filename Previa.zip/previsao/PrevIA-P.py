import tkinter as tk  
from tkinter import *
from posixpath import curdir
import easygui
import os
import subprocess
import sys
from sys import *
from tkinter import messagebox
import shutil
from pathlib import Path


window = tk.Tk()

global arqq 
global arqq2
global tiparq
global tipper
global arqlabel2
global arqlabel1

# Obtém o caminho do executável ou do script
if getattr(sys, 'frozen', False):
    # Se estiver rodando como executável (empacotado)
    application_path = Path(sys.executable).parent
else:
    # Se estiver rodando como script Python
    application_path = Path(__file__).parent
# Configura a pasta de trabalho para o diretório do executável/script
os.chdir(application_path)


window.title('PrevIA-P 2.9.0')
window.geometry("640x550+10+10")
window.iconbitmap('config/previa.ico')
window.resizable(width=True, height=True)

def openNewWindow():
  def clickedImpCoef():
   padrao = str(arqlabel1.get())
   txtCoef.delete(0,END)
   pathcoef = easygui.fileopenbox(msg=padrao,default="dados/*.txt")
   pathtest= str(pathcoef)
   if not os.path.isfile(pathtest):
     return   
   txtCoef.insert(END,pathcoef)

  def clickedImpConf():
   padrao = str(arqlabel2.get())
   txtConf.delete(0,END)
   pathconf = easygui.fileopenbox(msg=padrao,default="dados/*.txt")
   pathtest= str(pathconf)
   if not os.path.isfile(pathtest):
     return
   txtConf.insert(END,pathconf)


  def importaja():
   arq=arqq.get()  
   arq2=arqq2.get()
      
   dest = arq+"old"
   if os.path.isfile(dest):
     os.remove(dest)
   if os.path.isfile(arq):
     os.rename(arq,dest)

   dest = arq2+"old"
   if os.path.isfile(dest):
     os.remove(dest)
   if os.path.isfile(arq2):   
     os.rename(arq2,dest)

   pathcoef=txtCoef.get()
   pathconf=txtConf.get()  
   shutil.copyfile(pathcoef, arq)
   shutil.copyfile(pathconf,arq2)
   messagebox.showinfo("Aviso", "Importado!")
   newW.destroy()

  pegadadoradio() 

  t1= tiparq.get()
  
  t2= tipper.get()
  

  ok=messagebox.askokcancel("Importar configurações","Importar configurações para\n"+t1+" "+t2+"?")
  if not ok:
    return

  newW = Toplevel() 
  newW.title("Importar dados de calibração")    
  newW.geometry("525x300+10+10")
  newW.iconbitmap('config/previa.ico')

  lbl=Label(newW, textvariable=tiparq, font=("Courier",12,'bold'),bg="lightyellow")
  lbl.place(x=10, y=80)
  lbl=Label(newW, textvariable=tipper, font=("Courier",12,'bold'),bg="lightyellow")
  lbl.place(x=10, y=100)

  lbl=Label(newW, text="Arquivo de coeficientes: ", font=("Courier",10))
  lbl.place(x=10, y=130)
  lbl=Label(newW, textvariable=arqlabel1, font=("Courier",10))
  lbl.place(x=210, y=130)
  txtCoef=Entry(newW, text="", width="75")
  txtCoef.place(x=10, y=150)
  btnImpCoef=Button(newW,command=clickedImpCoef, image=busca,width=20,height=20)
  btnImpCoef.place(x=480, y=145)
  
  lbl=Label(newW, text="Arquivo de configuração: ", font=("Courier",10))
  lbl.place(x=10, y=190)
  lbl=Label(newW, textvariable=arqlabel2, font=("Courier",10))
  lbl.place(x=210, y=190)
  txtConf=Entry(newW, text="", width="75")
  txtConf.place(x=10, y=210)
  btnImpConf=Button(newW,command=clickedImpConf, image=busca,width=20,height=20)
  btnImpConf.place(x=480, y=205)
  lbl=Label(newW, text="Importar PrevIA-P", font=("Courier",20,'bold'),relief="ridge",width="30",bg="lightblue")
  lbl.place(x=18,y=10)
  lbl=Label(newW, text="Modelo de Redes Neurais para Previsão de Vazões", font=("Courier",10), width="50")
  lbl.place(x=40, y=50)

  btnImpJa=Button(newW,command=importaja, text="Importar",font=("Courier", 10),width=10,bg='lightgrey')
  btnImpJa.place(x=10, y=240)
  btnFechaImp=Button(newW,command=newW.destroy, text="Fechar",font=("Courier", 10),width=10,bg='lightgrey')
  btnFechaImp.place(x=110, y=240)

def lercsv1(vpath2):
  arquivo1=open("Varx.txt","w+")
  arquivo2=open(vpath2, "r")
  for l in arquivo2:
      l=l.strip()
      l=l.replace(',','.')
      l=l.replace(';',',')
      arquivo1.write(l+"\n")  
  arquivo2.close()
  arquivo1.close()

def resultado():
 messagebox.showwarning("Lembrete:", "Imprima ou salve o arquivo de resultados em sua pasta!")
 os.startfile("relat\\relatprev.html")

def planilha():
 messagebox.showwarning("Lembrete:", "Imprima ou salve o arquivo de resultados em sua pasta!")
 os.startfile("plan\\relatprev.csv")

def rodar():

 btnresult["state"]="disabled"
 btnplan["state"]="disabled" 

 txtRun.delete("1.0","end")
 txtRun.insert(END,"  AGUARDE...\n")
 txtRun.update_idletasks()

 p=os.popen("P.exe") 

 for l in p:
   txtRun.insert(END,l)
   txtRun.update_idletasks()

 btnresult["state"]="active"
 btnplan["state"]="active"      


########## PEGADA DO RADIO PARA PASSAR PARA NEWWINDOW
def pegadadoradio():
 tipo=v1.get()
 reserv=v0.get()
 periodo=v3.get()

 if periodo==1:
   tipper.set("Período Úmido")
   arqlabel1.set("COEFU.TXT")
   arqlabel2.set("CONFIGU.TXT")
 if periodo==2:
   tipper.set("Período Seco")
   arqlabel1.set("COEFS.TXT")
   arqlabel2.set("CONFIGS.TXT")
 if periodo==3:
   tipper.set("Período Total") 
   arqlabel1.set("COEFT.TXT")
   arqlabel2.set("CONFIGT.TXT")
 if tipo==1:
   if reserv==1:
    tiparq.set("Sobradinho Mensal")
    if periodo==1:
      arqq.set("config\\coefusbmu")
      arqq2.set("config\\configusbmu")      
    if periodo==2:
      arqq.set("config\\coefusbms")
      arqq2.set("config\\configusbms")      
    if periodo==3:
      arqq.set("config\\coefusbmt")
      arqq2.set("config\\configusbmt")        
   if reserv==2:
    tiparq.set("Itapatica Mensal")
    if periodo==1:
     arqq.set("config\\coefuitmu")
     arqq2.set("config\\configuitmu")   
    if periodo==2:
     arqq.set("config\\coefuitms")
     arqq2.set("config\\configuitms")     
    if periodo==3:
     arqq.set("config\\coefuitmt")
     arqq2.set("config\\configuitmt")                 
   if reserv==3:
    tiparq.set("Boa Esperança Mensal")
    if periodo==1:
     arqq.set("config\\coefubemu")
     arqq2.set("config\\configubemu")     
    if periodo==2:
     arqq.set("config\\coefubems")
     arqq2.set("config\\configubems")     
    if periodo==3:
     arqq.set("config\\coefubemt")
     arqq2.set("config\\configubemt")       
   if reserv==4:
    tiparq.set("Pedra Mensal")
    if periodo==1:
      arqq.set("config\\coefupemu")
      arqq2.set("config\\configupemu")      
    if periodo==2:
      arqq.set("config\\coefupems")
      arqq2.set("config\\configupems")      
    if periodo==3:
      arqq.set("config\\coefupemt")
      arqq2.set("config\\configupemt")
   if reserv==5:
    tiparq.set("Três Marias Mensal")
    if periodo==1:
      arqq.set("config\\coefutmmu")
      arqq2.set("config\\configutmmu")      
    if periodo==2:
      arqq.set("config\\coefutmms")
      arqq2.set("config\\configutmms")      
    if periodo==3:
      arqq.set("config\\coefutmmt")
      arqq2.set("config\\configutmmt")                        
 if tipo==2:
   if reserv==1:
    tiparq.set("Sobradinho Semanal")
    if periodo==1:
     arqq.set("config\\coefusbsu")
     arqq2.set("config\\configusbsu")     
    if periodo==2:
     arqq.set("config\\coefusbss")
     arqq2.set("config\\configusbss")       
    if periodo==3:
     arqq.set("config\\coefusbst")
     arqq2.set("config\\configusbst")               
   if reserv==2:
    tiparq.set("Itapatica Semanal")
    if periodo==1:
     arqq.set("config\\coefuitsu")
     arqq2.set("config\\configuitsu")     
    if periodo==2:
     arqq.set("config\\coefuitss")
     arqq2.set("config\\configuitss")     
    if periodo==3:
     arqq.set("config\\coefuitst")
     arqq2.set("config\\configuitst")              
   if reserv==3:
    tiparq.set("Boa Esperança Semanal")
    if periodo==1:
     arqq.set("config\\coefubesu")
     arqq2.set("config\\configubesu")     
    if periodo==2:
     arqq.set("config\\coefubess")
     arqq2.set("config\\configubess")     
    if periodo==3:
     arqq.set("config\\coefubest")
     arqq2.set("config\\configubest")              
   if reserv==4:
    tiparq.set("Pedra Semanal")
    if periodo==1:
     arqq.set("config\\coefupesu")
     arqq2.set("config\\configupesu")     
    if periodo==2:
     arqq.set("config\\coefupess")
     arqq2.set("config\\configupess")       
    if periodo==3:
     arqq.set("config\\coefupest")
     arqq2.set("config\\configupest")           
 if tipo==3:
   if reserv==1:
    tiparq.set("Sobradinho Diária")
    if periodo==1:
     arqq.set("config\\coefusbdu")
     arqq2.set("config\\configusbdu")     
    if periodo==2:
     arqq.set("config\\coefusbds")
     arqq2.set("config\\configusbds")          
    if periodo==3:
     arqq.set("config\\coefusbdt")
     arqq2.set("config\\configusbdt")              
   if reserv==2:
    tiparq.set("Itapatica Diária")
    if periodo==1:
     arqq.set("config\\coefuitdu")
     arqq2.set("config\\configuitdu") 
    if periodo==2:
     arqq.set("config\\coefuitds")
     arqq2.set("config\\configuitds")
    if periodo==3:
     arqq.set("config\\coefuitdt")
     arqq2.set("config\\configuitdt")       
   if reserv==3:
    tiparq.set("Boa Esperança Diária")
    if periodo==1:
     arqq.set("config\\coefubedu")
     arqq2.set("config\\configubedu")
    if periodo==2:
     arqq.set("config\\coefubeds")
     arqq2.set("config\\configubeds")
    if periodo==3:
     arqq.set("config\\coefubedt")
     arqq2.set("config\\configubedt")       
   if reserv==4:
    tiparq.set("Pedra Diária")
    if periodo==1:
     arqq.set("config\\coefupedu")
     arqq2.set("config\\configupedu")
    if periodo==2:
     arqq.set("config\\coefupeds")
     arqq2.set("config\\configupeds")
    if periodo==3:
     arqq.set("config\\coefupedt")
     arqq2.set("config\\configupedt")


def transfere(arquivo):
 tipo=v1.get()
 reserv=v0.get()
 periodo=v3.get()

 if tipo==1:   
   if reserv==1:
  ##print("Sobradinho Mensal")
    if periodo==1:
      arq="config\\coefusbmu"
      arq2="config\\configusbmu"
      arquivo.write(" 1 1")
    if periodo==2:
      arq="config\\coefusbms"
      arq2="config\\configusbms"
      arquivo.write(" 1 1")
    if periodo==3:
      arq="config\\coefusbmt"
      arq2="config\\configusbmt"
      arquivo.write(" 1 1")  
   if reserv==6:
  ##print("Sobradinho Incremental Mensal")
    if periodo==1:
      arq="config\\coefusbimu"
      arq2="config\\configusbimu"
      arquivo.write(" 1 6")
    if periodo==2:
      arq="config\\coefusbims"
      arq2="config\\configusbims"
      arquivo.write(" 1 6")
    if periodo==3:
      arq="config\\coefusbimt"
      arq2="config\\configusbimt"
      arquivo.write(" 1 6")        
   if reserv==2:
  ##print("Itapatica Mensal")
    if periodo==1:
     arq="config\\coefuitmu"
     arq2="config\\configuitmu"
     arquivo.write(" 1 2")
    if periodo==2:
     arq="config\\coefuitms"
     arq2="config\\configuitms"
     arquivo.write(" 1 2")
    if periodo==3:
     arq="config\\coefuitmt"
     arq2="config\\configuitmt"
     arquivo.write(" 1 2")            
   if reserv==3:
  ##print("Boa Esperança Mensal")
    if periodo==1:
     arq="config\\coefubemu"
     arq2="config\\configubemu"
     arquivo.write(" 1 3")
    if periodo==2:
     arq="config\\coefubems"
     arq2="config\\configubems"
     arquivo.write(" 1 3")
    if periodo==3:
     arq="config\\coefubemt"
     arq2="config\\configubemt"
     arquivo.write(" 1 3")     
   if reserv==4:
  ##print("Pedra Mensal")
    if periodo==1:
      arq="config\\coefupemu"
      arq2="config\\configupemu"
      arquivo.write(" 1 4")
    if periodo==2:
      arq="config\\coefupems"
      arq2="config\\configupems"
      arquivo.write(" 1 4")
    if periodo==3:
      arq="config\\coefupemt"
      arq2="config\\configupemt"
      arquivo.write(" 1 4")       
   if reserv==5:
  ##print("Três Marias Mensal")
    if periodo==1:
      arq="config\\coefutmmu"
      arq2="config\\configutmmu"
      arquivo.write(" 1 5")
    if periodo==2:
      arq="config\\coefupems"
      arq2="config\\configutmms"
      arquivo.write(" 1 5")
    if periodo==3:
      arq="config\\coefutmmt"
      arq2="config\\configutmmt"
      arquivo.write(" 1 5")                
 if tipo==2:
   if reserv==1:
  #print("Sobradinho Semanal")
    if periodo==1:
     arq="config\\coefusbsu"
     arq2="config\\configusbsu"
     arquivo.write(" 2 1")
    if periodo==2:
     arq="config\\coefusbss"
     arq2="config\\configusbss"
     arquivo.write(" 2 1")  
    if periodo==3:
     arq="config\\coefusbst"
     arq2="config\\configusbst"
     arquivo.write(" 2 1") 
   if reserv==1:
  #print("Sobradinho incremenal Semanal")
    if periodo==1:
     arq="config\\coefusbisu"
     arq2="config\\configusbisu"
     arquivo.write(" 2 6")
    if periodo==2:
     arq="config\\coefusbiss"
     arq2="config\\configusbiss"
     arquivo.write(" 2 6")  
    if periodo==3:
     arq="config\\coefusbist"
     arq2="config\\configusbist"
     arquivo.write(" 2 6")                
   if reserv==2:
  #print("Itapatica Semanal")
    if periodo==1:
     arq="config\\coefuitsu"
     arq2="config\\configuitsu"
     arquivo.write(" 2 2")
    if periodo==2:
     arq="config\\coefuitss"
     arq2="config\\configuitss"
     arquivo.write(" 2 2") 
    if periodo==3:
     arq="config\\coefuitst"
     arq2="config\\configuitst"
     arquivo.write(" 2 1")          
   if reserv==3:
  #print("Boa Esperança Semanal")
    if periodo==1:
     arq="config\\coefubesu"
     arq2="config\\configubesu"
     arquivo.write(" 2 3")
    if periodo==2:
     arq="config\\coefubess"
     arq2="config\\configubess"
     arquivo.write(" 2 3") 
    if periodo==3:
     arq="config\\coefubest"
     arq2="config\\configubest"
     arquivo.write(" 2 3")          
   if reserv==4:
  #print("Pedra Semanal")
    if periodo==1:
     arq="config\\coefupesu"
     arq2="config\\configupesu"
     arquivo.write(" 2 4")
    if periodo==2:
     arq="config\\coefupess"
     arq2="config\\configupess"
     arquivo.write(" 2 4")   
    if periodo==3:
     arq="config\\coefupest"
     arq2="config\\configupest"
     arquivo.write(" 2 4")        
 if tipo==3:
   if reserv==1:
  #print("Sobradinho Diária")
    if periodo==1:
     arq="config\\coefusbdu"
     arq2="config\\configusbdu"
     arquivo.write(" 3 1")
    if periodo==2:
     arq="config\\coefusbds"
     arq2="config\\configusbds"
     arquivo.write(" 3 1")      
    if periodo==3:
     arq="config\\coefusbdt"
     arq2="config\\configusbdt"
     arquivo.write(" 3 1")        
  #print("Sobradinho Incremental Diária")
    if periodo==1:
     arq="config\\coefusbidu"
     arq2="config\\configusbidu"
     arquivo.write(" 3 6")
    if periodo==2:
     arq="config\\coefusbids"
     arq2="config\\configusbids"
     arquivo.write(" 3 6")      
    if periodo==3:
     arq="config\\coefusbidt"
     arq2="config\\configusbidt"
     arquivo.write(" 3 6")           
   if reserv==2:
  #print("Itapatica Diária")
    if periodo==1:
     arq="config\\coefuitdu"
     arq2="config\\configuitdu"
     arquivo.write(" 3 2")
    if periodo==2:
     arq="config\\coefuitds"
     arq2="config\\configuitds"
     arquivo.write(" 3 2") 
    if periodo==3:
     arq="config\\coefuitdt"
     arq2="config\\configuitdt"
     arquivo.write(" 3 2")          
   if reserv==3:
  #print("Boa Esperança Diária")
    if periodo==1:
     arq="config\\coefubedu"
     arq2="config\\configubedu"
     arquivo.write(" 3 3")
    if periodo==2:
     arq="config\\coefubeds"
     arq2="config\\configubeds"
     arquivo.write(" 3 3") 
    if periodo==3:
     arq="config\\coefubedt"
     arq2="config\\configubedt"
     arquivo.write(" 3 3")         
   if reserv==4:
  #print("Pedra Diária")
    if periodo==1:
     arq="config\\coefupedu"
     arq2="config\\configupedu"
     arquivo.write(" 3 4")
    if periodo==2:
     arq="config\\coefupeds"
     arq2="config\\configupeds"
     arquivo.write(" 3 4")
    if periodo==3:
     arq="config\\coefupedt"
     arq2="config\\configupedt"
     arquivo.write(" 3 4")     
 if periodo==1:
     arquivo.write("\n 1")
 if periodo==2:
     arquivo.write("\n 2")
 if periodo==3:
     arquivo.write("\n 3")          

 arquivo.close()

 shutil.copyfile(arq, "coef.txt")
 shutil.copyfile(arq2, "config.txt")

# os.system("copy {} coef.txt  ".format(arq))
# os.system("copy {} config.txt  ".format(arq2))


def clicked():
    txtfld.delete(0,END)
    vpath2 = easygui.fileopenbox(msg="Arquivo de dados CSV",default="dados/*.csv")
    vpatht=str(vpath2)
    if not os.path.isfile(vpatht):
      btn["state"]='disabled'
      mensalRd["state"]='disabled'
      diariaRd["state"]='disabled'
      semanalRd["state"]='disabled'
      uitRd["state"]='disabled'
      usbRd["state"]='disabled'
      usb2Rd["state"]='disabled'
      upeRd["state"]='disabled'
      ubeRd["state"]='disabled'
      utmRd["state"]='disabled'  
      btnroda["state"]='disabled'
      PuRd["state"]='disabled'
      PsRd["state"]='disabled'
      PtRd["state"]='disabled'
      #Usaprev2["state"]='disabled'
      return    
    txtfld.insert(END,vpath2)
    
    btn["state"]=ACTIVE
    mensalRd["state"]=ACTIVE
    diariaRd["state"]=ACTIVE
    semanalRd["state"]=ACTIVE
    uitRd["state"]=ACTIVE
    usbRd["state"]=ACTIVE
    usb2Rd["state"]=ACTIVE
    upeRd["state"]=ACTIVE
    ubeRd["state"]=ACTIVE
    utmRd["state"]=ACTIVE  
    btnroda["state"]=ACTIVE
    PuRd["state"]=ACTIVE
    PsRd["state"]=ACTIVE
    PtRd["state"]=ACTIVE
    #Usaprev2["state"]=ACTIVE

def ajuda():
  os.startfile('config\\ajudaprev.html')

def escolhe():
  lbl.configure(text="teste")

def escreve():

  vpath2=txtfld.get()
  lercsv1(vpath2)
  asc1=(asc.get()) 
  dsc1=(dsc.get())
  arquivo = open("temp.txt", "w")
  arquivo.write(asc1)
  arquivo.write("  ")
  arquivo.write(dsc1)
  arquivo.write("  ")
  iprev = (v6.get())
  if iprev==1:   #se vai usar previsão pra prever ou não
    arquivo.write("1")
  else:
    arquivo.write("0")
  transfere(arquivo)
  rodar()

def chekimp():
 v = v4.get()
 if v==1:
   btnImpCal["state"]='active'
   mensalRd["state"]=ACTIVE
   diariaRd["state"]=ACTIVE
   semanalRd["state"]=ACTIVE
   uitRd["state"]=ACTIVE
   usbRd["state"]=ACTIVE
   usb2Rd["state"]=ACTIVE
   upeRd["state"]=ACTIVE
   ubeRd["state"]=ACTIVE
   utmRd["state"]=ACTIVE
   PuRd["state"]=ACTIVE
   PsRd["state"]=ACTIVE
   PtRd["state"]=ACTIVE
   btnbusca["state"]='disabled'
   btnroda["state"]='disabled'

 if v==0:
   btnImpCal["state"]='disabled'
   mensalRd["state"]='disabled'
   diariaRd["state"]='disabled'
   semanalRd["state"]='disabled'
   uitRd["state"]='disabled'
   usbRd["state"]='disabled'
   usb2Rd["state"]='disabled'
   upeRd["state"]='disabled'
   ubeRd["state"]='disabled'
   utmRd["state"]='disabled'
   PuRd["state"]='disabled'
   PsRd["state"]='disabled'
   PtRd["state"]='disabled'
   btnbusca["state"]=ACTIVE
   if not txtfld.get() == '':
    btnroda["state"]=ACTIVE 
  

def seltempo():
  rtipo = v0.get()
  
  if rtipo==5:
    mensalRd["state"]='active'
    semanalRd["state"]='disabled'
    diariaRd ["state"]='disabled'
    v1.set(1)
  else:    
    mensalRd["state"]='active'
    semanalRd["state"]='active'
    diariaRd ["state"]='active'  


global vpath2

asc = tk.StringVar()  
dsc = tk.StringVar()
arqq=tk.StringVar()
arqq2=tk.StringVar()
tiparq = tk.StringVar()
tipper = tk.StringVar()
arqlabel1=tk.StringVar()
arqlabel2=tk.StringVar()

busca = PhotoImage(file=r"config/buscap")

btnbusca=Button(window,bg='lightgrey',command=clicked, image=busca,width=20,height=20)
btnbusca.place(x=590, y=135)
lbl=Label(window, text="Arquivo '.csv' com os 100 últimos dados observados", font=("Courier",10))
lbl.place(x=10, y=120)
txtfld=Entry(window, text="Ultimos dados", width="95")
txtfld.place(x=10, y=140)

v6 = IntVar()
#Usaprev2 = Checkbutton(window, text="Usar previsão 1\npara prever", variable=v6,font=("Courier",10),state="disabled",onvalue=1,offvalue=0)
#Usaprev2.place(x=400, y=260)

v1 = IntVar()
v1.set(3)
lbl=Label(window, text="Passo de tempo:", font=("Courier",10))
lbl.place(x=10, y=250)
mensalRd = Radiobutton(window, text="Mensal", variable=v1, value=1,font=("Courier",10),state="disabled")
semanalRd = Radiobutton(window, text="Semanal", variable=v1, value=2,font=("Courier",10),state="disabled")
diariaRd = Radiobutton(window, text="Diária", variable=v1, value=3,font=("Courier",10),state="disabled")
mensalRd.place(x=270, y=270)
semanalRd.place(x=140, y=270)
diariaRd.place(x=10, y=270)
v0 = IntVar()
v0.set(1)
lbl=Label(window, text="Reservatório:", font=("Courier",10))
lbl.place(x=10, y=170)
usbRd = Radiobutton(window, text="Sobradinho", variable=v0, value=1,font=("Courier",10),state="disabled",command=seltempo)
uitRd = Radiobutton(window, text="Itaparica", variable=v0, value=2,font=("Courier",10),state="disabled",command=seltempo)
ubeRd = Radiobutton(window, text="Boa Esperança", variable=v0, value=3,font=("Courier",10),state="disabled",command=seltempo)
upeRd = Radiobutton(window, text="Pedra", variable=v0, value=4,font=("Courier",10),state="disabled",command=seltempo)
utmRd = Radiobutton(window, text="Três Marias", variable=v0, value=5,font=("Courier",10),state="disabled",command=seltempo)
usb2Rd = Radiobutton(window, text="Incremental Sobradinho", variable=v0, value=6,font=("Courier",10),state="disabled",command=seltempo)
usbRd.place(x=10, y=190)
uitRd.place(x=140, y=190)
ubeRd.place(x=270, y=190)
upeRd.place(x=420, y=190)
utmRd.place(x=510, y=190)
usb2Rd.place(x=10, y=220)

lbl=Label(window, text="PrevIA-P", font=("Courier",20,'bold'),relief="ridge",width="37",bg='lightblue')
lbl.place(x=18,y=10)
lbl=Label(window, text="Modelo de Redes Neurais para Previsão de Vazões", font=("Courier",10), width="74",background="#d3d3d3")
lbl.place(x=18, y=50)

btnroda=Button(window,bg='lightgrey',text="Previsão",state="disabled",width="13", command=escreve,font=("Courier",10))
btnroda.place(x=10,y=420)

btnresult=Button(window,bg='lightgrey',text="Resultado",state="disabled",width="13",command=resultado,font=("Courier",10))
btnresult.place(x=10,y=450)
btnplan=Button(window,bg='lightgrey',text="Planilha",state="disabled",width="13",command=planilha,font=("Courier",10))
btnplan.place(x=10,y=480)

lbl=Label(window, text="Calibrado para:", font=("Courier",10))
lbl.place(x=10, y=305)
v3 = IntVar()
v3.set(3)
PuRd = Radiobutton(window, text="Período Úmido", variable=v3, value=1,font=("Courier",10),state="disabled")
PsRd = Radiobutton(window, text="Período Seco", variable=v3, value=2,font=("Courier",10),state="disabled") 
PtRd = Radiobutton(window, text="Período Total", variable=v3, value=3,font=("Courier",10),state="disabled") 
PuRd.place(x=290, y=330)
PsRd.place(x=160, y=330)
PtRd.place(x=10, y=330)

v4 = IntVar()
ImpCalChk = Checkbutton(window, text="Importar Calibração", variable=v4,font=("Courier",10),state="active",onvalue=1,offvalue=0,command=chekimp)
ImpCalChk.place(x=150,y=420)
btnImpCal=Button(window,bg='lightgrey',text="Importa Calibração",state="disabled",width="20",font=("Courier",10),command=openNewWindow)
btnImpCal.place(x=150,y=450)

btn=Button(window,bg='lightgrey',text="Fechar",state="active",width=8,command=window.destroy,font=("Courier",10))
btn.place(x=150,y=480)
btn=Button(window,bg='lightgrey',text="Ajuda",state="active",width=8,command=ajuda,font=("Courier",10))
btn.place(x=246,y=480)

#escreve = partial(escreve,asc,dsc) 

lbl2=Label(window,text="Taxa de Ascensão (%):",font=("Courier",10))
lbl2.place(x=10,y=370)
txtasc=Entry(window,width="10",textvariable=asc)
txtasc.place(x=190, y=370)
txtasc.insert(END,"10000")
lbl2=Label(window,text="Taxa de Recessão (%):",font=("Courier",10)) 
lbl2.place(x=320,y=370)
txtdsc=Entry(window,width="10",textvariable=dsc)
txtdsc.place(x=500, y=370)
txtdsc.insert(END,"10000")

txtRun=Text(window,font=("Courier",10),height=5,width=30)
txtRun.insert(END,"EVOLUÇÃO")
txtRun.place(x=362,y=420)

dir = './relat'
if os.path.isdir(dir):
    a=1
else:       
    os.mkdir(dir)
  
dir = './plan'
if os.path.isdir(dir):
    a=1
else:       
    os.mkdir(dir)
  
dir = './config'
if os.path.isdir(dir):
    a=1
else:       
    os.mkdir(dir)

# Create Label and add some text
Lower_left = Label(window,text ='Desenvolvido pelo Centro de Pesquisas de Energia Elétrica - CEPEL',
                        borderwidth = 2,
                        background="#d3d3d3")
 
# using place method we can set the position of label
Lower_left.place(relx = 0.01,
                 rely = 0.99,
                 anchor ='sw')


window.mainloop()