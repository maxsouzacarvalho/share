        subroutine chamasorede(nprev,sigla,titcaso,iopt,p,ngraf,
     *  imix,titteste,icam)
        include 'paramrede.dim'
        dimension zz(mmax),itree(10,nmm),tree(10,nmm,6),zprev(nmp)
        dimension itr(2*nmm),y(nmd),smooth_y(nmd),yp(nmd),ym(nmd)
        dimension dpmes(12), vies_mensal(12)
        real L95,yy,maxx(mmax),minx(mmax),amax,amin
        integer*2 i,iopt,nprev,m1,m,icam,d2,limes(nmd)
        character*2 xnome
        character*1 p,tip
        character*80 titteste,titcaso
        integer*4 n1,ngraf,jj,ntest
        integer imix,iter
        CHARACTER*20 A1,A2,A3
                       
        if(iopt.eq.2)then
        tip='t'
        else
        tip='c'
        end if

        open (unit=16, file='config\coef'//p//'.txt')          
        open (unit=13,file='paragraf.txt')
        open (unit=14,file='tempgraf.txt')
       
        
        if(iopt.eq.2)then
         read(16,'(A80)')titcaso
         if(titcaso.ne.titteste)then
            write(*,*)'Arquivo de coeficientes nao corresponde ao caso'
            write(12,*)'<h3>Arquivo de coeficientes para o teste'
            write(12,*)'n&atilde;o corresponde ao caso calibrado.</h3>'
            stop
         end if       
        else
            write(16,'(A80)')titteste
        end if
        
        
        
        open (unit=11,file='config\calib'//p//'.txt')   
        open(unit=34,file='relat\resumo'//p//tip//'.txt')               
       
        WRITE(12,*)'T&iacute;tulo do caso: ', titteste
        write(12,*)'</font><hr>'
        write(12,'(a,i4,a,i4,a, i4, a,f7.5)')'<h6> imix = ', imix,
     *    ' inorm = ', inorm,' icam = ',icam,' tol = '
     *   ,tol,'<br>'   
        write(12,*)'Arquivos de configura&ccedil;&atilde;o '
        write(12,*)'e coeficientes na pasta CONFIG: ' 
        write(12,*)'coef',p,'.txt e config',p,'.txt<br>'
        write(12,*)'Intervalo de confian�a SAZONAL, baseado no desvio pa
     *dr�o dos res�duos mensais. </h6>'


        kmuda=1  ! pra tirar a programacao antiga das multiplicacoes de dados
       
        
        do i = 1, nprev

        close(1)
        close(3)
        close(4)
        close(33)
                 
            if (i.lt.10)write(xnome,'(I1)') i
            if (i.gt.9) write(xnome,'(I2)') i  
        
            open(unit=1,file ='auxi\'//xnome//'x.txt')                        
            open(unit=4,file ='plan\grupoteste'//p//xnome//'.csv',
     *ERR=11)
            write(4,*,err=11)
            rewind(4)
            if(iopt.eq.1)then
            open (unit=3,file='relat\'//xnome//'result.txt')
            open(unit=33,file ='plan\calibvalid'//p//xnome//'.csv',
     *ERR=11)
            write(33,*,err=11)
            rewind(33)
            end if
          
            
            if (iopt.eq.2)then 

            write(6,'(a25,i4)')'    Testando horizonte: ',i
            write(10,*)'Horizonte: ',i                        
        
            read(1,*) m
            
            if(i.eq.1)m1=m  ! para usar a previsao, tem que mudar m que leu para o primeiro            
            if(usaprev.eq.1)then 
               m=m1  ! mesmo que for horizonte 1, vai pegar o m certo.
               if(m.lt.3)then
                   write(1,*)'Numero de vari�veis = ',m
                   write(2,*)'Para usar previsao, o numero de variaveis'
                   write(2,*)'tem que ser >=3.'
                   write(12,*)'<p>Para usar a previs&atilde;o, o n&uacut
     *e;mero de vari&aacute;veis de entrada para o horizonte 1 precisa s
     *er maior ou igual a 3.</p>'
                   stop
               end if    
            end if
            
            
            k = 0
            jj=0
            err=0
            ntest=0
            if (usaprev.eq.1)then
                  rewind(16) ! volta pra previsao 1.
                  read(16,*) !pula o titulo
            end if      
            call lecomp(itree,tree,iter,itr,L95,maxx,m,minx,dpmes,
     *                  vies_mensal)
            do       
                k = k+1 
                ntest=ntest+1
                if(k.eq.1)then
                    jj=jj+1
                    
                    if(usaprev.eq.1)then
                       call testaprev(itree,tree,iter,itr,L95,
     *                  maxx,m,minx,jj,nprev)
                       goto 12   ! ja vai direto pra saida, antes de ler o i = 2
                    else
                      read(1,*,end=10)limes(jj),y(jj),(zz(j),j=1,m) ! vai ler os dados da rede separada por horizonte
                    end if
                    
                    do j = 1, m
                        zz(j)=(zz(j)-minx(j))/(maxx(j)-minx(j)) 
                    end do
                    
                                      
                    call comp(zz,yy,itree,tree,iter,itr)
                    
                    if(inorm.eq.1)then
                        amax = ymax
                        amin = ymin
                    else
                        amax = 1
                        amin = 0
                    end if 
                    
                    yy = yy*(amax-amin)+amin
                    yp(ntest)=yy
                    ym(ntest)=yy
                    
                    if(iter.gt.1)then
                      do j=iter,2,-1  !soma de cima at�  a segunda camada, pois a 1 j� esta somada.
                      call comp(zz,yyy,itree,tree,j,itr) !o iter t� entrando como j.
                      if(inorm.eq.1)yyy = yyy*(ymax-ymin)+ymin !desnormaliza
                          ym(ntest)=ym(ntest)+yyy
                      end do
                      ym(ntest)=ym(ntest)/iter
                    end if
                    
                    zprev(i)=yy

                    !if(jj.lt.nmg+1)write(100+i,*)y(jj),yy
                else
                read(1,*)
                end if
                if(k.eq.kmuda)k=0        
            end do
           else
          
         write(6,'(a26,i4)')'    Calibrando horizonte: ',i
         write(10,*)'Horizonte: ',i 
         
         if(iopt.eq.1)write(15,'(a11,i3)')'Horizonte: ',i
         write(44,*)         
         write(44,*)'Passo de tempo ', i  
         call rede(i,n1,ngraf,imix,dpmes,limes) 
           
           end if  
           
  10     if(iopt.eq.2)then
           igraf = jj-1
           if(igraf.gt.nmg)igraf=nmg  ! no teste eh o arquivo inteiro pras estatisticas.
           write(14,*)igraf
           ngraf = igraf  ! vai ficar com o menor numero de dados dos horizontes.
            call loess_smoothing(yp, ngraf, smooth_y)
            call escreveplanilha (0, ngraf, y, smooth_y,yp,ym,limes,
     *      vies_mensal)
         end if
         if(iopt.eq.2)write(34,*)'Avaliacao horizonte:',jj-1,' dados:',
     *    i,err/(jj-1)  
         continue 
        
        end do        
        
 12     rewind(13) 
        rewind(14) 
        call html(nprev,n1,p,iopt,sigla)        
        return
        
  11    write(12,*)'<h3>Erro abrindo os arquivos csv. 
     *  Verifique se tem algum aberto.</h3>'
        write(*,*)'Erro abrindo os arquivos csv. 
     *  Verifique se tem algum aberto.'
        stop       
        
        
 9009   write(*,*)'Erro abrindo arquivo entrada.txt. Use a interface.' 
        write(12,*)'<h3>Erro abrindo arquivo entrada.txt.<br>
     *  Use a interface.</h3>'
        stop
 2009   write(*,*)'Erro lendo arquivo entrada.txt. Linha: ',iread9
        write(12,*)'<h3>Erro lendo arquivo entrada.txt. Linha: ',
     *  iread9,'</h3>'
        stop        
        
        end 
        
        subroutine lecomp(itree,tree,iter,itr,L95,maxx,m,minx,dpmes,
     *             vies_mensal)
        
        Include  'paramrede.dim'
        integer*2 m
        dimension itree(10,nmm),tree(10,nmm,6)
        dimension itr(2*nmm),dpmes(12),vies_mensal(12)
        real L95,maxx(mmax),minx(mmax)
        integer iter
        
        
        read(16,*)
        read(16,*)
        read(16,23)m,L95,ibeta,inorm,ymax,ymin,(maxx(j),j=1,m),
     *        (minx(j),j=1,m)
23      FORMAT(i4,1x,F10.3,1X,2(i4,1x),f10.2,1x,f10.2,1x,160(f10.2,1x))
        read(16,*)(dpmes(j),j=1,12)
        read(16,*)(vies_mensal(j),j=1,12)
        read(16,*)iter
        nitr = 2**(iter+1)
        read(16,*)
        read(16,*)(itr(i), i = 1, nitr+1)! mais 1 pq ele sempre escreve 1 no inicio
        read(16,*)         
        do i = 1, iter+1
        read(16,*)(itree(i,k),k=1,m)
        read(16,*)
         do j = 1, m
            read(16,*)(tree(i,j,k),k=1,6)
         end do
        end do
        end
      
        Subroutine Testaprev(itree,tree,iter,itr,L95,
     *       maxx,m,minx,jj,nprev)
        include  'paramrede.dim'
        dimension zz(mmax),itree(10,nmm),tree(10,nmm,6)
        dimension itr(2*nmm),y(nmd),zprev(nmd,nmp)
        real L95,yy,maxx(mmax),minx(mmax),amax,amin
        integer*2 m, nprev,id
        integer*4 i,j,jj
               
        do
            read(1,*,end=10)imes,y(jj),(zz(j),j=1,m)
                       
            do id = 1,nprev
              if(id.gt.1)then
              do i = m, id, -1               
                  zz(i)=zz(i-id+1)
              end do              
              ii = id         
              do i = 1,id-1
                  ii = ii-1
                  zz(i)=zprev(jj,ii)
              end do
              end if
              
              do j = 1, m
                   zz(j)=(zz(j)-minx(j))/(maxx(j)-minx(j))
              end do
                                       
              call comp(zz,yy,itree,tree,iter,itr)
                    
              if(inorm.eq.1)then
                        amax = ymax
                        amin = ymin
              else
                        amax = 1
                        amin = 0
              end if 
              yy = yy*(amax-amin)+amin                    
              zprev(jj,id)=yy 
              
c              if(jj.lt.16)write(100+id,*)y(jj),zprev(jj,id),
c     *        (zz(j),j=1,m)
            end do
            jj = jj+1 ! j� chegou como 1 na chamada, ent�o s� soma depois
        end do
        
 10     igraf = jj-1
        if(igraf.gt.nmg)igraf=nmg  ! no teste eh o arquivo inteiro pras estatisticas.
        
        do j = 1, nprev
           write(14,*)igraf
           do i = 1, igraf               
               write(13,*)y(i),zprev(i,j)
           end do
        end do
        return    
              
      end

