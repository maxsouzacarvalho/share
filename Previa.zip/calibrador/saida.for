        subroutine html(d2,n1,w,iopt,sigla)
        include 'paramrede.dim'
        dimension g(nmp),p(nmp),dpmes(12),vies_mensal(12)
        real media(nmp),maximo(nmp),ep,desv,L95,sim,err,e95,
     *  e95m,coef,r2c,tend,nasht,erm,ermt,eabsm,ema,emq
        integer*2 d2,iaux,iopt,per(12),inig,icrit_vetor(nmp)
        dimension d(nmg),y1g(nmg),y2g(nmg),y3g(nmg),y4g(nmg)
        integer*2 hora, minuto, dia, mes, ano,limes(nmd)
        character*3 b
        character*9 a,aaac
        character*1 w
        integer*4 n1,st,ngraf,iter
        real ybo,ybp,ce,cang,max_corr,lambda1_vetor(nmx)
        integer pic, pict

        close(7)
        open (unit=7,file='confx.txt') 
        read (7,*) !pula a linha do titulo do caso    
        
        open (unit=100, file='relat\estatisticas.txt')
        write(100,*)'          h ;  Nash          ; emabs          ; 
     * em%           ; def        ; cam '
        
        rewind(16)  !ler o arquico coef.txt pra ler o L95
       
c        ngraf=100
        iaux=0
        
        rewind(11)

        read(11,'(I10)',err=108)n1
        rewind(11)
    
        
        read(7,*,err=107)nn
        
        coef = nint(ntrei/100.*(n1))
        
        read(97,*)nper
        do i = 1, nper
         read(97,*)per(i)
        end do
        
        write(34,*)
        write(34,*)'GRUPO TESTE'
        write(34,*)
        

 
        if(w.eq.'j')then        
        write(12,*)'<center><h1>Coeficientes para todo per&iacute;odo
     *  </h1></center>'
        end if
        if(w.eq.'u')then        
        write(12,*)'<center><h1>Coeficientes para o per&iacute;odo 
     *  &Uacute;mido</h1></center>'
        end if   
        if(w.eq.'s')then        
        write(12,*)'<center><h1>Coeficientes para o per&iacute;odo 
     *  seco</h1></center>'
        end if     
        if (iopt.eq.2)then
        write(12,*)'<center><h2>'
        write(12,*)'Avalia&ccedil;&atilde;o da Calibra&ccedil;&atilde;o
     *  - Teste do ajuste</h2>'
        write(12,*)'</center>'
        else
        write(12,*)'<center><h2>'
        write(12,*)'Calibra&ccedil;&atilde;o/Valida&ccedil;&atilde;o 
     *    e Grupo Teste</h2>'
        write(12,*)'</center>'
        end if
        write(12,*)'<center><h2>'
        write(12,*)'N&uacute;mero de vari&aacute;veis:',nn,'</h2>'
        write(12,*)'<table width = 50><tr><td>'       
               write(12,*)'<table border="1">'
               write(12,*)'<tr><th colspan=',nn+1,'> N&uacute;mero de  
     * dados atr&aacute;s (defasagem)</th></tr>'
               write(12,*)'<tr class="tit">'
               write(12,*)'<td><b>Horizonte</b></td>'
               do i = 1, nn
               write(12,*)'<td><b>',sigla(3+i),'
     *</h4></b>'
               end do
               write(12,*)'</tr>'               
               do i = 1, d2
               
c               ja que ta lendo de novo, nao precisa ser
c               ao contrario, pois vai imprimir de acordo
c               com a ordem informada.               
               
                read(7,*,err=107)(g(j),p(j),j=1,nn),ibeta,
     *                           lambda1_vetor(i),icrit_vetor(i)
                write(12,*)'<tr>'
                write(12,*)'<td>',i,'</td>'
                do j = 1, nn                                
                write(12,*)'<td>',nint(g(j)),
     *         ' a ',nint(p(j)),'</td>'
                end do
                write(12,*)'</tr>'
               end do
               write(12,*)'</table>'
        write(12,*)'<td class="tit">'
        write(12,*)'<h3>Total para treinamento:',n1
        if(nkfold.eq.0)then
        write(12,*)'<br>Regress&atilde;o (',ntrei,'%):',nint(COEF)
        write(12,*)'<br>Valida&ccedil;&atilde;o (',100-ntrei,'%):',
     *  nint(n1-COEF) 
        else
        write(12,*)'<br>K-folds:',nkfold  
        end if
        write(12,*)'<br>Horizontes:', d2
        read(14,*)ngraf
        rewind(14)
        write(12,*)'<br>Valida&ccedil;&atilde;o visual: ',ngraf 
        write(12,*)'<br>Amortizou (total):',iaux        
        write(12,*)'</h3>'
        write(12,*)'<h5>* Total para o horizonte 1</h5>'
        write(12,*)'</td></tr></table></center>'
        write(12,*)'<hr>'
        write(12,*)'<h2>Estat&iacute;sticas</h2>'
c        write(12,*)'<b>Estat&iacute;sticas "aparadas", retirando 
c     *as 1% maiores e 1% menores estimativas</b>'
        write(12,*)'<h3>Meses do per&iacute;odo: ',
     *  (per(jj),jj=1,nper),'</h3>'

        
        rewind(15)  !arquivo dos pares
        
        write(44,*)
        write(44,*)'GRUPO TESTE'
        
        
        do j = 1, d2 
           read(14,*)ngraf                     
           do igraf=1,ngraf
            read(13,*)y1g(igraf),y2g(igraf),y3g(igraf),
     *                y4g(igraf),limes(igraf)
           end do
           write(44,*)
           write(44,*)'Passo de tempo ', j  
           
           
           !call stat1(ngraf,y1g,y3g,pict) 
           CALL CALCULA_LAG(y1g, y3g, ngraf, pict, nmp, MAX_CORR) !Com poucos dados, o lag pode ficar alto
                                                                  !pois a media do max_corr vai ficando alta. Aconteceu com a semanal.
                                                                  !e isso acontece com o Pearson tamb�m.
           call NashSutcliffe(y1g,y3g,ngraf,nasht)
           
           Call Calcula_EP(y1g, y3g, ngraf, EP)
           
           Call Calcula_Tendencia(y1g, y3g, ngraf, cang,ybo,ybp) !Esse tend � o coeficiente algular da reta
           tend = (ybp-ybo)/ybo  !trocando pela divis�o entre as medias
            
           Call desvpad (ngraf, y1g, y3g, ema, desv,emq) !aqui � da suavizada, mas talvez fique ruim para mensal.
           
           Call PearsonCorrelation(ngraf,y1g, y3g, r2)
           
           Call ErroPercentual(y1g, y2g, ngraf, ermt) ! aqui � o erro da bruta = y2g
           
           Call ErroPercentual(y1g, y3g, ngraf, ermts)
           
           write(12,*)
           


          do
            read(16,'(a9)')a
            if (a.eq.'Horizonte')goto 119
          end do
          
  119    continue
          read(16,*)!pula a linha do asc e dsc
          read(16,*,err=120)dum, L95
          read(16,*)(dpmes(ia), ia=1,12)
          read(16,*)(vies_mensal(ia), ia=1,12)
          read(16,*)iter
          
          do ia=1,12
              if(dpmes(ia).le.0)dpmes(ia)=l95
          end do
          
          write(100,*)j,';',nasht ,';',ema ,';',ermts,';',pict,';',iter
          
 120    continue         
          
           
        write(12,*)'<hr>'                      
        write(12,*)'<b>Horizonte:',j,'</b><br>'
c        write(12,*)'<h6>&Uacute;ltimos ',ngraf, ' dados</h6>'
        write(34,*)'Ultimos ',ngraf, ' dados.'
        write(34,*)
        write(34,*)'HORIZONTE:',j
        write(34,*)
        write(34,*)'Numero de camadas: ', iter
c        write(12,*)'Pares que usou:<br>'
c         do ipar = 1, 256
c            read(15,'(2a7)')a, b
c            if(a.eq.'fim    ')goto 10
c            write(12,'(2a7)')a,b,'<br>'
c         end do    
10       Read(11,27, err=28)n,n,nash,eabsm,r2c,ibeta,ymax,ymin,pic,erm 
27       format(I10,1X,I10,1X,F12.5,1X,F12.5,1X,F10.7,1x,I4,1X,F10.3,1X,
     *   F10.3,1X,I4,1x,f10.3)
28        if (ibeta.eq.1)then
           write(12,*)'<b> Regress&atildeo COM termo independente</b>'
        else
           write(12,*)'<b style="font-size: 12px"> 
     *     Regress&atildeo SEM termo independente</b>'
        end if
        write(12,*)'<br><b style="font-size: 12px">' 
        write(12,'(a,f9.4)')'Lambida (Ridge) = ',lambda1_vetor(j)
        
        if (icrit_vetor(j).eq.1)aaac = 'Dmin'
        if (icrit_vetor(j).eq.2)aaac = 'RMSE'
        if (icrit_vetor(j).eq.3)aaac = 'Pearson'
        if (icrit_vetor(j).eq.4)aaac = 'Nash'
        
        write(12,'(a,a8,a)')'<br>Criterio = ',aaac,'</b>'
                
        write(12,*) '<table style="font-size: 11px; border-collapse: co
     *llapse; width: 80%;">'
        
        ! Linha adicional para R de Pearson e defasagens
        write(12,'(a)') '<tr>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;paddi
     *ng:4px;"><b>R Pearson (Cal):</b></td><td style="border:1px solid
     * #ddd;padding:4px;">', r2c, '</td>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;paddi
     *ng:4px;"><b>R Pearson (Teste):</b></td><td style="border:1px soli
     *d #ddd;padding:4px;">', r2, '</td>'
        write(12,'(a,i2,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">Defasagem Pico (Cal):</td><td style="border:1px solid #
     *ddd;padding:4px;">', pic, '</td>'
        write(12,'(a,i2,a)') '<td style="border:1px solid #ddd;paddi
     *ng:4px;">Defasagem Pico (Teste):</td><td style="border:1px solid #
     *ddd;padding:4px;">', pict, '</td></tr>'        
        
        ! Primeira linha com 4 estat�sticas (todas reais)
        write(12,'(a)') '<tr>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">M�dia Obs(Teste):</td><td style="border:1px solid #ddd;
     *padding:4px;">', ybo, '</td>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">M�dia Prev(Teste):</td><td style="border:1px solid #dd
     *d;padding:4px;">', ybp, '</td>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">Obs M�x(Cal):</td><td style="border:1px solid #ddd;pad
     *ding:4px;">', ymax, '</td>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">Obs M�n(Cal):</td><td style="border:1px solid #ddd;pad
     *ding:4px;">', ymin, '</td></tr>'        ! Segunda linha com 4 estat�sticas (todas reais)
        write(12,'(a)') '<tr>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">Tend�ncia(%):</td><td style="border:1px solid #ddd;pad
     *ding:4px;">', tend*100, '</td>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">DP Erros(Cal):</td><td style="border:1px solid #ddd;pa
     *dding:4px;">', L95, '</td>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">DP Erros(Teste):</td><td style="border:1px solid #ddd;
     *padding:4px;">', desv, '</td>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">MAE(Cal):</td><td style="border:1px solid #ddd;padding
     *:4px;">', eabsm, '</td></tr>'

        ! Terceira linha com 4 estat�sticas (todas reais)
        write(12,'(a)') '<tr>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">MAE(Teste):</td><td style="border:1px solid #ddd;paddi
     *ng:4px;">', ema, '</td>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">MAPE Cal (%):</td><td style="border:1px solid #ddd;
     *padding:4px;">', erm, '</td>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">MAPE Teste(bruto)(%):</td><td style="border:1px solid 
     *#ddd;padding:4px;"><b>', ermt, '</b></td>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">MAPE Teste(suave)(%):</td><td style="border:1px solid 
     *#ddd;padding:4px;"><b>', ermts, '</b></td></tr>'

        ! Quarta linha (3 reais e 1 inteiro)
        write(12,'(a)') '<tr>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">MSE Teste:</td><td style="border:1px solid #ddd;paddin
     *g:4px;">', emq, '</td>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">RMSE:</td><td style="border:1px solid #ddd;paddi
     *ng:4px;">', EP, '</td>'
        write(12,'(a,f15.3,a)') '<td style="border:1px solid #ddd;padd
     *ing:4px;">Nash-Sutcliffe:</td><td style="border:1px solid #ddd;p
     *adding:4px;">', Nasht, '</td>'
        write(12,'(a,i4,a)') '<td style="border:1px solid #ddd;padding
     *:4px;">N� Camadas:</td><td style="border:1px solid #ddd;padding:4
     *px;">', iter, '</td></tr>'

        write(12,*) '</table>'
      
       L95 = L95*1.96   ! para o LI e LS do grafico
              
       if(ngraf.gt.200)then
          inig=ngraf-200
       else
          inig=1
       end if
       
       !write(12,*)'' 
       
       write(12,*)'<canvas id="',j,'" style="width:800px;height:
     * 230px;max-width:80%"></canvas>'
       
        write(12,*)'<script>'       
        write(12,*)'var xValues = ['
            do i = inig, ngraf
                write(12,'(i6,a1)')i,',' 
            end do
        write(12,*)'];'
        write(12,*)'new Chart("',j,'", {'
        write(12,*)' type: "line",'
        write(12,*)'  data: {'
        write(12,*)'    labels: xValues,'
        write(12,*)'    datasets: [{ '
        
        write(12,*)'      data: ['
          do i = inig, ngraf
                yyy = (y1g(i))
                write(12,'(F15.7,a1)')yyy,',' 
          end do
        write(12,*)'],'
        write(12,*)'      borderColor: "crimson",'
        write(12,*)'      fill: false,'
        write(12,*)'      label:"Observado"'
        write(12,*)'    }, { '
        
        write(12,*)'      data: ['
          do i = inig, ngraf
                yyy = (y3g(i))
                write(12,'(F15.7,a1)')yyy,',' 
          end do        
        write(12,*)'],'
        write(12,*)'      borderColor: "blue",'
        write(12,*)'      fill: false,'
        write(12,*)'      label:"Previs�o Suavizada"' 
        write(12,*)'    }, { '        
        
        write(12,*)'      data: ['
          do i = inig, ngraf
                yyy = (y2g(i))
                write(12,'(F15.7,a1)')yyy,',' 
          end do        
        write(12,*)'],'
        write(12,*)'      borderColor: "grey",'
        write(12,*)'      fill: false,'
        write(12,*)'      hidden: false,'  
        write(12,*)'      label:"Previs�o Bruta"' 
        write(12,*)'    }, { '

        write(12,*)'      data: ['
          do i = inig, ngraf
                yyy = (y4g(i))
                write(12,'(F15.7,a1)')yyy,',' 
          end do        
        write(12,*)'],'
        write(12,*)'      borderColor: "yellow",'
        write(12,*)'      fill: false,'
        write(12,*)'      hidden: false,'  
        write(12,*)'      label:"Previs�o M�dia"' 
        write(12,*)'    }, { '        
        
          write(12,*)'      data: ['
          do i = inig, ngraf
                !yyy = (y3g(i))-vies_mensal(limes(i))
                 if (vies_mensal(limes(i)).eq.(-1))then
                  yyy = y3g(i)
                 else
                  yyy =y3g(i)/(1+vies_mensal(limes(i)))
                 end if
                write(12,'(F15.7,a1)')yyy,',' 
          end do        
        write(12,*)'],'
        write(12,*)'      borderColor: "purple",'
        write(12,*)'      fill: false,'
        write(12,*)'      label:"Remo��o de Vi�s"' 
        write(12,*)'    }, { '
         
        write(12,*)'      data: ['
          do i = inig, ngraf
                !yyy = (y3g(i)+(dpmes(limes(i))*y3g(i)*1.96)) se fosse %
                yyy = (y3g(i)+(dpmes(limes(i))*1.96))
                if(yyy.gt.ymax)yyy=ymax
                write(12,'(F15.7,a1)')yyy,',' 
          end do        
        write(12,*)'],'
        write(12,*)'      borderColor: "lightgreen",'
        write(12,*)'      backgroundColor: "rgba(144, 238, 144, 0.3)",' 
        write(12,*)'      fill: "+1",'
        write(12,*)'      label:"Limite Superior 95%"' 
        write(12,*)'    }, { '
        
        write(12,*)'      data: ['
          do i = inig, ngraf
                !yyy = (y3g(i)-(dpmes(limes(i))*y3g(i)*1.96)) se fosse %
                yyy = (y3g(i)-(dpmes(limes(i))*1.96)) 
                if(yyy.lt.ymin)yyy=ymin
                write(12,'(F15.7,a1)')yyy,',' 
          end do        
        write(12,*)'],'
        write(12,*)'      borderColor: "orange",'
        write(12,*)'      backgroundColor: "rgba(240, 128, 128, 0.3)",' 
        write(12,*)'      fill: "-1",'
        write(12,*)'      label:"Limite Inferior 95%"' 
       
        write(12,*)'    }'
        write(12,*)'] '
        write(12,*)'},'
        
        write(12,*)'  options: {'
        write(12,*)'    legend: {display: true}'
        write(12,*)'  }'
        write(12,*)'});'      
        write(12,*)'</script>' 
        !write(12,*)'<br>'
        write(12,*)'<table>
     *   <tr style="font-size: 11px;height=5px;">'
        write(12,*)'<td style="background-color:grey;">
     *  </td><td>Jan</td><td>Fev</td><td>Mar</td>
     *  <td>Abr</td><td>Mai</td><td>Jun</td><td>Jul</td><td>Ago</td>
     *  <td>Set</td><td>Out</td><td>Nov</td><td>Dez</td></tr>
     *  <tr style="font-size: 11px;">'
        write(12,'(a,12(a,f10.3,a))')'<td>DP</td>',('<td>',dpmes(ia),
     *  '</td>',ia=1,12),'</tr><tr style="font-size: 11px;">'
        write(12,'(a,12(a,f10.3,a))')'<td>Vies(%)</td>',
     *  ('<td>',vies_mensal(ia)*100,'</td>',ia=1,12)
        write(12,*)'</tr></table>'
        write(34,*)'Desvio Padrao Erros Calibracao:',L95
        write(34,*)'Desvio padrao dos Erros do teste:',desv    
        write(34,*)'Erro medio absoluto da Calibracao:',eabsm
        write(34,*)'Erro medio absoluto do Teste:',ema
        write(34,*)'Erro medio relativo da Calibracao:',erm
        write(34,*)'Erro medio relativo do Teste (bruto):',ermt  
        write(34,*)'Erro medio relativo do Teste (suave):',ermts  
        write(34,*)'ErrMedQuad:',emq          
        write(34,*)'Erro Padrao de Predi��o',EP
        write(34,*)'Coeficiente Nash-Sutcliffe (Teste):',Nasht
        
        
          end do
         write(12,*)'<br><hr>'
         write(12,*)'<b style="font-size: 12px"> ' 
         write(12,*)'* Chart.js v4.4.7 <br>'
         write(12,*)'* https://www.chartjs.org <br>'
         write(12,*)'* (c) 2024 Chart.js Contributors <br>'
         write(12,*)'* Released under the MIT License' 
         write(12,*)'</b>'        
        write(12,*)'</body>'
        write(12,*)'</html>'
                
        goto 110

107     continue
        write(12,*)'<html><body><h1>Erro no arquivo de entrada</h1>'
        write(12,*)'verificar o arquivo de configuracao'
        write(12,*)'</body></html>'
        stop  
108     write(12,*)'<html><body><h1>Erro no arquivo "calib"</h1>'
        write(12,*)'Verificar se existe rodada de calibracao'
        write(12,*)'</body></html>'
        stop   
        
110     continue  
        
        end
        


        
