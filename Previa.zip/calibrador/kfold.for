      subroutine kfold_split( n, nc, folds,k,fold_count)
      include 'paramrede.dim'
      integer n, k, i, j, fold_size, remainder,nc
      integer start_idx, end_idx, current_fold
      integer indices(nmd)              ! Vetor de �ndices de 1 a n
      integer folds(10,nmd)           ! Array 2D para armazenar os folds 
      integer fold_count(10)            ! N�mero de elementos em cada fold

      
     
      ! Inicializar os �ndices de 1 a n
      do 10 i = 1, n
         indices(i) = i
 10   continue

      ! Calcular o tamanho de cada fold e o resto
      fold_size = n/k
      remainder = mod(n, k)            ! Resto para distribuir elementos adicionais
      

      ! Dividir os �ndices em k folds
      call create_folds(indices, folds, fold_size, remainder,
     * fold_count, n, k)

      ! Loop principal para exibir os grupos de treino e valida��o de cada fold
      do 20 current_fold = 1, k
         !write(*,*) 'Fold ', current_fold, ' como grupo de validacao:'
         call get_train_validation_split(folds, fold_count, 
     * current_fold, n, k)
         !write(*,*) '-----------------------------------'
 20   continue
 
       !aumenta o numero de folds e preenche o folds(k,i) com todos os dados pro treino e pra valida�ao
       !como ele �e o �ultimo, os coeficientes que estarao valendo eh justamente o do grupo todo.
       
       k = k + 1  !ultimo fold = todos
       fold_count(k) = 0  !  Tamanho da valida��o - s�o todos
       
       do i = 1, n
         folds(k,i)=i  !preenche treinamento com todos
       end do
       
c      read(*,*)
      end

      ! Sub-rotina para organizar os �ndices em k folds
      subroutine create_folds(indices, folds, fold_size, remainder, 
     * fold_count, n, k)
      include 'paramrede.dim'
      integer indices(nmd), folds(10,nmd), fold_count(10)
      integer fold_size, remainder, n, k
      integer i, j, start, count

      ! Inicializa o array `folds` e `fold_count`
      do 30 i = 1, k
         fold_count(i) = 0
         do 31 j = 1, n
            folds(i, j) = -1
 31      continue
 30   continue

      ! Dividir os �ndices de forma balanceada entre os folds
      start = 1
      do 40 i = 1, k
         count = fold_size
         if (i .le. remainder) count = count + 1

         do 41 j = 1, count
            folds(i, j) = indices(start)
            start = start + 1
 41      continue
         fold_count(i) = count
 40   continue

      return
      end

      ! Sub-rotina para exibir os dados de treinamento e valida��o de um fold
      subroutine get_train_validation_split(folds, fold_count,
     * current_fold, n, k)
      include 'paramrede.dim'
      integer folds(10, nmd), fold_count(10)
      integer current_fold, n, k
      integer i, j

      ! Exibir �ndices de valida��o para o fold atual
      !write(*,*) 'Indices de Validacao:'
      do 50 i = 1, fold_count(current_fold)
         if (folds(current_fold, i).ne.-1) then
            !write(*,*) folds(current_fold, i)
         end if
 50   continue

      ! Exibir �ndices de treinamento (os outros folds)
      jcur = fold_count(current_fold)
      !write(*,*) 'Indices de Treinamento:'
      do 60 i = 1, k         
         if (i .ne. current_fold) then
            do 61 j = 1, fold_count(i)               
               if (folds(i, j).ne.-1) then
                  jcur = jcur +1
                  !write(*,*) folds(i, j)
                  folds(current_fold,jcur)=folds(i, j)
               end if
 61         continue
         end if
 60   continue
      return
      end
