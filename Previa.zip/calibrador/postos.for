        subroutine postos(n1,d1,nn,d2,icam,iprint,
     *  nnt,n3,iprev,ip,sigla,iopt)
        include 'paramrede.dim'
        integer*2 d1,d2,icam,iprint,iprev,ip,iopt
        integer*2 nn,z,pj,q,imes,iano,j,dia,n1,n3
        integer*4 g(nmp),p(nmp),nnt
        dimension y(nmd),xu(nmd,nmx),x(nmd,nmx),xs(nmd,nmx)
        dimension w(99),iper(12)
        real max, min
        character*2 xnome,aa
        character*8 aandd
        
        if (d1.lt.10)then
          write (xnome,'(I1)') d1
        else
          write (xnome,'(I2)') d1
        end if

        open(unit=98,file ='auxi\'//xnome//'x.txt')
        open(unit=97,file='periodo.txt',status ='old',err=9097)
        
        iread97=1
        read(97,*,err=2)nper
        iread97=iread97+1
        
        do i=1,nper
            read(97,*,err=2)iper(i)
            iread97=iread97+1
        end do
                
c       le ao contrario pq vai ler os dados ao contrario tb
c       para ficar compativel com a ordem que o usuario entra
c       importante que as variaveis mais importantes fiquem
c       por ultimo. Por causa de relatorios montante-jusante,
c       a jusante eh o dado que a gente quer calibrar.

c       necessario por que a montagem das variaveis para a rede,
c       a que quer calibrar eh a primeira
        read(7,*,err=4)(g(j),p(j),j=nn,1,-1),ibeta,lambda1,icrit 
        
        ! a sigla leu na ordem do arquivo.
        ndd = 1
        if(iopt.eq.1)write(15,'(a4,i3)')'dia ',d1
        if(iopt.eq.1)write(15,*)
        do j = 1,nn
          jji = nn-j+1
          if(g(j).gt.0)then
          do ij = g(j),p(j)
            iij=ij
            write(aa,'(i2)')iij
            write(aandd,'(a4,a2)')sigla(jji+3),aa
            if(iopt.eq.1)write(15,'(i3,1x,a8)')ndd,aandd
            ndd=ndd+1            
          end do
          end if
        end do
       if(iopt.eq.1) write(15,*)               
               
        pj = 0  !maxima defasagem
        q = 0   !quantidade de neuronios

        do j=1,nn                !se alguem colocar inicio 0
          if (g(j).eq.0)then
            if (p(j).gt.0)then
           write(*,*)'Verifique as defasagens do ',
     *     'posto ',j,', horizonte ',d1
            write(12,*)'<html><body><h1>Verifique as defasagens do ',
     *     'posto ',j,', horizonte ',d1,'</h1>'
           write(12,*)'Postos iniciados com defasagem zero ',
     *     'n&atilde;o s&atilde;o utilizados'
           write(12,*)'</body></html>'
            stop 
            else            
             p(j)=-1
            end if
          end if
        end do

        do i = 1, nn
         if(p(i).gt.pj)pj=p(i)
         if(g(i).gt.0)then
           q = q + p(i)-g(i)+1
         end if
        end do
        write(98,*)q,icam,ibeta,lambda1,icrit
               
         do  
         n1 = 0
         do ile=1, pj+d1
            n1=n1+1
            read(2,*,end=1)dia,imes,iano,
     *     (x(n1,j),j=nn,1,-1)
            y(n1)=x(n1,1)  
         end do
         
         k=0
          do j=1, nn
            do jj =g(j)+d1, p(j)+d1
             k = k+1
             w(k)= x(n1-jj+1,j)
            end do
          end do
         
         if(k.gt.40)then 
         write(*,*)'Numero de variaveis (',k, 
     *   ') no horizonte ',xnome, ' maior que o maximo (40).'
         write(12,*)'<html><h1>N&uacute;mero de vari&aacute;veis (', k,
     *   ') no horizonte ',xnome,' maior que o m&aacute;ximo (40).</h1>'
         write(12,*)'</body></html>'
         stop
         end if
          
         do im=1, nper
         
         if(imes.eq.iper(im))then                                 !ja que leu tudo, nao fica descontinuo quando muda de periodo.
          write(98,'(i4,1x,41(f17.8,1x))')imes,y(n1),(w(j),j=1,k) 
c          write(98,'(41(F15.7,1x))')1.8*y(n1),(1.8*w(j),j=1,k)    !com duas normalizacoes, nao precisaria talvez. Aguardar acontecer erro.
c          write(98,'(41(F15.7,1x))')0.5*y(n1),(0.5*w(j),j=1,k)
c          write(98,'(41(F15.7,1x))')0.2*y(n1),(0.2*w(j),j=1,k)
         end if

         end do

          
           do ile=1,pj+d1-1
              backspace(2)
           end do 
         
         end do  
                                                      
  1      rewind(2) 
         rewind(97)
         
         return
         
  2     continue
        write(*,*)'Erro lendo arquivo periodo.txt. Linha:',iread97
        write(*,*)'Use a interface.'
        write(12,*)'<h3>Erro lendo arquivo periodo.txt. Linha:'        
        write(12,*)iread97
        write(12,*)'Use a interface.</h3></body></html>'
        stop 
  3     continue
        write(*,*)'Erro no arquivo de dados'
        write(*,*)'Ultimo dado lido: ', dia,'/',imes,'/',iano
        write(12,*)'<h31>Erro no arquivo de dados</h3>'
        write(12,*)'<br>Ultimo dado lido: ', dia,'/',imes,'/',iano
        write(12,*)'</body></html>'
        stop
  4     continue
        write(*,*)'Erro no arquivo de configuracao para o dia ',d1
        write(12,*)'<h3>Erro no arquivo de configura&ccedil;&atilde;o:
     *  entrada de dados para o horizonte ',d1,' </h3>'        
        write(12,*)'</body></html>'
        stop
 9097   write(*,*)'Erro abrindo arquivo periodos.txt.'
        write(*,*)'Use a interface.'
        stop
 
        end
        
        
