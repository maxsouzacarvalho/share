
# suite_previas.py
import os
import sys
import shutil
import subprocess
from pathlib import Path
import webbrowser
import tkinter as tk
from tkinter import messagebox, filedialog
from tkinter.scrolledtext import ScrolledText
import ttkbootstrap as tb
from ttkbootstrap.constants import *
from datetime import datetime
import numpy as np
import pandas as pd
import re
from typing import Dict, List, Set, Tuple

# Backends e libs opcionais
OPENPYXL_AVAILABLE = False
STATSMODELS_AVAILABLE = False
try:
    import openpyxl
    from openpyxl.drawing.image import Image as OpenpyxlImage
    OPENPYXL_AVAILABLE = True
except Exception:
    pass

try:
    from statsmodels.tsa.arima.model import ARIMA
    from statsmodels.tsa.stattools import adfuller
    STATSMODELS_AVAILABLE = True
except Exception:
    pass

APP_NAME = "PrevIA 3.0"

# ======================================================================
# BasePath e utilitários comuns
# ======================================================================
BASE_PATH = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).parent
# Último diretório usado nos diálogos de arquivo
_last_dir = str(BASE_PATH / "dados")

def ensure_dirs():
    """
    Garante a existência das pastas utilizadas pelos 3 aplicativos.
    """
    for nome in ['relat', 'plan', 'auxi', 'config', 'configprop', 'dados', 'tabelas', 'graficos']:
        (BASE_PATH / nome).mkdir(exist_ok=True)
    pastadados = BASE_PATH / "dados"
    for nome in ['USB','UIT','UBE','UPE','UTM','IUSB']:
          (pastadados / nome).mkdir(exist_ok=True)

def safe_set_icon(root: tk.Tk, icon_relpath: str):
    icon_path = BASE_PATH / icon_relpath
    if icon_path.exists():
        try:
            root.iconbitmap(str(icon_path))
        except Exception:
            pass  # ambiente sem suporte a .ico

def pick_file(title: str, filetypes, initialdir=None):
    global _last_dir
    if initialdir is None:
        initialdir = _last_dir
    filename = filedialog.askopenfilename(
        title=title,
        initialdir=initialdir,
        filetypes=filetypes
    )
    if filename:
        _last_dir = os.path.dirname(filename)
        return filename
    return ""

def open_system_file(path: Path):
    """Abre arquivo no sistema de forma multiplataforma."""
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(path))
        elif sys.platform == "darwin":
            subprocess.run(["open", str(path)], check=False)
        else:
            subprocess.run(["xdg-open", str(path)], check=False)
    except Exception:
        # Fallback para HTML
        if path.suffix.lower() in {".html", ".htm"}:
            webbrowser.open(str(path))


def run_exe(exe_name: str, txt_output: tk.Text):
    """
    Executa C.exe, P.exe ou PP.exe e envia stdout para o ScrolledText de log.
    """
    exe_path = BASE_PATH / exe_name
    if not exe_path.exists():
        messagebox.showerror("Erro", f"Executável não encontrado:\n{exe_path}")
        return
    try:
        p = subprocess.Popen(
            [str(exe_path)],
            cwd=BASE_PATH,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )
        for line in p.stdout:
            txt_output.insert(tk.END, line)
            txt_output.see(tk.END)
            txt_output.update_idletasks()
        p.wait()
    except Exception as e:
        messagebox.showerror("Erro", f"Falha ao executar {exe_name}:\n{e}")

# Backends e libs opcionais
OPENPYXL_AVAILABLE = False
STATSMODELS_AVAILABLE = False
try:
    import openpyxl
    from openpyxl.drawing.image import Image as OpenpyxlImage
    OPENPYXL_AVAILABLE = True
except Exception:
    pass

try:
    from statsmodels.tsa.arima.model import ARIMA
    from statsmodels.tsa.stattools import adfuller
    STATSMODELS_AVAILABLE = True
except Exception:
    pass

# Caso seu Suite já tenha BASE_PATH/safe_set_icon/open_system_file/pick_file,
# reutilize-os; abaixo, usamos uma versão mínima local para manter o exemplo autocontido.
BASE_PATH = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).parent

def open_system_file(path: Path):
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(path))
        elif sys.platform == "darwin":
            import subprocess; subprocess.run(["open", str(path)], check=False)
        else:
            import subprocess; subprocess.run(["xdg-open", str(path)], check=False)
    except Exception:
        import webbrowser
        if path.suffix.lower() in {".html", ".htm"}:
            webbrowser.open(str(path))

def pick_file_csv(title="Selecionar CSV"):
    return pick_file(title, [("CSV", "*.csv"), ("Todos", "*.*")])

# ======================================================================
# Classe árvore 
# ======================================================================
class GMDHModelParser:
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.horizontes: Dict[int, dict] = {}
        
    def parse(self) -> None:
        try:
            with open(self.file_path, 'r', encoding='utf-8') as file:
                content = file.read()
            
            # Processa seção de variáveis (antes dos horizontes)
            variaveis_globais = self._processar_secao_variaveis(content)
            
            # Processa cada horizonte
            for horizonte_block in re.split(r'(?=Horizonte:\s+\d+)', content):
                if 'Horizonte:' not in horizonte_block:
                    continue
                
                horizonte_num = int(re.search(r'Horizonte:\s+(\d+)', horizonte_block).group(1))
                self._processar_horizonte(horizonte_num, horizonte_block, variaveis_globais)
                
        except Exception as e:
            raise Exception(f"Erro ao processar arquivo: {str(e)}")
    
    def _processar_secao_variaveis(self, content: str) -> Dict[int, Dict[int, str]]:
        """Processa a seção inicial com as variáveis de todos os dias"""
        variaveis_por_dia = {}
        
        # Encontra todas as seções 'dia X'
        for dia_section in re.finditer(r'dia\s+(\d+)(.*?)(?=dia\s+\d+|Horizonte:|\Z)', content, re.DOTALL):
            dia_num = int(dia_section.group(1))
            variaveis = {}
            
            # Extrai cada variável
            for var_line in re.finditer(r'^\s*(\d+)\s+(\w+)\s+(\d+)\s*$', dia_section.group(2), re.MULTILINE):
                var_num = int(var_line.group(1))
                var_name = f"{var_line.group(2)} {var_line.group(3)}"
                variaveis[var_num] = var_name
            
            variaveis_por_dia[dia_num] = variaveis
        
        return variaveis_por_dia
    
    def _processar_horizonte(self, horizonte_num: int, block: str, variaveis_globais: Dict[int, Dict[int, str]]) -> None:
        try:
            # Verifica se temos variáveis para este horizonte/dia
            if horizonte_num not in variaveis_globais:
                raise ValueError(f"Nenhuma variável definida para o dia {horizonte_num}")
            
            # Processa camadas (ignorando a última se houver 'Horizonte:' no conteúdo)
            camadas = {}
            for camada_match in re.finditer(
                r'Camada:\s+(\d+)\s+Polinomios:\s+\d+\s*(.*?)(?=Camada:|Horizonte:|\Z)', 
                block, 
                re.DOTALL
            ):
                camada_num = int(camada_match.group(1))
                camada_content = camada_match.group(2)
                
                polinomios = {}
                for pol_match in re.finditer(
                    r'Pol\.\s+(\d+)\s+=\s+(.*?)(?=Pol\.\s+\d+|$)', 
                    camada_content, 
                    re.DOTALL
                ):
                    pol_num = int(pol_match.group(1))
                    expr = pol_match.group(2).strip()
                    
                    # Extrai dependências
                    dependencias = set()
                    for dep_match in re.finditer(r'([xp])\s*(\d+)', expr):
                        tipo = dep_match.group(1)
                        num = int(dep_match.group(2))
                        dependencias.add((tipo, num))
                    
                    polinomios[pol_num] = {
                        'expressao': f"Pol. {pol_num} = {expr}",
                        'dependencias': sorted(dependencias, key=lambda x: x[1])
                    }
                
                camadas[camada_num] = polinomios
            
            self.horizontes[horizonte_num] = {
                'variaveis': variaveis_globais[horizonte_num],
                'camadas': camadas
            }
            
        except Exception as e:
            raise ValueError(f"Erro no horizonte {horizonte_num}: {str(e)}")
    
    def get_original_variables(self, horizonte: int, camada: int, polinomio: int) -> List[int]:
        """Obtém as variáveis originais para um polinômio específico"""
        try:
            # Validações
            if horizonte not in self.horizontes:
                raise ValueError(f"Horizonte {horizonte} não encontrado")
                
            if camada not in self.horizontes[horizonte]['camadas']:
                raise ValueError(f"Camada {camada} não encontrada no horizonte {horizonte}")
                
            if polinomio not in self.horizontes[horizonte]['camadas'][camada]:
                raise ValueError(f"Polinômio {polinomio} não encontrado na camada {camada}")
            
            # Rastreamento recursivo
            vars_set = self._rastrear_dependencias(horizonte, camada, polinomio, set())
            return sorted(vars_set)
            
        except Exception as e:
            raise ValueError(f"Erro ao buscar variáveis originais: {str(e)}")
    
    def _rastrear_dependencias(self, horizonte: int, camada: int, polinomio: int, visitados: Set[Tuple[int, int, int]]) -> Set[int]:
        """Função recursiva para rastrear dependências"""
        chave = (horizonte, camada, polinomio)
        if chave in visitados:
            return set()
        
        visitados.add(chave)
        
        pol_info = self.horizontes[horizonte]['camadas'][camada][polinomio]
        variaveis = set()
        
        for tipo, num in pol_info['dependencias']:
            if tipo == 'x':
                if num not in self.horizontes[horizonte]['variaveis']:
                    raise ValueError(f"Variável x{num} não definida no horizonte {horizonte}")
                variaveis.add(num)
            elif tipo == 'p':
                if camada == 1:
                    raise ValueError("Dependência 'p' encontrada na camada 1")
                variaveis.update(
                    self._rastrear_dependencias(horizonte, camada-1, num, visitados))
        
        return variaveis
    
    def print_summary(self) -> None:
        """Exibe um resumo estruturado do modelo"""
        for horizonte, data in self.horizontes.items():
            print(f"\n=== Horizonte {horizonte} ===")
            print(f"Variáveis de entrada ({len(data['variaveis'])}):")
            for num, nome in sorted(data['variaveis'].items()):
                print(f"  {num}: {nome}")
            
            print(f"\nCamadas ({len(data['camadas'])}):")
            for camada in sorted(data['camadas']):
                print(f"  Camada {camada}: {len(data['camadas'][camada])} polinômios")
                
                # Exemplo: mostra dependências do primeiro polinômio
                primeiro_pol = data['camadas'][camada][1]
                print(f"    Exemplo Pol.1: {primeiro_pol['expressao'][:60]}...")
                
                if camada > 1:
                    try:
                        vars_orig = self.get_original_variables(horizonte, camada, 1)
                        print(f"    Variáveis originais: {vars_orig}")
                    except Exception as e:
                        print(f"    Erro ao obter variáveis originais: {str(e)}")

    def exportar_rastreamento(self, arquivo_saida: str = "rastreamento.txt") -> None:
        """Exporta todo o rastreamento para um arquivo de texto"""
        with open(arquivo_saida, 'w', encoding='utf-8') as f:
            f.write("=== RASTREAMENTO COMPLETO DO MODELO ===\n\n")
            
            for horizonte, data in sorted(self.horizontes.items()):
                f.write(f"=== HORIZONTE {horizonte} ===\n")
                f.write(f"Variáveis de entrada ({len(data['variaveis'])}):\n")
                for num, nome in sorted(data['variaveis'].items()):
                    f.write(f"  x{num}: {nome}\n")
                
                f.write("\nCamadas:\n")
                for camada in sorted(data['camadas']):
                    f.write(f"\nCamada {camada}:\n")
                    
                    for pol_num, pol_data in sorted(data['camadas'][camada].items()):
                        f.write(f"\nPol. {pol_num}:\n")
                        f.write(f"Expressão: {pol_data['expressao'][:100]}...\n")
                        
                        if camada > 1:
                            try:
                                vars_orig = self.get_original_variables(horizonte, camada, pol_num)
                                f.write(f"Variáveis originais: {vars_orig}\n")
                                
                                # Detalha cada variável
                                f.write("Detalhes:\n")
                                for var_id in vars_orig:
                                    f.write(f"  x{var_id}: {data['variaveis'][var_id]}\n")
                            except Exception as e:
                                f.write(f"Erro ao rastrear variáveis: {str(e)}\n")
                
                f.write("\n" + "="*50 + "\n\n")
            
            f.write("=== FIM DO RASTREAMENTO ===")
    
    def exportar_penultima_camada(self, arquivo_saida: str = "penultima_camada.txt") -> None:
        """Exporta informações do primeiro polinômio da penúltima camada de cada horizonte (formato texto)"""
        with open(arquivo_saida, 'w', encoding='utf-8') as f:
            f.write("=== PRIMEIRO POLINÔMIO DA PENÚLTIMA CAMADA - POR HORIZONTE ===\n\n")
            
            for horizonte, data in sorted(self.horizontes.items()):
                f.write(f"=== HORIZONTE {horizonte} ===\n")
                
                # Encontra a penúltima camada
                camadas = sorted(data['camadas'].keys())
                if len(camadas) < 2:
                    f.write("Aviso: Horizonte com menos de 2 camadas - não há penúltima camada\n\n")
                    continue
                
                penultima_camada = camadas[-2]  # Penúltimo elemento da lista ordenada
                f.write(f"Penúltima camada: {penultima_camada}\n")
                
                # Pega o primeiro polinômio
                try:
                    polinomio = data['camadas'][penultima_camada][1]
                    f.write(f"\nPolinômio 1 da Camada {penultima_camada}:\n")
                    f.write(f"Expressão completa: {polinomio['expressao']}\n")
                    
                    # Obtém variáveis originais
                    vars_orig = self.get_original_variables(horizonte, penultima_camada, 1)
                    f.write(f"\nVariáveis originais: {vars_orig}\n")
                    
                    # Detalha cada variável
                    f.write("\nDetalhes das variáveis:\n")
                    for var_id in vars_orig:
                        f.write(f"x{var_id}: {data['variaveis'][var_id]}\n")
                    
                    # Mostra a árvore de dependências em texto
                    f.write("\nÁrvore de dependências:\n")
                    self._escrever_arvore_dependencias(f, horizonte, penultima_camada, 1)
                    
                except Exception as e:
                    f.write(f"\nErro ao processar polinômio: {str(e)}\n")
                
                f.write("\n" + "="*50 + "\n\n")
            
            f.write("=== FIM DO RELATÓRIO ===")

    def _escrever_arvore_dependencias(self, arquivo, horizonte: int, camada: int, polinomio: int, nivel: int = 0, visitados: Set[Tuple[int, int, int]] = None) -> None:
        """Auxiliar para escrever a árvore de dependências formatada (texto)"""
        if visitados is None:
            visitados = set()
            
        chave = (horizonte, camada, polinomio)
        if chave in visitados:
            arquivo.write("  " * nivel + f"↳ [C{camada}P{polinomio}] (recursão)\n")
            return
            
        visitados.add(chave)
        
        pol_info = self.horizontes[horizonte]['camadas'][camada][polinomio]
        arquivo.write("  " * nivel + f"↳ [C{camada}P{polinomio}]: {pol_info['expressao'][:60]}...\n")
        
        for tipo, num in pol_info['dependencias']:
            if tipo == 'x':
                arquivo.write("  " * (nivel+1) + f"→ x{num}: {self.horizontes[horizonte]['variaveis'][num]}\n")
            elif tipo == 'p':
                if camada > 1:  # Só rastreia se não for a primeira camada
                    self._escrever_arvore_dependencias(arquivo, horizonte, camada-1, num, nivel+1, visitados)

    # ========== NOVOS MÉTODOS PARA HTML INTERATIVO ==========
    def exportar_penultima_camada_html(self, arquivo_saida: str = "penultima_camada.html") -> None:
        """Exporta a penúltima camada como um diagrama interativo HTML (árvore de dependências)."""
        html_content = []
        html_content.append("""<!DOCTYPE html>
    <html lang="pt">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>PrevIA- Árvore de Dependências</title>
        <script src="https://d3js.org/d3.v7.min.js"></script>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                margin: 0;
                background-color: #f5f5f5;
                color: #333;
            }
            .container {
                max-width: 1200px;
                margin: 20px auto;
                padding: 20px;
                background: white;
                border-radius: 8px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            h1 {
                color: #2c3e50;
            }
            h3 {
                color: #2c3e50;
                border-bottom: 2px solid #3498db;
                padding-bottom: 10px;
            }                            
            .horizonte {
                margin-bottom: 40px;
                border: 1px solid #ddd;
                border-radius: 8px;
                overflow: hidden;
                background: white;
            }
            .horizonte-header {
                background: #3498db;
                color: white;
                padding: 10px 15px;
                cursor: pointer;
                font-weight: bold;
            }
            .horizonte-header:hover {
                background: #2980b9;
            }
            .horizonte-content {
                padding: 20px;
                display: none;
            }
            .tree-container {
                width: 100%;
                min-height: 500px;
                border: 1px solid #eee;
                background: #fafafa;
                border-radius: 4px;
                overflow: auto;
                position: relative;
            }
            svg {
                display: block;
                margin: 0 auto;
                font-family: monospace;
            }
            .node circle {
                fill: #fff;
                stroke: steelblue;
                stroke-width: 1.5px;
            }
            .node text {
                font-size: 12px;
                fill: #333;
            }
            .link {
                fill: none;
                stroke: #ccc;
                stroke-width: 1.5px;
            }
            .tooltip {
                position: absolute;
                background: rgba(0,0,0,0.8);
                color: white;
                padding: 5px 10px;
                border-radius: 4px;
                font-size: 12px;
                pointer-events: none;
                z-index: 10;
            }
            .var-detail {
                margin-top: 15px;
                padding: 10px;
                background: #f0f7ff;
                border-left: 4px solid #3498db;
                font-size: 14px;
            }
            .var-detail strong {
                color: #2c3e50;
            }
            .controls {
                margin-bottom: 10px;
            }
            button {
                background: #2c3e50;
                color: white;
                border: none;
                padding: 6px 12px;
                margin-right: 10px;
                border-radius: 4px;
                cursor: pointer;
            }
            button:hover {
                background: #1a252f;
            }
        </style>
    </head>
    <body>
    <div class="container">                  
        <h1>PrevIA - Árvore de Dependências</h1>
        <h3>Desenvolvido pelo Centro de Pesquisas de Energia Elétrica - CEPEL</h3>
<div style="font-family: system-ui, -apple-system, Arial, sans-serif; 
            max-width: 850px; 
            padding: 20px; 
            background-color: #f9f9f9; 
            border-radius: 8px; 
            border: 1px solid #e0e0e0; 
            line-height: 1.7; 
            color: #333;">

    <h2 style="color: #1a73e8;">Como interpretar o diagrama</h2>
    
    <p><strong>Clique nos cabeçalhos</strong> para expandir ou colapsar cada horizonte.</p>
    
    <p>O diagrama apresenta o <strong>primeiro polinômio da última camada considerada</strong>, 
    juntamente com todas as suas dependências recursivas.</p>
    
    <p>Os dados completos estão disponíveis no arquivo 
    <strong style="color: #d32f2f;">“rastreamento_xxx.txt”</strong>.</p>
    
    <div style="background-color: #fff3cd; 
                padding: 12px 16px; 
                border-left: 5px solid #ffc107; 
                margin: 15px 0; 
                border-radius: 4px;">
        <strong>Importante:</strong> A última camada válida para o polinômio é a <strong>penúltima</strong>. 
        A última camada presente no arquivo é descartada durante o processo de convergência.
    </div>

</div>                                                    
    """)
        
        for horizonte, data in sorted(self.horizontes.items()):
            camadas = sorted(data['camadas'].keys())
            if len(camadas) < 2:
                continue
            penultima_camada = camadas[-2]
            try:
                polinomio = data['camadas'][penultima_camada][1]
                # Construir árvore de dependências
                tree_data = self._build_tree_data(horizonte, penultima_camada, 1)
                import json
                tree_json = json.dumps(tree_data, ensure_ascii=False)
                
                # Obter lista de variáveis originais
                vars_orig = self.get_original_variables(horizonte, penultima_camada, 1)
                
                # Gerar bloco HTML para este horizonte
                html_content.append(f"""
    <div class="horizonte">
        <div class="horizonte-header" onclick="toggleHorizonte(this)">Horizonte {horizonte} - {penultima_camada} Camada(s)</div>
        <div class="horizonte-content">
            <div class="var-detail">
                <strong>Variáveis originais utilizadas:</strong> {', '.join(f'x{vid}' for vid in vars_orig)}<br>
                <strong>Expressão:</strong> {polinomio['expressao']}
            </div>
            <div class="controls">
                <button class="zoom-in-btn">Zoom +</button>
                <button class="zoom-out-btn">Zoom -</button>
                <button class="reset-zoom-btn">Reset</button>
            </div>
            <div id="tree-{horizonte}" class="tree-container"></div>
        </div>
    </div>
    <script>
        (function() {{
            const containerId = "tree-{horizonte}";
            const data = {tree_json};
            
            function drawTree() {{
                const container = document.getElementById(containerId);
                if (!container) return;
                // Limpar conteúdo anterior
                container.innerHTML = "";
                
                const width = container.clientWidth;
                const height = 500;
                const margin = {{ top: 40, right: 90, bottom: 40, left: 90 }};
                const innerWidth = width - margin.left - margin.right;
                const innerHeight = height - margin.top - margin.bottom;
                
                const svg = d3.select("#" + containerId)
                    .append("svg")
                    .attr("width", width)
                    .attr("height", height)
                    .append("g")
                    .attr("transform", `translate(${{margin.left}},${{margin.top}})`);
                
                const root = d3.hierarchy(data);
                const treeLayout = d3.tree().size([innerHeight, innerWidth]);
                treeLayout(root);
                
                // Links
                svg.selectAll(".link")
                    .data(root.links())
                    .enter()
                    .append("path")
                    .attr("class", "link")
                    .attr("d", d3.linkHorizontal()
                        .x(d => d.y)
                        .y(d => d.x)
                    );
                
                // Nodes
                const node = svg.selectAll(".node")
                    .data(root.descendants())
                    .enter()
                    .append("g")
                    .attr("class", "node")
                    .attr("transform", d => `translate(${{d.y}},${{d.x}})`);
                
                node.append("circle")
                    .attr("r", 8)
                    .style("fill", d => d.data.type === 'var' ? "#ffe6b3" : "#b3d9ff")
                    .on("mouseover", function(event, d) {{
                        const tooltip = d3.select("body").append("div")
                            .attr("class", "tooltip")
                            .style("left", (event.pageX + 10) + "px")
                            .style("top", (event.pageY - 20) + "px")
                            .html(d.data.desc);
                        tooltip.transition().duration(200).style("opacity", 0.9);
                    }})
                    .on("mouseout", function() {{
                        d3.selectAll(".tooltip").remove();
                    }});
                
                node.append("text")
                    .attr("dy", ".35em")
                    .attr("x", d => d.children ? -13 : 13)
                    .style("text-anchor", d => d.children ? "end" : "start")
                    .text(d => d.data.name);
                
                // Zoom
                const zoom = d3.zoom()
                    .scaleExtent([0.1, 4])
                    .on("zoom", (event) => {{
                        svg.attr("transform", event.transform);
                    }});
                d3.select("#" + containerId + " svg").call(zoom);
                
                // Armazenar referências para os botões
                const controls = document.querySelector(`#tree-{horizonte}`).closest('.horizonte-content').querySelector('.controls');
                const zoomInBtn = controls.querySelector('.zoom-in-btn');
                const zoomOutBtn = controls.querySelector('.zoom-out-btn');
                const resetBtn = controls.querySelector('.reset-zoom-btn');
                
                const svgSelection = d3.select("#" + containerId + " svg");
                zoomInBtn.onclick = () => {{
                    svgSelection.transition().call(zoom.scaleBy, 1.2);
                }};
                zoomOutBtn.onclick = () => {{
                    svgSelection.transition().call(zoom.scaleBy, 0.8);
                }};
                resetBtn.onclick = () => {{
                    svgSelection.transition().call(zoom.transform, d3.zoomIdentity);
                }};
            }}
            
            // Aguardar o carregamento do container
            if (document.readyState === 'loading') {{
                document.addEventListener('DOMContentLoaded', drawTree);
            }} else {{
                drawTree();
            }}
            // Redesenhar ao redimensionar a janela (opcional)
            window.addEventListener('resize', () => {{
                drawTree();
            }});
        }})();
    </script>
    """)
            except Exception as e:
                html_content.append(f"""
    <div class="horizonte">
        <div class="horizonte-header">Horizonte {horizonte}</div>
        <div class="horizonte-content">
            <p style="color: red;">Erro ao gerar árvore: {str(e)}</p>
        </div>
    </div>
    """)
        
        html_content.append("""
    </div>
    <script>
    function toggleHorizonte(header) {
        const content = header.nextElementSibling;
        if (content.style.display === "none" || !content.style.display) {
            content.style.display = "block";
            // Disparar redesenho da árvore quando expandir (já que pode ter sido redimensionada)
            const containers = content.querySelectorAll('.tree-container');
            containers.forEach(container => {
                // Simula resize para redesenhar
                window.dispatchEvent(new Event('resize'));
            });
        } else {
            content.style.display = "none";
        }
    }
    // Inicializar todos os conteúdos como ocultos
    document.querySelectorAll('.horizonte-content').forEach(el => el.style.display = 'none');
    </script>
    </body>
    </html>
    """)
        
        with open(arquivo_saida, 'w', encoding='utf-8') as f:
            f.write('\n'.join(html_content))
        print(f"Relatório HTML gerado: {arquivo_saida}")

    def _build_tree_data(self, horizonte: int, camada: int, polinomio: int) -> dict:
        """Constrói um dicionário hierárquico para a árvore de dependências (formato para D3.js)."""
        pol_info = self.horizontes[horizonte]['camadas'][camada][polinomio]
        node = {
            "name": f"C{camada}P{polinomio}",
            "desc": f"Polinômio {polinomio} da camada {camada}: {pol_info['expressao'][:80]}",
            "type": "pol",
            "children": []
        }
        for tipo, num in pol_info['dependencias']:
            if tipo == 'x':
                var_name = self.horizontes[horizonte]['variaveis'][num]
                child = {
                    "name": f"x{num}",
                    "desc": f"Variável original: {var_name}",
                    "type": "var"
                }
                node["children"].append(child)
            elif tipo == 'p' and camada > 1:
                child = self._build_tree_data(horizonte, camada-1, num)
                node["children"].append(child)
        return node

# ======================================================================
# Aba 4: Prev-Saz (com gráfico, tabela de previsões e tabela de sigmas mensais)
# ======================================================================

class PrevSazPage(tb.Frame):
    """
    Aba Prev-Saz (decomposição sazonal clássica + ARIMA opcional nos resíduos),
    com salvamento automático do Excel em plan/ e geração de relatório HTML em relat/.
    """
    def __init__(self, master):
        super().__init__(master)
        self._build_vars()
        self._load_paths()
        self._build_ui()

    # -----------------------
    # Estado / Variáveis
    # -----------------------
    def _build_vars(self):
        # Preferências
        self.csv_path    = tk.StringVar(value="")
        self.periodo     = tk.IntVar(value=12)   # sazonalidade padrão (mensal)
        self.n_futuro    = tk.IntVar(value=12)   # meses de previsão futura
        self.use_arima   = tk.IntVar(value=1)    # 1=usar ARIMA nos resíduos
        self.auto_excel  = tk.IntVar(value=1)    # 1=salvar Excel automaticamente

        # === NOVO: Preferências do relatório HTML (expostas na UI) ===
        self.usar_sigma_por_raiz_n = tk.IntVar(value=0)       # 0/1
        self.ic_grafico_nivel      = tk.StringVar(value="95") # "95","90","80","70","50"
        self.casas_decimais        = tk.IntVar(value=2)       # 0..6
        self.separador_milhar      = tk.IntVar(value=0)       # 0/1
        # === NOVO: Fonte do sigma para IC (global vs sazonal) ===
        self.ic_sigma_modo         = tk.StringVar(value="sazonal")  # "sazonal" ou "global"

        # Resultados e caminho do último Excel gerado
        self.resultados  = None
        (BASE_PATH / "plan").mkdir(exist_ok=True)   # garante pasta plan/
        (BASE_PATH / "relat").mkdir(exist_ok=True)  # garante pasta relat/
        self.excel_path  = BASE_PATH / "plan" / "resultados_previsao.xlsx"

        # === NOVO: caminho do último relatório HTML ===
        self.relatorio_html_path = BASE_PATH / "relat" / "prevsaz.html"
        self.csv_path = tk.StringVar(value="")

    def _load_paths(self):
        paths = load_file_paths().get("prev_saz", {})
        if "csv_path" in paths and Path(paths["csv_path"]).exists():
            self.csv_path.set(paths["csv_path"])

    def _save_paths(self):
        paths = load_file_paths()
        paths["prev_saz"] = {"csv_path": self.csv_path.get()}
        save_file_paths(paths)

    # -----------------------
    # UI
    # -----------------------
    def _build_ui(self):
        frame_left  = tb.Frame(self, padding=2)
        frame_right = tb.Frame(self, padding=2)
        frame_left.grid(row=0, column=0, sticky="nsew")
        frame_right.grid(row=0, column=1, sticky="nsew")

        # Esquerda mais larga
        self.columnconfigure(0, weight=3)
        self.columnconfigure(1, weight=2)
        self.rowconfigure(0, weight=1)

        # ---------------------------
        # ESQUERDA: Controles
        # ---------------------------
        tb.Label(frame_left, text="Prev-Saz", font=("Segoe UI", 22, "bold"))\
          .grid(row=0, column=0, sticky="w", pady=(0,8))

        tb.Label(frame_left, text="Decomposição sazonal clássica + tendência (regressão) + ARIMA opcional nos resíduos")\
          .grid(row=1, column=0, sticky="w")

        # Seleção do CSV
        row_csv = tb.Frame(frame_left); row_csv.grid(row=2, column=0, sticky="ew", pady=8)
        row_csv.columnconfigure(0, weight=1)
        tb.Label(row_csv, text="Arquivo CSV com todo o histórico:").grid(row=0, column=0, sticky="w")
        ent_csv = tb.Entry(row_csv, textvariable=self.csv_path, width=90); ent_csv.grid(row=1, column=0, sticky="ew")
        tb.Button(row_csv, text="Buscar", bootstyle="primary",
                  command=self._select_csv).grid(row=1, column=1, padx=8)

        # Parâmetros
        params = tb.Labelframe(frame_left, text="Parâmetros")
        params.grid(row=3, column=0, sticky="ew", pady=8,)
        tb.Label(params, text="Sazonalidade (período):").grid(row=0, column=0, sticky="e", padx=5)
        tb.Spinbox(params, from_=2, to=24, textvariable=self.periodo, width=6).grid(row=0, column=1, sticky="w")

        tb.Label(params, text="Passos futuros (meses):").grid(row=1, column=0, sticky="e", padx=5)
        tb.Spinbox(params, from_=1, to=60, textvariable=self.n_futuro, width=6).grid(row=1, column=1, sticky="w")

        tb.Checkbutton(params, text="Modelar resíduos com ARIMA", variable=self.use_arima,
                       bootstyle="success").grid(row=2, column=0, columnspan=3, sticky="w", pady=(6,0), padx=10)

        #tb.Checkbutton(params, text="Salvar Excel automaticamente (plan/)", variable=self.auto_excel,
        #               bootstyle="primary").grid(row=3, column=0, columnspan=3, sticky="w",pady=(6,0), padx=10)

        # === NOVO: Grupo de opções do Relatório HTML ===
        grup_html = tb.Labelframe(frame_left, text="Relatório HTML")
        grup_html.grid(row=4, column=0, sticky="ew", pady=8)
        grup_html.columnconfigure(1, weight=1)

        tb.Checkbutton(
            grup_html, text="Usar σ/√n (ajuste por amostras)",
            variable=self.usar_sigma_por_raiz_n, bootstyle="success"
        ).grid(row=0, column=0, columnspan=2, sticky="w", padx=10, pady=(4,2))

        tb.Label(grup_html, text="Nível do IC no gráfico:").grid(row=1, column=0, sticky="e", padx=5)
        cb_ic = tb.Combobox(
            grup_html, values=["95","90","80","70","50"],
            textvariable=self.ic_grafico_nivel, state="readonly", width=6
        )
        cb_ic.grid(row=1, column=1, sticky="w")

        tb.Label(grup_html, text="Casas decimais:").grid(row=2, column=0, sticky="e", padx=5)
        tb.Spinbox(grup_html, from_=0, to=6, textvariable=self.casas_decimais, width=6)\
          .grid(row=2, column=1, sticky="w")

        tb.Checkbutton(
            grup_html, text="Usar separador de milhar (pt-BR)",
            variable=self.separador_milhar, bootstyle="primary"
        ).grid(row=3, column=0, columnspan=2, sticky="w", padx=10, pady=(4,2))

        # === NOVO: Fonte do sigma para IC (global vs sazonal) ===
        tb.Label(grup_html, text="Sigma para IC:").grid(row=4, column=0, sticky="e", padx=5)
        cb_sigma_modo = tb.Combobox(
            grup_html, values=["sazonal", "global"],  # valores diretos na StringVar
            textvariable=self.ic_sigma_modo, state="readonly", width=8
        )
        cb_sigma_modo.grid(row=4, column=1, sticky="w")

        # ---------------------------
        # DIREITA: Log + Botões
        # ---------------------------
        tb.Label(frame_right, text="Log de Execução", font=("Segoe UI", 14, "bold")).grid(row=0, column=0, sticky="w")
        self.txtRun = ScrolledText(frame_right, height=25, width=70)
        self.txtRun.configure(font=("Courier", 10))
        self.txtRun.grid(row=1, column=0, sticky="nsew", pady=10)
        frame_right.rowconfigure(1, weight=1)

        btns = tb.Frame(frame_right); btns.grid(row=2, column=0, pady=8)
        tb.Button(btns, text="Executar",               bootstyle="primary",   command=self._executar).grid(row=0, column=0, padx=5)
        self.saz_plan = tb.Button(btns, text="Planilha",  bootstyle="info",      command=self._abrir_excel, state="disabled")
        self.saz_plan.grid(row=0, column=2, padx=5)
        self.saz_relat = tb.Button(btns, text="Relatório",   bootstyle="success",   command=self._abrir_relatorio_html, state="disabled")
        self.saz_relat.grid(row=0, column=1, padx=5)
        tb.Button(btns, text="Ajuda",                  bootstyle="dark", command=self._ajuda).grid(row=0, column=3, padx=5)
        tb.Button(btns, text="Fechar",                 bootstyle="danger",    command=self._fechar).grid(row=0, column=4, padx=5)

    # -----------------------
    # Ações de UI
    # -----------------------
    def _select_csv(self):
        sel = pick_file("Selecionar CSV", (("CSV", "*.csv"), ("Todos", "*.*")))
        if sel:
            self.csv_path.set(sel)
            self._save_paths()   # <-- NOVO

    def _log(self, text: str):
        self.txtRun.insert(tk.END, text + "\n")
        self.txtRun.see(tk.END)
        self.txtRun.update_idletasks()

    def _fechar(self):
        self.winfo_toplevel().destroy()

    def _ajuda(self):
        help_path = BASE_PATH / "manuais" / "manual-prevsaz.html"
        if help_path.exists():
            open_system_file(help_path)
        else:
            messagebox.showinfo("Ajuda", "Crie 'manuais/manual-prevsaz.html' com instruções do Prev-Saz.")

    def _abrir_excel(self):
        if self.excel_path.exists():
            open_system_file(self.excel_path)
        else:
            messagebox.showwarning("Planilha", "Nenhuma planilha gerada ainda.")

    # === NOVO: abrir relatório HTML ===
    def _abrir_relatorio_html(self):
        if self.relatorio_html_path.exists():
            open_system_file(self.relatorio_html_path)
        else:
            messagebox.showwarning("Relatório HTML", "Nenhum relatório HTML gerado ainda.")

    # -----------------------
    # Execução principal
    # -----------------------
    def _executar(self):
        # Validação
        path = self.csv_path.get().strip()
        if not path or not Path(path).is_file():
            messagebox.showerror("Erro", "Selecione um arquivo CSV válido.")
            return

        periodo = int(self.periodo.get())
        passos  = int(self.n_futuro.get())
        usar_arima   = bool(self.use_arima.get())
        salvar_excel = bool(self.auto_excel.get())

        try:
            self.txtRun.delete("1.0", "end")
            self._log("Iniciando análise sazonal...")

            # 1) Ler CSV
            (valores, meses_nomes, meses_num, anos_num,
             primeiro_mes, primeiro_ano, ultimo_mes, ultimo_ano) = self._ler_csv(path)
            if valores is None:
                self._log("✗ Falha na leitura do CSV.")
                return

            serie = pd.Series(valores, index=range(len(valores)))
            self._log(f"Arquivo: {Path(path).name} • Registros: {len(valores)}")
            self._log(f"Período: {primeiro_mes}/{primeiro_ano} a {ultimo_mes}/{ultimo_ano}")

            # 2) Média móvel centrada e índices sazonais
            mm_centrada = self._mm_centrada(serie, periodo)
            indices_individual, mm_alinhada = self._indices_sazonais(serie, mm_centrada, meses_num, anos_num, periodo)
            indices_intervalo = self._indice_intervalo(indices_individual, periodo)

            # 3) Tendência (regressão linear estilo Excel)
            modelo_tendencia = self._tendencia_excel(mm_alinhada)

            # 4) Futuros (x) e MM projetada
            ultimo_idx = serie.index[-1]
            X_futuro   = np.arange(ultimo_idx + 1, ultimo_idx + 1 + passos)
            mm_proj    = modelo_tendencia.predict(X_futuro)

            # Meses futuros sequenciais
            meses_futuros, meses_num_fut, anos_fut = self._meses_futuros(ultimo_mes, ultimo_ano, passos)

            # 5) Sem tendência
            prev_hist_sem, prev_fut_sem, mm_media_mes = self._prev_sem_tend(
                serie, mm_alinhada, indices_intervalo, meses_num, anos_num, periodo
            )

            # 6) Com tendência (histórico e futuro)
            prev_hist_com = self._prev_hist_com_tendencia(
                serie, meses_nomes, meses_num, periodo, modelo_tendencia, indices_intervalo
            )
            prev_fut_com = [mm_proj[i] * indices_intervalo[(meses_num_fut[i]-1) % periodo]
                            for i in range(len(meses_num_fut))]

            # 7) Erros
            erros_com = self._erros(pd.Series(prev_hist_com, index=serie.index), serie, "Com Tendência")
            erros_sem = self._erros(prev_hist_sem, serie, "Sem Tendência")

            # 8) ARIMA (opcional)
            if usar_arima and STATSMODELS_AVAILABLE:
                (prev_hist_adj, prev_fut_adj,
                 res_hist_model, res_fut_model) = self._prev_ajustada_residuos(
                    serie, prev_hist_com, pd.Series(prev_fut_com), meses_num, anos_num, meses_futuros
                )
                etiqueta_prev_plot = "Ajustado (ARIMA: resíduos previstos)"
                fonte_prev_plot = "Com tendência + correção por resíduos ARIMA"
                erros_adj = self._erros(prev_hist_adj, serie, "Ajustado ARIMA")
            elif usar_arima and not STATSMODELS_AVAILABLE:
                self._log("⚠ 'statsmodels' não está instalado. Ignorando ARIMA.")
                prev_hist_adj  = pd.Series(prev_hist_com, index=serie.index)
                prev_fut_adj   = np.array(prev_fut_com)
                res_hist_model = pd.Series([0]*len(prev_hist_adj), index=prev_hist_adj.index)
                res_fut_model  = pd.Series([0]*len(prev_fut_com))
                erros_adj      = self._erros(prev_hist_adj, serie, "Ajustado ARIMA")
                
                etiqueta_prev_plot = "Com Tendência (ARIMA indisponível)"
                fonte_prev_plot = "Com tendência (fallback: sem ARIMA)"

            else:
                prev_hist_adj  = pd.Series(prev_hist_com, index=serie.index)
                prev_fut_adj   = np.array(prev_fut_com)
                res_hist_model = pd.Series([0]*len(prev_hist_adj), index=prev_hist_adj.index)
                res_fut_model  = pd.Series([0]*len(prev_fut_com))
                erros_adj      = self._erros(prev_hist_adj, serie, "Ajustado ARIMA")               
                etiqueta_prev_plot = "Com Tendência (ARIMA desligado)"
                fonte_prev_plot = "Com tendência (sem ARIMA)"
            self._log(f"Previsão plotada: {etiqueta_prev_plot}")
            # 9) Consolidar resultados
            self.resultados = {
                'serie_original': serie,
                'previsoes_com_tendencia_futuro': prev_fut_com,
                'previsoes_ajustadas_futuro': prev_fut_adj,
                'previsoes_com_tendencia_historico': pd.Series(prev_hist_com, index=serie.index),
                'previsoes_ajustadas_historico': prev_hist_adj,
                'previsoes_sem_tendencia_historico': prev_hist_sem,
                'previsoes_sem_tendencia_futuro': pd.Series(prev_fut_sem),                
                'n_futuro': passos,
                'fonte_prev_plot': fonte_prev_plot,
                'etiqueta_prev_plot': etiqueta_prev_plot,
                'fonte_prev_plot': fonte_prev_plot,
                'etiqueta_prev_plot': etiqueta_prev_plot,
                'residuos_modelados_futuro': res_fut_model,
                'residuos_modelados_historico': res_hist_model,
                'erros_com_tendencia': erros_com,
                'erros_sem_tendencia': erros_sem,
                'erros_ajustados': erros_adj,
                'indices_sazonais': indices_intervalo,
                'meses_futuros': meses_futuros,
                'meses_nomes': meses_nomes,
                'meses_numericos': meses_num,
                'modelo_tendencia': modelo_tendencia,
                'mm_alinhada': mm_alinhada,
                'mm_media_por_mes': mm_media_mes,
                'primeiro_mes': primeiro_mes, 'primeiro_ano': primeiro_ano,
                'ultimo_mes': ultimo_mes, 'ultimo_ano': ultimo_ano
            }

            # 10) Salvamento automático do Excel em plan/
            if salvar_excel:
                carimbo = datetime.now().strftime("%Y%m%d_%H%M")
                #self.excel_path = BASE_PATH / "plan" / f"resultados_previsao_{carimbo}.xlsx"
                self.excel_path = BASE_PATH / "plan" / f"resultados_previsao.xlsx"
                ok = self._exportar_para_excel(self.resultados, caminho_saida=str(self.excel_path))
                if ok:
                    self._log(f"✓ Excel salvo em: {self.excel_path}")

            # 11) Gerar relatório HTML em relat/
            try:
                self._gerar_relatorio_html(
                    usar_sigma_por_raiz_n=bool(self.usar_sigma_por_raiz_n.get()),
                    ic_grafico_nivel=int(self.ic_grafico_nivel.get()),
                    casas_decimais=int(self.casas_decimais.get()),
                    separador_milhar=bool(self.separador_milhar.get()),
                    modo_sigma_ic=str(self.ic_sigma_modo.get()).lower()  # "sazonal" ou "global"
                )
                self._log(f"✓ HTML salvo em: {self.relatorio_html_path}")
            except Exception as e:
                self._log(f"⚠ Falha ao gerar HTML: {e}")

            # Resumo no log
            melhor = "Ajustado ARIMA" if (erros_adj['mape'] < erros_com['mape']) else "Com Tendência"
            mape_melhor = min(erros_adj['mape'], erros_com['mape'])
            self._log(f"Melhor: {melhor} • MAPE: {mape_melhor:.2f}% • Futuros: {passos} meses")
            self._log("Concluído.")
            self.saz_plan.config(state="normal")
            self.saz_relat.config(state="normal")
            

        except Exception as e:
            import traceback
            self._log(f"✗ Erro: {e}")
            self._log(traceback.format_exc())

    # -----------------------
    # Funções auxiliares de processamento (mantidas)
    # -----------------------
    @staticmethod
    def _ler_csv(caminho_arquivo):
        try:
            df = pd.read_csv(caminho_arquivo, encoding='latin1', delimiter=';', decimal=',', header=0)
            if df.shape[1] < 4:
                raise ValueError("O arquivo deve ter pelo menos 4 colunas (dia;mes;ano;valor)")
            dados, meses_nomes, meses_num, anos_num = [], [], [], []
            nomes = ['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro']
            for _, row in df.iterrows():
                dia = int(row.iloc[0]) if pd.notna(row.iloc[0]) else 1
                mes = int(row.iloc[1]) if pd.notna(row.iloc[1]) else 1
                ano = int(row.iloc[2]) if pd.notna(row.iloc[2]) else 2000
                val = float(row.iloc[3]) if pd.notna(row.iloc[3]) else np.nan
                dados.append(val)
                nome_mes = nomes[mes-1] if 1 <= mes <= 12 else f"mês_{mes}"
                meses_nomes.append(f"{nome_mes}/{ano}")
                meses_num.append(mes)
                anos_num.append(ano)
            return (dados, meses_nomes, meses_num, anos_num,
                    meses_num[0], anos_num[0], meses_num[-1], anos_num[-1])
        except Exception as e:
            print(f"Erro ao ler CSV: {e}")
            return (None, None, None, None, None, None, None, None)

    @staticmethod
    def _mm_centrada(serie, periodo=12):
        mm_simples   = serie.rolling(window=periodo, center=False).mean()
        mm_centrada  = mm_simples.rolling(window=2, center=True).mean()
        return mm_centrada

    @staticmethod
    def _encontrar_primeira_mm(mm_centrada, meses_num, anos_num):
        idx_validos = mm_centrada.dropna().index
        if len(idx_validos) == 0: return (None, None)
        primeiro_mes, primeiro_ano = meses_num[0], anos_num[0]
        mes_mm = (primeiro_mes + 6) % 12 or 12
        ano_mm = primeiro_ano + ((primeiro_mes + 6 - 1) // 12)
        return (mes_mm, ano_mm)

    def _alinhar_mm(self, mm_centrada, meses_num, anos_num):
        mes_mm, ano_mm = self._encontrar_primeira_mm(mm_centrada, meses_num, anos_num)
        if mes_mm is None: return pd.Series([np.nan]*len(mm_centrada), index=mm_centrada.index)
        mm_alinh = pd.Series([np.nan]*len(mm_centrada), index=mm_centrada.index)
        alvo0 = None
        for i,(m,a) in enumerate(zip(meses_num, anos_num)):
            if m == mes_mm and a == ano_mm: alvo0 = i; break
        if alvo0 is None: return mm_alinh
        for k, idx in enumerate(mm_centrada.dropna().index):
            j = alvo0 + k
            if j < len(mm_alinh):
                mm_alinh.iloc[j] = mm_centrada.iloc[idx]
        return mm_alinh

    def _indices_sazonais(self, serie, mm_centrada, meses_num, anos_num, periodo=12):
        mm_alinh = self._alinhar_mm(mm_centrada, meses_num, anos_num)
        ind_ind  = serie / mm_alinh
        por_mes  = {}
        for i, val in ind_ind.items():
            if not np.isnan(val) and i < len(meses_num):
                pos = (meses_num[i]-1) % periodo
                por_mes.setdefault(pos, []).append(val)
        return por_mes, mm_alinh

    @staticmethod
    def _indice_intervalo(indices_por_mes, periodo=12):
        idx = {}
        for m in range(periodo):
            vals = indices_por_mes.get(m, [])
            idx[m] = np.mean(vals) if len(vals) > 0 else 1.0
        soma = sum(idx.values())
        return {k: v/soma*len(idx) for k, v in idx.items()}

    @staticmethod
    def _tendencia_excel(mm_alinhada):
        vals = mm_alinhada.dropna()
        if len(vals) == 0: raise ValueError("Sem valores válidos para tendência.")
        x = np.array(vals.index); y = vals.values
        n = len(x); sx = x.sum(); sy = y.sum()
        sxy = (x*y).sum(); sx2 = (x*x).sum()
        den = n*sx2 - sx*sx
        incl = 0.0 if den == 0 else (n*sxy - sx*sy)/den
        inter = (sy - incl*sx)/n

        class ModeloExcel:
            def __init__(self, b, a): self.inclinacao=b; self.intercepto=a
            def predict(self, X):
                arr = np.array(X)
                return self.intercepto + self.inclinacao * arr
        return ModeloExcel(incl, inter)

    @staticmethod
    def _erros(prev, real, nome):
        prev = pd.Series(prev, index=real.index) if not isinstance(prev, pd.Series) else prev
        mask = ~prev.isna() & ~real.isna()
        pv = prev[mask].values; rv = real[mask].values
        if len(pv) == 0:
            return {'mae':np.nan,'mse':np.nan,'rmse':np.nan,'mape':np.nan,'n':0}
        mae = np.mean(np.abs(rv - pv))
        mse = np.mean((rv - pv)**2)
        rmse= np.sqrt(mse)
        mape= np.mean(np.abs((rv - pv)/rv))*100 if np.all(rv!=0) else np.nan
        return {'mae':mae,'mse':mse,'rmse':rmse,'mape':mape,'n':len(pv)}

    def _prev_sem_tend(self, serie, mm_alinhada, idx_intervalo, meses_num, anos_num, periodo=12):
        mms_por_mes = {}
        for i in range(len(serie)):
            if not np.isnan(mm_alinhada.iloc[i]) and i < len(meses_num):
                pos = (meses_num[i]-1) % periodo
                mms_por_mes.setdefault(pos, []).append(mm_alinhada.iloc[i])
        mm_media_mes = {pos: np.mean(vals) for pos, vals in mms_por_mes.items()}

        prev_hist = []
        for i in range(len(serie)):
            if i < len(meses_num):
                pos = (meses_num[i]-1) % periodo
                if pos in mm_media_mes:
                    prev_hist.append(mm_media_mes[pos] * idx_intervalo[pos])
                else:
                    todas = list(mm_media_mes.values())
                    mm_geral = np.mean(todas) if todas else np.nan
                    prev_hist.append(mm_geral * idx_intervalo[pos] if not np.isnan(mm_geral) else np.nan)
            else:
                prev_hist.append(np.nan)

        # Futuro placeholder (12) — retorno compatível; o futuro real é calculado em _executar
        fut = []
        for mes_num in range(1, periodo+1):
            pos = (mes_num-1) % periodo
            if pos in mm_media_mes:
                fut.append(mm_media_mes[pos] * idx_intervalo[pos])
            else:
                todas = list(mm_media_mes.values())
                mm_geral = np.mean(todas) if todas else np.nan
                fut.append(mm_geral * idx_intervalo[pos] if not np.isnan(mm_geral) else np.nan)

        return (pd.Series(prev_hist, index=serie.index),
                pd.Series(fut), mm_media_mes)

    def _prev_hist_com_tendencia(self, serie, meses_nomes, meses_num, periodo, modelo_tendencia, idx_intervalo):
        out = []
        for i in range(len(serie)):
            if i < len(meses_num):
                pos = (meses_num[i]-1) % periodo
                tend = float(modelo_tendencia.predict(i))
                out.append(tend * idx_intervalo[pos])
            else:
                out.append(np.nan)
        return out

    @staticmethod
    def _meses_futuros(ultimo_mes, ultimo_ano, quantidade=12):
        nomes = ['janeiro','fevereiro','março','abril','maio','junho',
                 'julho','agosto','setembro','outubro','novembro','dezembro']
        mf, mn, an = [], [], []
        m = ultimo_mes; a = ultimo_ano
        for _ in range(quantidade):
            m += 1
            if m > 12: m = 1; a += 1
            mf.append(f"{nomes[m-1]}/{a}"); mn.append(m); an.append(a)
        return mf, mn, an

    # === ARIMA nos resíduos ===

    def _prev_ajustada_residuos(self, serie, prev_hist_com, prev_fut_com_series, meses_num, anos_num, meses_futuros):
        """
        Ajusta ARIMA/SARIMAX nos resíduos com invertibilidade forçada.
        - Usa SARIMAX(res_clean, order=(p,d,q), enforce_invertibility=True, enforce_stationarity=True)
        - Seleção de ordem pelo menor AIC no mesmo grid de ordens que você já utiliza.
        - Mantém o mesmo contrato de retorno: (prev_hist_adj, prev_fut_adj, res_hist_model, res_fut_model)
        """
        if not STATSMODELS_AVAILABLE:
            prev_hist_adj  = pd.Series(prev_hist_com, index=serie.index)
            prev_fut_adj   = np.array(prev_fut_com_series.values)
            res_hist_model = pd.Series([0] * len(prev_hist_adj), index=prev_hist_adj.index)
            res_fut_model  = pd.Series([0] * len(prev_fut_com_series))
            return (prev_hist_adj, prev_fut_adj, res_hist_model, res_fut_model)

        # Importa SARIMAX para ter controle explícito sobre invertibilidade
        from statsmodels.tsa.statespace.sarimax import SARIMAX

        # Resíduos históricos
        residuos_hist = serie - pd.Series(prev_hist_com, index=serie.index)
        res_clean = residuos_hist.dropna()

        # Poucos dados -> retorna baseline
        if len(res_clean) < 10:
            prev_hist_adj  = pd.Series(prev_hist_com, index=serie.index)
            prev_fut_adj   = np.array(prev_fut_com_series.values)
            res_hist_model = pd.Series([0] * len(prev_hist_adj), index=prev_hist_adj.index)
            res_fut_model  = pd.Series([0] * len(prev_fut_com_series))
            return (prev_hist_adj, prev_fut_adj, res_hist_model, res_fut_model)

        # Grid de ordens (mantido)
        ordens = [(1,0,0),(0,0,1),(1,0,1),(1,1,0),(0,1,1),(1,1,1),(2,0,0),(0,0,2),(2,1,2)]

        # Seleção pelo menor AIC, forçando invertibilidade
        melhor_aic = np.inf
        melhor_fit = None
        melhor_ordem = None

        for ordem in ordens:
            try:
                # Força invertibilidade e estacionariedade durante a estimação
                modelo = SARIMAX(
                    res_clean,
                    order=ordem,
                    enforce_invertibility=True,
                    enforce_stationarity=True
                )
                fit = modelo.fit(disp=False)
                if fit.aic < melhor_aic:
                    melhor_aic = fit.aic
                    melhor_fit = fit
                    melhor_ordem = ordem
            except Exception:
                continue  # tenta próxima ordem

        # Se nada convergiu, retorna baseline
        if melhor_fit is None:
            prev_hist_adj  = pd.Series(prev_hist_com, index=serie.index)
            prev_fut_adj   = np.array(prev_fut_com_series.values)
            res_hist_model = pd.Series([0] * len(prev_hist_adj), index=prev_hist_adj.index)
            res_fut_model  = pd.Series([0] * len(prev_fut_com_series))
            return (prev_hist_adj, prev_fut_adj, res_hist_model, res_fut_model)

        # Previsão de resíduos (histórico dentro da janela e futuro)
        # Histórico previsto (mesma janela de res_clean)
        pred_hist = melhor_fit.get_prediction(
            start=res_clean.index[0],
            end=res_clean.index[-1]
        ).predicted_mean

        # Futuro previsto (n passos = meses_futuros)
        steps_fut = len(meses_futuros)
        pred_fut = melhor_fit.get_forecast(steps=steps_fut).predicted_mean

        # Ajusta as previsões com os resíduos previstos
        prev_hist_adj = pd.Series(prev_hist_com, index=serie.index).copy()
        mask = ~prev_hist_adj.isna()
        for idx in prev_hist_adj[mask].index:
            if idx in pred_hist.index:
                prev_hist_adj.loc[idx] += float(pred_hist.loc[idx])

        prev_fut_adj = prev_fut_com_series.values + pred_fut.values

        # Retorna também as séries de resíduos modelados (histórico e futuro)
        return (prev_hist_adj, prev_fut_adj, pd.Series(pred_hist), pd.Series(pred_fut))

    # === Exportação para Excel (automática, em plan/) ===
    def _exportar_para_excel(self, res, caminho_saida="resultados_previsao.xlsx"):
        if not OPENPYXL_AVAILABLE:
            self._log("⚠ 'openpyxl' não está disponível. Instale: pip install openpyxl")
            return False
        try:
            # Matplotlib headless
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
            from io import BytesIO
            from openpyxl.drawing.image import Image as OpenpyxlImage

            out_path = Path(caminho_saida)
            if not out_path.is_absolute():
                out_path = BASE_PATH / "plan" / out_path
            out_path.parent.mkdir(exist_ok=True)

            # Gráfico 1: Observado x MM centrada
            buf1 = BytesIO()
            plt.figure(figsize=(12,6))
            plt.plot(res['serie_original'].index, res['serie_original'].values, label="Observado", lw=2)
            plt.plot(res['mm_alinhada'].index, res['mm_alinhada'].values, label="Tendência (MM centrada)", lw=2, color="red")
            plt.legend(); plt.grid(alpha=0.3); plt.tight_layout()
            plt.savefig(buf1, format="png", dpi=150); buf1.seek(0); plt.close()

            # Gráfico 2: Comparação com a previsão plotada explicitamente
            buf2 = BytesIO()
            plt.figure(figsize=(14,7))
            idx = res['serie_original'].index
            plt.plot(idx, res['serie_original'].values, label="Observado", color="black", lw=2)

            mask_val = ~res['previsoes_ajustadas_historico'].isna()
            plt.plot(
                idx[mask_val],
                res['previsoes_ajustadas_historico'][mask_val],
                label=f"{res.get('etiqueta_prev_plot','Previsão (Hist.)')}",
                color="green", lw=2
            )

            fut_idx = np.arange(
                len(res['serie_original']),
                len(res['serie_original']) + len(res['previsoes_ajustadas_futuro'])
            )
            plt.plot(
                fut_idx,
                res['previsoes_ajustadas_futuro'],
                label=f"{res.get('etiqueta_prev_plot','Previsão (Futuro)')}",
                color="red", lw=2, ls="--"
            )

            plt.axvline(x=len(res['serie_original'])-0.5, color='gray', ls=':', alpha=0.7)
            plt.legend(); plt.grid(alpha=0.3); plt.tight_layout()
            plt.savefig(buf2, format="png", dpi=150); buf2.seek(0); plt.close()


            with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
                # Dados Históricos
                df_hist = pd.DataFrame({
                    "Mês/Ano": res['meses_nomes'][:len(res['serie_original'])],
                    "Observado": res['serie_original'].values,
                    "Prev. Com Tendência": res['previsoes_com_tendencia_historico'].values,
                    "Prev. Ajustada (ARIMA)": res['previsoes_ajustadas_historico'].values,
                    "Prev. Sem Tendência": res['previsoes_sem_tendencia_historico'].values,
                    "MM centrada": res['mm_alinhada'].values
                })
                df_hist.to_excel(writer, sheet_name="Dados Históricos", index=False)

                # Previsões Futuras
                df_fut = pd.DataFrame({
                    "Mês/Ano": res['meses_futuros'],
                    "Prev. Com Tendência": res['previsoes_com_tendencia_futuro'],
                    "Prev. Ajustada (ARIMA)": res['previsoes_ajustadas_futuro'],
                    "Resíduo ARIMA": res['residuos_modelados_futuro'].values
                })
                df_fut.to_excel(writer, sheet_name="Previsões Futuras", index=False)

                # === NOVO: Aba com a Equação da Tendência ===
                try:
                    modelo = res.get('modelo_tendencia', None)
                    if modelo is not None:
                        a = float(getattr(modelo, 'intercepto', np.nan))
                        b = float(getattr(modelo, 'inclinacao', np.nan))
                        eq_str = f"y = {a:.6f} + {b:.6f} × x"

                        df_eq = pd.DataFrame({
                            "Item": ["Intercepto (a)", "Inclinação (b)", "Equação da Tendência"],
                            "Valor": [a, b, eq_str]
                        })
                        df_eq.to_excel(writer, sheet_name="Equação da Tendência", index=False)
                except Exception as e:
                    self._log(f"⚠ Falha ao escrever equação da tendência no Excel: {e}")

                # === NOVO: Bloco informativo sobre X e a faixa temporal ===
                try:
                    modelo = res.get('modelo_tendencia', None)
                    if modelo is not None:
                        a = float(getattr(modelo, 'intercepto', np.nan))
                        b = float(getattr(modelo, 'inclinacao', np.nan))

                        # formato com 6 casas ou você pode usar self.casas_decimais se preferir
                        eq_str = f"y = {a:.6f} + {b:.6f} × x"

                        # Faixa temporal e índices
                        primeiro_mes = res.get('primeiro_mes')
                        primeiro_ano = res.get('primeiro_ano')
                        ultimo_mes   = res.get('ultimo_mes')
                        ultimo_ano   = res.get('ultimo_ano')
                        n_total      = len(res['serie_original'])
                        idx_ini      = 0
                        idx_fim      = max(n_total - 1, 0)

                        # Tabela principal (já existente)
                        df_eq = pd.DataFrame({
                            "Item": ["Intercepto (a)", "Inclinação (b)", "Equação da Tendência"],
                            "Valor": [a, b, eq_str]
                        })
                        df_eq.to_excel(writer, sheet_name="Equação da Tendência", index=False)

                        # --- NOVO: Tabela complementar com explicação de X e faixa (primeiro/último mês/ano) ---
                        df_info = pd.DataFrame({
                            "Campo": [
                                "Definição de x",
                                "Primeiro dado (Mês/Ano)",
                                "Índice do primeiro dado (x)",
                                "Último dado (Mês/Ano)",
                                "Índice do último dado (x)",
                                "Total de pontos (n)"
                            ],
                            "Valor": [
                                "x é a ordem do dado na série: 0 no primeiro ponto, 1 no segundo, ..., (n-1) no último.",
                                f"{primeiro_mes:02d}/{primeiro_ano}",
                                idx_ini,
                                f"{ultimo_mes:02d}/{ultimo_ano}",
                                idx_fim,
                                n_total
                            ]
                        })

                        # Escreve a tabela complementar na mesma aba, logo abaixo
                        # (usando openpyxl para posicionar após df_eq)
                        wb = writer.book
                        sh = wb["Equação da Tendência"]
                        # Descobre a última linha preenchida e escreve df_info a partir dali + 2
                        start_row = sh.max_row + 2
                        # Converte df_info em linhas e escreve manualmente
                        from openpyxl.utils.dataframe import dataframe_to_rows
                        for r_idx, row in enumerate(dataframe_to_rows(df_info, index=False, header=True), start=start_row):
                            sh.append(row)
                except Exception as e:
                    self._log(f"⚠ Falha ao escrever equação/faixa no Excel: {e}")
                # Métricas
                df_met = pd.DataFrame({
                    "Métrica": ["MAE","RMSE","MAPE (%)","Amostras"],
                    "Com Tendência": [res['erros_com_tendencia']['mae'], res['erros_com_tendencia']['rmse'],
                                      res['erros_com_tendencia']['mape'], res['erros_com_tendencia']['n']],
                    "Ajustado ARIMA": [res['erros_ajustados']['mae'], res['erros_ajustados']['rmse'],
                                      res['erros_ajustados']['mape'], res['erros_ajustados']['n']],
                    "Sem Tendência": [res['erros_sem_tendencia']['mae'], res['erros_sem_tendencia']['rmse'],
                                      res['erros_sem_tendencia']['mape'], res['erros_sem_tendencia']['n']],
                })
                df_met.to_excel(writer, sheet_name="Métricas de Erro", index=False)

                # Índices sazonais
                nomes_mes = ['janeiro','fevereiro','março','abril','maio','junho',
                             'julho','agosto','setembro','outubro','novembro','dezembro']
                df_saz = pd.DataFrame({
                    "Mês": [nomes_mes[k].upper() for k in sorted(res['indices_sazonais'].keys())],
                    "Índice": [res['indices_sazonais'][k] for k in sorted(res['indices_sazonais'].keys())]
                })
                df_saz.to_excel(writer, sheet_name="Índices Sazonais", index=False)

                # Erros por mês
                df_err_mes = self._erros_por_mes(res['serie_original'],
                                                 res['previsoes_ajustadas_historico'],
                                                 res['meses_numericos'],
                                                 "Ajustado ARIMA")
                df_err_mes.to_excel(writer, sheet_name="Erros por Mês", index=False)

                # Gráficos
                wb = writer.book
                sh1 = wb.create_sheet("Gráfico Tendência")
                img1 = OpenpyxlImage(buf1); img1.width=700; img1.height=450; sh1.add_image(img1, "A1")
                sh2 = wb.create_sheet("Gráfico Comparação")
                img2 = OpenpyxlImage(buf2); img2.width=800; img2.height=500; sh2.add_image(img2, "A1")

            buf1.close(); buf2.close()
            return True
        except Exception as e:
            self._log(f"✗ Erro ao exportar Excel: {e}")
            return False

    @staticmethod
    def _erros_por_mes(serie, previsoes, meses_num, nome_modelo):
        erros_por_mes = {}
        for i in range(len(serie)):
            if i < len(meses_num) and not np.isnan(previsoes.iloc[i]) and not np.isnan(serie.iloc[i]):
                mes = meses_num[i]
                obs = serie.iloc[i]; prev = previsoes.iloc[i]
                err_abs = abs(obs - prev)
                err_pct = abs((obs - prev)/obs * 100) if obs != 0 else np.nan
                b = erros_por_mes.setdefault(mes, {"abs":[], "pct":[]})
                b["abs"].append(err_abs)
                if not np.isnan(err_pct): b["pct"].append(err_pct)
        out = []
        nomes = ['janeiro','fevereiro','março','abril','maio','junho',
                 'julho','agosto','setembro','outubro','novembro','dezembro']
        for m in range(1,13):
            b = erros_por_mes.get(m, None)
            if b:
                out.append({
                    "Mês": nomes[m-1].upper(), "Modelo": nome_modelo,
                    "Amostras": len(b["abs"]),
                    "MAE (média)": np.mean(b["abs"]),
                    "MAPE (média %)": np.mean(b["pct"]) if b["pct"] else np.nan,
                    "MAE (mediana)": np.median(b["abs"]),
                    "MAPE (mediana %)": np.median(b["pct"]) if b["pct"] else np.nan,
                    "Desvio Padrão MAE": np.std(b["abs"]),
                    "Desvio Padrão MAPE": np.std(b["pct"]) if b["pct"] else np.nan,
                    "Mínimo MAPE": np.min(b["pct"]) if b["pct"] else np.nan,
                    "Máximo MAPE": np.max(b["pct"]) if b["pct"] else np.nan,
                })
            else:
                out.append({
                    "Mês": nomes[m-1].upper(), "Modelo": nome_modelo,
                    "Amostras": 0,
                    "MAE (média)": np.nan,
                    "MAPE (média %)": np.nan,
                    "MAE (mediana)": np.nan,
                    "MAPE (mediana %)": np.nan,
                    "Desvio Padrão MAE": np.nan,
                    "Desvio Padrão MAPE": np.nan,
                    "Mínimo MAPE": np.nan,
                    "Máximo MAPE": np.nan,
                })
        return pd.DataFrame(out)

    # -----------------------
    # NOVO: Relatório HTML (como método da classe)
    # -----------------------
    def _gerar_relatorio_html(self,
                              usar_sigma_por_raiz_n=False,    # True -> usa σ/√n (apenas no modo sazonal)
                              ic_grafico_nivel=95,           # nível do IC mostrado no gráfico
                              casas_decimais=2,
                              separador_milhar=False,
                              modo_sigma_ic="sazonal"         # "sazonal" (por mês) ou "global"
                              ):
        """
        Gera relat/prevsaz.html com:
          - Tabela das previsões futuras (12) e ICs 95/90/80/70/50 usando sigma **global** ou **sazonal** (com opcional σ/√n por mês).
          - Gráfico dos últimos 12 observados + próximos 12 previstos com IC do nível escolhido (global ou mensal, conforme modo).
          - Tabela de sigmas por mês (sigma bruto, n, sigma ajustado σ/√n).
        """
        import os, io, base64
        import matplotlib.pyplot as plt

        if self.resultados is None:
            raise ValueError("resultados está vazio. Execute a análise antes de gerar o HTML.")

        # Caminho de saída
        caminho_arquivo_html = BASE_PATH / "relat" / "prevsaz.html"
        os.makedirs(caminho_arquivo_html.parent, exist_ok=True)

        # Extrair objetos
        res         = self.resultados
        serie       = res['serie_original']
        prev_hist   = res['previsoes_ajustadas_historico']   # baseline para resíduos
        prev_fut    = list(res['previsoes_ajustadas_futuro'])
        etq_prev = str(res.get('etiqueta_prev_plot', 'Previsão'))
        fonte_prev = str(res.get('fonte_prev_plot', ''))
        meses_hist  = res['meses_nomes']
        meses_fut   = res['meses_futuros']
        meses_num_h = res['meses_numericos']


        # Últimos N observados, onde N = n_futuro (limitado ao tamanho da série)
        n_futuro = int(res.get('n_futuro', 12))
        ult_n = min(n_futuro, len(serie))  # evita passar do tamanho da série

        obs_ultN        = serie.iloc[-ult_n:]
        meses_hist_ultN = meses_hist[-ult_n:]


        # Resíduos históricos e sigma global
        resid = serie - prev_hist
        try:
            sigma_global = float(np.nanstd(resid.values))
        except Exception:
            sigma_global = np.nan
        if np.isnan(sigma_global) or sigma_global == 0:
            sigma_global = float(res.get('erros_ajustados', {}).get('rmse', np.nan))
        if np.isnan(sigma_global) or sigma_global == 0:
            sigma_global = float(res.get('erros_com_tendencia', {}).get('rmse', np.nan))
        if np.isnan(sigma_global) or sigma_global == 0:
            sigma_global = 1e-6

        # --- NOVO: n_global e sigma_global ajustado por √n ---
        n_global = int(np.sum(~np.isnan(resid.values)))  # número de resíduos válidos
        n_global = max(n_global, 1)                      # evita divisão por zero
        sigma_global_ajustado = (sigma_global / np.sqrt(n_global)) if usar_sigma_por_raiz_n else sigma_global

        # Sigma por mês (1..12) e n por mês
        residuos_por_mes = {m: [] for m in range(1, 13)}
        for i in range(len(serie)):
            if i < len(meses_num_h):
                mnum = int(meses_num_h[i])
                if 1 <= mnum <= 12:
                    r = resid.iloc[i]
                    if not np.isnan(r):
                        residuos_por_mes[mnum].append(float(r))

        sigma_por_mes = {}
        n_por_mes     = {}
        for m in range(1, 13):
            vals = np.array(residuos_por_mes[m], dtype=float)
            n_m  = int(np.sum(~np.isnan(vals))) if vals.size > 0 else 0
            n_por_mes[m] = n_m
            if vals.size >= 2 and not np.all(np.isnan(vals)):
                sdm = float(np.nanstd(vals))
                if np.isnan(sdm) or sdm == 0:
                    sdm = sigma_global
            else:
                sdm = sigma_global
            sigma_por_mes[m] = sdm

        # Sigma ajustado (σ/√n) por mês (aplicado apenas se modo sazonal e usar_sigma_por_raiz_n=True)
        sigma_ajustado_por_mes = {}
        for m in range(1, 13):
            n_m = max(n_por_mes[m], 1)
            sigma_ajustado_por_mes[m] = (sigma_por_mes[m] / np.sqrt(n_m)) if usar_sigma_por_raiz_n else sigma_por_mes[m]

        # Mapear nomes de meses futuros para número (para usar sigma mensal correto)
        mapa_mes_nome_num = {
            'janeiro': 1, 'fevereiro': 2, 'março': 3, 'marco': 3, 'abril': 4,
            'maio': 5, 'junho': 6, 'julho': 7, 'julio': 7, 'agosto': 8,
            'setembro': 9, 'outubro': 10, 'novembro': 11, 'dezembro': 12
        }
        def extrair_num_mes(label):
            try:
                nome = str(label).split('/')[0].strip().lower()
                return mapa_mes_nome_num.get(nome, None)
            except Exception:
                return None
        meses_num_fut = [extrair_num_mes(x) for x in meses_fut]

        # Z-scores e ICs futuros
        zmap = {95: 1.96, 90: 1.645, 80: 1.282, 70: 1.036, 50: 0.674}

        cis = {}
        # Modo legível para rótulos
        modo_leg = "mensal" if str(modo_sigma_ic).lower() == "sazonal" else "global"

        for level, z in zmap.items():
            upper, lower = [], []
            for j, yhat in enumerate(prev_fut):
                if str(modo_sigma_ic).lower() == "global":
                    # --- NOVO: aplica σ_global/√n quando a opção estiver ativada ---
                    sigma_use = sigma_global_ajustado
                else:
                    mnum = meses_num_fut[j] if j < len(meses_num_fut) else None
                    # mensal com ou sem σ/√n, já calculado em sigma_ajustado_por_mes
                    if mnum is None:
                        # fallback seguro
                        sigma_use = sigma_global
                    else:
                        sigma_use = sigma_ajustado_por_mes.get(mnum, sigma_global)
                upper.append(yhat + z * sigma_use)
                lower.append(yhat - z * sigma_use)
            cis[level] = {'upper': upper, 'lower': lower}

        # Gráfico (IC do nível escolhido)
        nivel = int(ic_grafico_nivel) if int(ic_grafico_nivel) in zmap else 95
        fig, ax = plt.subplots(figsize=(12, 6))

        ax.plot(
            range(len(obs_ultN)),
            obs_ultN.values,
            label=f"Observado (últimos {ult_n})",
            color="#1f77b4", linewidth=2
        )


        x_offset = len(obs_ultN)
        ax.plot(range(x_offset, x_offset + len(prev_fut)), prev_fut,
                label=f"{etq_prev} (próximos {len(prev_fut)})", color="#ff7f0e", linewidth=2,
                linestyle='--', marker='o')

        upperN = cis[nivel]['upper']
        lowerN = cis[nivel]['lower']

        ax.plot(
            range(x_offset, x_offset + len(prev_fut)), upperN,
            label=f"IC {nivel}% (Superior, {modo_leg})", color="#2ca02c", linestyle=':'
        )
        ax.plot(
            range(x_offset, x_offset + len(prev_fut)), lowerN,
            label=f"IC {nivel}% (Inferior, {modo_leg})", color="#d62728", linestyle=':'
        )


        ax.axvline(x=x_offset - 0.5, color="gray", linestyle=":", alpha=0.6)
        
        # Rótulos do eixo X
        labels = meses_hist_ultN + meses_fut
        ax.set_xticks(range(x_offset + len(prev_fut)))
        ax.set_xticklabels(labels, rotation=45, ha="right")
        #ax.set_title(f"Observados (12) e Previsões (12) com IC {nivel}% ({modo_leg})")
        ax.set_title(f"Observados ({ult_n}) e {etq_prev} ({len(prev_fut)}) • IC {nivel}% ({modo_leg})")
        ax.set_xlabel("Mês/Ano")
        ax.set_ylabel("Valor")
        ax.grid(alpha=0.3)
        plt.tight_layout()

        # Base64 da figura
        buf = io.BytesIO()
        plt.savefig(buf, format='png', dpi=150)
        plt.close(fig)
        img_b64 = base64.b64encode(buf.getvalue()).decode('ascii')

        # Tabela de previsões e ICs (todos os níveis)
        col_suf = "(mensal)" if modo_leg == "mensal" else "(global)"
        df_table = pd.DataFrame({
            'Mês/Ano': meses_fut,
            'Previsão (Y)': prev_fut,
            f'IC 95% Inferior {col_suf}': cis[95]['lower'],
            f'IC 95% Superior {col_suf}': cis[95]['upper'],
            f'IC 90% Inferior {col_suf}': cis[90]['lower'],
            f'IC 90% Superior {col_suf}': cis[90]['upper'],
            f'IC 80% Inferior {col_suf}': cis[80]['lower'],
            f'IC 80% Superior {col_suf}': cis[80]['upper'],
            f'IC 70% Inferior {col_suf}': cis[70]['lower'],
            f'IC 70% Superior {col_suf}': cis[70]['upper'],
            f'IC 50% Inferior {col_suf}': cis[50]['lower'],
            f'IC 50% Superior {col_suf}': cis[50]['upper'],
        })

        # Tabela de sigmas por mês
        nomes_mes_impressao = ['JAN','FEV','MAR','ABR','MAI','JUN','JUL','AGO','SET','OUT','NOV','DEZ']
        df_sigma = pd.DataFrame({
            'Mês': nomes_mes_impressao,
            'Sigma (bruto)': [sigma_por_mes[m] for m in range(1, 13)],
            'Amostras (n)':  [n_por_mes[m]     for m in range(1, 13)],
            'Sigma ajustado (σ/√n)': [sigma_ajustado_por_mes[m] for m in range(1, 13)],
        })

        # Formatação pt-BR: casas decimais e milhar
        def fmt_br(x, casas=casas_decimais, milhar=separador_milhar):
            try:
                if milhar:
                    s = f"{x:,.{casas}f}".replace(",", "X").replace(".", ",").replace("X", ".")
                else:
                    s = f"{x:.{casas}f}".replace(".", ",")
                return s
            except Exception:
                return x

        table_html = df_table.to_html(index=False, float_format=lambda x: fmt_br(x),
                                      classes="tabela", border=0)
        sigma_html = df_sigma.to_html(index=False, float_format=lambda x: fmt_br(x),
                                      classes="tabela", border=0)

        # Texto explicativo de IC conforme modo
        texto_ic = (
            f"Intervalo de Confiança Sazonal: y_IC = Y ± Z × σ<sub>mês</sub>{' / √n' if usar_sigma_por_raiz_n and str(modo_sigma_ic).lower()=='sazonal' else ''}"
            if str(modo_sigma_ic).lower() == "sazonal"
            else "Intervalo de Confiança Global: y_IC = Y ± Z × σ<sub>global</sub>"
        )

        # === NOVO: Extrair equação da tendência para exibir no HTML ===
        modelo = res.get('modelo_tendencia', None)
        if modelo is not None:
            a = float(getattr(modelo, 'intercepto', np.nan))
            b = float(getattr(modelo, 'inclinacao', np.nan))
            # Respeita configuração de casas decimais do relatório
            def _fmt(x): 
                try:
                    return f"{x:.{casas_decimais}f}"
                except Exception:
                    return str(x)
            eq_str = f"y = {_fmt(a)} + {_fmt(b)} × x"
        else:
            eq_str = "—"

        # HTML final
        html = f"""
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Prev-Saz</title>
<style>
body {{ font-family: Calibri,Arial, Helvetica, sans-serif; margin: 24px; color: #222; }}
h1, h2 {{ margin: 0 0 12px; }}
hr {{ border: 1px solid; border-color:black; background-color:black; }}
.small {{ font-size: 12px; color: #000; }}
.t2 {{ font-size: 12px; color: #000; }}
.tabela {{ border-collapse: collapse; width: 100%; }}
.tabela th, .tabela td {{ border: 1px solid #ddd; padding: 8px; text-align: right; }}
.tabela th {{ background: #f4f6f8; text-align: center; }}
.tabela td:first-child {{ text-align: left; }}
.figure {{ text-align: center; margin: 20px 0; }}
.legend {{ font-size: 12px; color: #555; }}
.badge {{
  display: inline-block; background: #eef; border: 1px solid #ccd;
  padding: 4px 8px; border-radius: 4px; margin-right: 8px;
}}
</style>
</head>
<body>

<hr>
<h1>Prev-Saz</h1>
<b class="t2">
Modelo clássico de previsão por Regressão Linear considerando Sazonalidade e Tendência<br>
Opcional: Resíduos previstos com modelo ARIMA.</b>
<h3>Desenvolvido pelo Centro de Pesquisas de Energia Elétrica - CEPEL</h3><hr>

<p class="small">
Data da Previsão: {datetime.now().strftime('%d/%m/%Y %H:%M')}<br>
Desvio Padrão Global dos Resíduos: <strong>{fmt_br(sigma_global)}</strong> <br>
Equação da Tendência: {eq_str}<br>
Fonte da Previsão no Gráfico: <strong>{etq_prev}</strong><br>
Composição: {fonte_prev}<br
</p>
<hr>

<h2>Resultados:</h2>
<div class="figure">
  <img src="data:image/png;base64,{img_b64}" alt="Gráfico de Previsões" style="max-width:100%; height:auto;">

<div class="legend">

    <span class="badge" style="background:#cfe2ff;border-color:#9ec5fe;color:#0b5ed7">
    Observado (últimos {ult_n})
    </span>
    <span class="badge" style="background:#ffe5d0;border-color:#ffb07a;color:#a35312">
    {etq_prev} (próximos {len(prev_fut)})
    </span>
    <span class="badge" style="background:#d9f2e6;border-color:#a7e3c7;color:#2ca02c">
    IC {nivel}% (Superior, {modo_leg})
    </span>
    <span class="badge" style="background:#f8d7da;border-color:#f1aeb5;color:#d62728">
    IC {nivel}% (Inferior, {modo_leg})

</div>

</div>

<h2>Tabela de Previsões e Intervalos ({modo_leg})</h2>
{table_html}

<h2>Desvios Padrão dos Resíduos por Mês</h2>
{sigma_html}

</body>
</html>
"""

        # Salvar
        with open(caminho_arquivo_html, 'w', encoding='utf-8') as f:
            f.write(html)

        # Atualiza o caminho na instância, para o botão "Abrir relatório HTML"
        self.relatorio_html_path = caminho_arquivo_html

        self._log(f"✓ Relatório HTML ({modo_leg}) gerado em: {caminho_arquivo_html}")

# ======================================================================
# Aba 1: PrevIA-C (versão completa adaptada para embed em Notebook)
# ======================================================================
class PrevIACPage(tb.Frame):
    def __init__(self, master):
        super().__init__(master)
        ensure_dirs()
        self._build_vars()
        self._load_paths() 
        self._build_ui()

    def _build_vars(self):
        # Estado
        self.v3 = tk.IntVar(value=3)   # período: 1 úmido / 2 seco / 3 total
        self.v1 = tk.IntVar(value=1)   # rodada: 1 treino / 2 teste / 3 previsão
        self.v8 = tk.IntVar(value=1)   # icrit: Dmin(1)/RMSE(2)/Pearson(3)/Nash(4)
        self.v9 = tk.IntVar(value=1)   # lag: Fixo(1)/Acu.Dir.(2)/Pearson(3)/Kendall(4)
        self.ibeta = tk.IntVar(value=0)  # 0 com intercepto; 1 sem intercepto
        self.varconf = tk.IntVar(value=0)
        self.varnorm = tk.IntVar(value=1)
        self.varh = tk.IntVar(value=0)
        self.v6 = tk.IntVar(value=0)

        # Parâmetros
        self.nprev = tk.StringVar(value="7")
        self.Tol = tk.StringVar(value="0.0005")
        self.Cam = tk.StringVar(value="2")
        self.Ntrei = tk.StringVar(value="70")
        self.Ntest = tk.StringVar(value="100")
        self.lambdat = tk.StringVar(value="0.0001")
        self.kfoldt = tk.StringVar(value="3")
        self.ntit = tk.StringVar(value="Título da calibração (máximo de 80 caracteres).")

        # Caminhos
        self.Arq = tk.StringVar(value="")
        self.Conf = tk.StringVar(value="")
        self.vpath2 = ""  # arquivo CSV dados
        self.vpath3 = ""  # arquivo CSV configuração

        # Meses (JAN..DEZ)
        self.month_vars = [tk.IntVar(value=1) for _ in range(12)]

    def _load_paths(self):
        """Carrega os caminhos salvos para esta aba."""
        paths = load_file_paths().get("prev_ia_c", {})
        if "dados" in paths and Path(paths["dados"]).exists():
            self.Arq.set(paths["dados"])
            self.vpath2 = paths["dados"]
        if "conf" in paths and Path(paths["conf"]).exists():
            self.Conf.set(paths["conf"])
            self.vpath3 = paths["conf"]

    def _save_paths(self):
        """Salva os caminhos atuais no arquivo de configuração."""
        paths = load_file_paths()
        paths["prev_ia_c"] = {
            "dados": self.Arq.get(),
            "conf": self.Conf.get()
        }
        save_file_paths(paths)                   

    def abrir_arquivo(self):
        caminho = Path(self.Conf.get())

        if not caminho.is_file():
            messagebox.showerror(
                "Erro",
                "Arquivo não encontrado."
            )
            return

        try:
            os.startfile(caminho)
        except Exception as e:
            messagebox.showerror(
                "Erro",
                f"Não foi possível abrir o arquivo:\n{e}"
            )

    def _build_ui(self):

        frame_left  = tb.Frame(self, padding=2)
        frame_right = tb.Frame(self, padding=2)
        frame_left.grid(row=0, column=0, sticky="nsew")
        frame_right.grid(row=0, column=1, sticky="nsew")

        # Esquerda mais larga
        self.columnconfigure(0, weight=3)
        self.columnconfigure(1, weight=2)
        self.rowconfigure(0, weight=1)

        # ============================
        # ESQUERDA: Configurações
        # ============================
        tb.Label(frame_left, text="PrevIA-C", font=("Segoe UI", 22, "bold"))\
            .grid(row=0, column=0, pady=(0, 8), sticky="ew")
        tb.Label(frame_left, text="Módulo de Treinamento, Validação, Teste e Previsão.                   ")\
          .grid(row=1, column=0, sticky="w")

        frm_tit = tb.Frame(frame_left)
        frm_tit.grid(row=2, column=0, sticky="ew", pady=(8,0))
        frm_tit.columnconfigure(1, weight=1)
        tb.Label(frm_tit, text="Título:").grid(row=0, column=0, sticky="w")
        tb.Entry(frm_tit, textvariable=self.ntit, width=90).grid(row=0, column=1, sticky="w")

        periodo = tb.Labelframe(frame_left, text="Período")
        periodo.grid(row=3, column=0, sticky="ew", pady=2)
        for i, (txt, val) in enumerate([("Período Total   ",3), ("Período Seco  ",2),("Período Úmido  ",1) ]):
            tb.Radiobutton(periodo, text=txt, variable=self.v3, value=val,
                           bootstyle="info", command=self.marcap).grid(row=0, column=i, padx=30, pady=5)

        meses = tb.Labelframe(frame_left, text="Meses Considerados")
        meses.grid(row=4, column=0, sticky="ew", pady=2)
        mes_labels = ["JAN","FEV","MAR","ABR","MAI","JUN","JUL","AGO","SET","OUT","NOV","DEZ"]
        for idx, label in enumerate(mes_labels):
            r, c = idx // 4, idx % 4
            tb.Checkbutton(meses, text=label, variable=self.month_vars[idx],
                           bootstyle="primary").grid(row=r, column=c, padx=40, pady=2, sticky="w")

        rodada = tb.Labelframe(frame_left, text="Rodada")
        rodada.grid(row=5, column=0, sticky="ew", pady=5)
        for i, (txt, val) in enumerate([("Treinamento",1), ("Testar outro período",2), ("Previsão",3)]):
            tb.Radiobutton(rodada, text=txt, variable=self.v1, value=val,
                           bootstyle="success", command=self.view).grid(row=0, column=i, padx=30, pady=5)

        modelo = tb.Labelframe(frame_left, text="Modelo / Lag")
        modelo.grid(row=6, column=0, sticky="ew", pady=2)
        for i, (txt, val) in enumerate([("Dmin",1), ("RMSE   ",2), ("Pearson",3), ("Nash   ",4)]):
            tb.Radiobutton(modelo, text=txt, variable=self.v8, value=val,
                           bootstyle="warning").grid(row=0, column=i, padx=30, pady=5)
        for i, (txt, val) in enumerate([("Fixo  ",1), ("Acu.Dir.",2), ("Pearson",3), ("Kendall",4)]):
            tb.Radiobutton(modelo, text=txt, variable=self.v9, value=val,
                           bootstyle="info").grid(row=1, column=i, padx=30,pady=5)

        params = tb.Labelframe(frame_left, text="Parâmetros")
        params.grid(row=7, column=0, sticky="ew", pady=2)
        params.columnconfigure(1, weight=1)
        #params.columnconfigure(2, weight=1)
        #params.columnconfigure(3, weight=1)
        campos = [("Horizontes:", self.nprev), ("Tolerância:", self.Tol),
                  ("Camadas:", self.Cam), ("% Treinamento:", self.Ntrei),
                  ("Nº p/ Gráfico:", self.Ntest)]
        for i, (label, var) in enumerate(campos):
            tb.Label(params, text=label).grid(row=i, column=0, sticky="e", padx=5, pady=2)
            tb.Entry(params, textvariable=var, width=10).grid(row=i, column=1, sticky="w")
        tb.Checkbutton(params, text="Com Intercepto", variable=self.ibeta, onvalue=0, offvalue=1,
                       bootstyle="primary").grid(row=1, column=2, sticky="e", padx=30)
        tb.Label(params, text="Lambda (Ridge):").grid(row=2, column=2)
        tb.Entry(params, textvariable=self.lambdat, width=10).grid(row=2, column=3, sticky="e", padx=30)
        tb.Label(params, text="k-folds:").grid(row=3, column=2)
        tb.Entry(params, textvariable=self.kfoldt, width=10).grid(row=3, column=3, sticky="e", padx=30)

        arquivos = tb.Labelframe(frame_left, text="Arquivos")
        arquivos.grid(row=8, column=0, sticky="ew", pady=2)
        arquivos.columnconfigure(1, weight=1)
        tb.Label(arquivos, text="Arquivo CSV com dados para Treino:").grid(row=0, column=0, sticky="e",padx=5)
        self.txtArq = tb.Entry(arquivos, textvariable=self.Arq)
        self.txtArq.grid(row=0, column=1, sticky="ew")
        tb.Button(arquivos, text="Buscar", bootstyle="primary", command=self.arquivopath).grid(row=0, column=2, padx=5,sticky="ew")

        self.ConfLabel = tb.Label(arquivos, text="Arquivo CSV com Lags e Parâmetros:",bootstyle="secondary subdued")
        self.ConfLabel.grid(row=1, column=0, sticky="ew",pady=(0,8),padx=5)
        self.txtConf = tb.Entry(arquivos, textvariable=self.Conf, state="disabled", bootstyle="secondary")
        self.txtConf.grid(row=1, column=1, sticky="ew",pady=(0,8))
        self.btnConf = tb.Button(arquivos, text="Buscar", bootstyle="primary", command=self.arquivopath2)
        self.btnConf.grid(row=1, column=2, padx=5,sticky="ew",pady=(0,8))

        tb.Checkbutton(arquivos, variable=self.varconf, command=self.checkconf,
                       bootstyle="primary").grid(row=1, column=3, padx=5)

        # ============================
        # DIREITA: Log e Botões
        # ============================
        tb.Label(frame_right, text="Log de Execução", font=("Segoe UI", 14, "bold")).grid(row=0, column=0, sticky="w")
        self.txtRun = ScrolledText(frame_right, height=25, width=70)
        self.txtRun.configure(font=("Courier", 10))
        self.txtRun.grid(row=1, column=0, sticky="nsew", pady=10)
        # --- Tags de formatação para o Log de Execução ---
        self.txtRun.tag_configure("bold", font=("Courier", 10, "bold"))
        self.txtRun.tag_configure("info", foreground="#0d6efd")      # azul (Bootstrap 'primary')
        self.txtRun.tag_configure("success", foreground="#198754")    # verde (Bootstrap 'success')
        self.txtRun.tag_configure("warning", foreground="#ffc107")    # amarelo
        self.txtRun.tag_configure("danger", foreground="#dc3545")     # vermelho
        self.txtRun.tag_configure("muted", foreground="#6c757d")      # cinza
        self.txtRun.tag_configure("header", foreground="#0d6efd", font=("Courier", 10, "bold"))
        self.txtRun.tag_configure("mono", font=("Courier", 10))

        frame_right.rowconfigure(1, weight=1)


        btns = tb.Frame(frame_right)
        btns.grid(row=2, column=0, pady=2)

        self.btnTreinar   = tb.Button(btns, text="Treinar",   command=self.escreve,   bootstyle="primary")
        self.btnTreinar.grid(row=0, column=0, padx=5)

        self.btnResultado = tb.Button(btns, text="Relatório", command=self.resultado, bootstyle="success", state="disabled")
        self.btnResultado.grid(row=0, column=1, padx=5)

        self.btnArvore    = tb.Button(btns, text="Árvore",    command=self.executar_analise_gmdh_C,    bootstyle="info", state="disabled")
        self.btnArvore.grid(row=0, column=2, padx=5)

        self.btnResumo    = tb.Button(btns, text="Resumo",    command=self.resumo,    bootstyle="secondary", state="disabled")
        self.btnResumo.grid(row=0, column=3, padx=5)

        self.btnExportar  = tb.Button(btns, text="Exportar",  command=self.exportar,  bootstyle="warning", state="disabled")
        self.btnExportar.grid(row=0, column=4, padx=5)

        # ✅ Agora o Ajuda está correto e posicionado na coluna 4
        self.btnAjuda     = tb.Button(btns, text="Ajuda",     command=self.ajuda,     bootstyle="dark")
        self.btnAjuda.grid(row=0, column=5, padx=4)

        # Botão Fechar
        self.btnFechar = tb.Button(btns, text="Fechar",
                                command=lambda: self.winfo_toplevel().destroy(),
                                bootstyle="danger")
        self.btnFechar.grid(row=0, column=6, padx=5)


        self.view()
        self.checkconf()

    def log(self, mensagem, *tags):
        self.txtRun.insert(tk.END, mensagem + "\n", tags)
        self.txtRun.see(tk.END)  # auto-scroll
        self.txtRun.update_idletasks()

    # -----------------------
    # Funções principais (PrevIA-C)
    # -----------------------

    def executar_analise_gmdh_C(self):

        pares_file = BASE_PATH / "config" / "pares.txt"

        if not pares_file.exists():
            self.log(f"Arquivo de pares não encontrado: {pares_file}", "bold", "danger")
            messagebox.showerror("Erro", f"Arquivo de pares não encontrado:\n{pares_file}")
            return

        try:
            parser = GMDHModelParser(str(pares_file))
            parser.parse()

            self.log("=== Análise do modelo GMDH ===", "header")

            output_dir = BASE_PATH / "analise_gmdh"
            output_dir.mkdir(exist_ok=True)

            rastreamento_txt = output_dir / "rastreamento.txt"
            penultima_txt = output_dir / "arvore_camada.txt"
            penultima_html = output_dir / "arvore_camada.html"

            parser.exportar_rastreamento(str(rastreamento_txt))
            parser.exportar_penultima_camada(str(penultima_txt))
            parser.exportar_penultima_camada_html(str(penultima_html))

            self.log(f"Rastreamento completo gerado em: {rastreamento_txt}", "success")
            self.log(f"Penúltima camada (texto) gerada em: {penultima_txt}", "success")
            self.log(f"Diagrama interativo gerado em: {penultima_html}", "success")

            if penultima_html.exists():
                open_system_file(str(penultima_html))

        except Exception as e:
            self.log(f"Erro na análise GMDH: {e}", "bold", "danger")
            messagebox.showerror("Erro", f"Falha ao processar o modelo:\n{e}")

    def view(self):
        tipo = self.v1.get()
        if tipo == 1:
            self.btnTreinar.config(text="Treinar")
        elif tipo == 2:
            self.btnTreinar.config(text="Testar")
        elif tipo == 3:
            self.btnTreinar.config(text="Prever")

    def marcap(self):
        i = self.v3.get()
        if i == 1:  # Úmido
            on = {0,1,2,3,10,11}
        elif i == 2:  # Seco
            on = {4,5,6,7,8,9}
        else:  # Total
            on = set(range(12))
        for idx in range(12):
            self.month_vars[idx].set(1 if idx in on else 0)

    def checkconf(self):
        v = self.varconf.get()
        if v == 1:
            self.btnConf.state(["!disabled"])
            self.txtConf.config(state="normal", bootstyle="default")
            caminho = Path(self.Conf.get())
            self.ConfLabel.config(bootstyle="default")
            if not caminho.is_file():
                self.btnConf.config(text="Buscar", command=self.arquivopath2)
        else:
            self.ConfLabel.config(bootstyle="secondary subdued")
            self.btnConf.state(["disabled"])
            self.txtConf.config(state="disabled", bootstyle="secondary")
            self.btnConf.config(text="Abrir", command=self.abrir_arquivo)

    # Seleção de arquivos
    def arquivopath(self):
        pasta_dados = BASE_PATH / "dados"
        sel = pick_file("Arquivo de dados CSV", (("CSV", "*.csv"), ("Todos os arquivos", "*.*")))
        if sel:
            self.vpath2 = sel
            self.Arq.set(sel)
            self._save_paths() 

    def arquivopath2(self):
        pasta_dados = BASE_PATH / "dados"
        sel = pick_file("Arquivo de configurações CSV", (("CSV", "*.csv"), ("Todos os arquivos", "*.*")))
        if sel:
            self.vpath3 = sel
            self.Conf.set(sel)
            self._save_paths()
            self.btnConf.state(["!disabled"])

    # Escritas/execuções (igual ao seu app.py, adaptado ao container)
    def periodo(self, count_active_months: int):
        caminho_arquivo = BASE_PATH / "periodo.txt"
        with caminho_arquivo.open("w", encoding="latin1") as f:
            f.write(f"{count_active_months}\n")
            for idx, var in enumerate(self.month_vars, start=1):
                if var.get() == 1:
                    f.write(f"{idx}\n")

    def arquivo4(self):
        caminho_arquivo = BASE_PATH / "entrada.txt"
        nkfold = self.kfoldt.get()
        tipo = ('1' if self.v1.get() == 1 else '2' if self.v1.get() == 2 else '')
        periodo_char = ('t' if self.v3.get()==3 else 'u' if self.v3.get()==1 else 's')
        linhas = [
            f"{'Varx.txt':<20} !Arquivo de entrada de dados",
            f"{self.nprev.get():<20} !Número de horizontes de previsão",
            f"{str(int(self.Cam.get())):<20} !Número de camadas. (0 = livre)",
            f"{tipo:<20} !1 = treinamento; 2 = teste",
            f"{periodo_char:<20} !t = total, u = úmido, s = seco",
            f"{self.Tol.get():<20} !Tolerância para convergência",
            f"{self.Ntrei.get():<20} !% para treino",
            f"{self.Ntest.get():<20} !Número para validação visual",
            f"{str(self.varh.get()):<20} !1 = Misturar histórico, 0 = não misturar histórico",
            f"{self.ntit.get()}",
            f"{str(self.varnorm.get()):<20} !1 = Normalizar dados, 0 = não normalizar",
            f"{str(self.v6.get()):<20} !Deixar sempre 0",
            f"{nkfold:<20} !Número de folds (min. 3). Não usa = 0"
        ]
        with caminho_arquivo.open("w", encoding="latin1") as f:
            f.write("\n".join(linhas) + "\n")

    def lercsv1(self):
        src = self.Arq.get()
        if not src or not Path(src).is_file():
            messagebox.showerror("Erro", "Falta o arquivo de dados!")
            return
        varx_path = BASE_PATH / "varx.txt"
        vpath2 = Path(src)
        with vpath2.open("r", encoding="latin1") as fin, varx_path.open("w", encoding="latin1") as fout:
            for j, l in enumerate(fin):
                l = l.strip()
                if j == 0:
                    header = '"' + '","'.join([s.strip() for s in l.split(';')]) + '"'
                    fout.write(header + "\n")
                else:
                    l = l.replace(',', '.')  # decimal
                    l = l.replace(';', ',')  # separador
                    fout.write(l + "\n")

    # ---- fazconf, calcular_lag, montar Confx etc. (copiado e adaptado) ----
    # Para reduzir a resposta, mantenho exatamente as mesmas rotinas do seu app.py,
    # apenas ajustando BASE_PATH (já está referenciado) e sem dependências de janela.
    # ---> INÍCIO BLOCO DE CÁLCULO DE LAGS/CONF <---
    def calcular_acuracia_direcao(self, coluna_deslocada, target):
        import pandas as pd
        validos = coluna_deslocada.notna() & target.notna()
        coluna_valida = coluna_deslocada[validos]
        target_valido = target[validos]
        diff_coluna = coluna_valida.diff()
        diff_target = target_valido.diff()
        validos_diff = diff_coluna.notna() & diff_target.notna()
        diff_coluna = diff_coluna[validos_diff]
        diff_target = diff_target[validos_diff]
        acertos = ((diff_coluna > 0) & (diff_target > 0)) | \
                  ((diff_coluna < 0) & (diff_target < 0)) | \
                  ((diff_coluna == 0) & (diff_target == 0))
        acuracia = acertos.mean()
        return acuracia if not pd.isna(acuracia) else 0.0

    def lag_kendall(self, coluna_deslocada, target):
        from scipy.stats import kendalltau
        validos = coluna_deslocada.notna() & target.notna()
        corr, _ = kendalltau(coluna_deslocada[validos], target[validos])
        return abs(corr) if corr is not None else 0.0

    def calcular_lag(self, coluna_x, coluna_y, max_lag):
        resultados = []
        metodo = self.v9.get()
        for lag in range(0, max_lag + 1):
            y_deslocado = coluna_y.shift(lag)
            if metodo == 1:      # Fixo -> neutro
                valor = 0.0
            elif metodo == 2:    # Acurácia de direção
                valor = self.calcular_acuracia_direcao(y_deslocado, coluna_x)
            elif metodo == 4:    # Kendall
                valor = self.lag_kendall(y_deslocado, coluna_x)
            elif metodo == 3:    # Pearson
                valor = y_deslocado.corr(coluna_x)
            else:
                raise ValueError(f"Método de lag desconhecido: {metodo}")
            resultados.append((lag, 0.0 if valor is None else valor))
        lag_mais_provavel = max(resultados, key=lambda x: abs(x[1]))[0]
        return lag_mais_provavel

    @staticmethod
    def calcular_correlacoes(df, lags, np_lag, nd, target):
        import pandas as pd
        df_correlacoes = pd.DataFrame(columns=['i', 'coluna', 'lag', 'correlacao'])
        nmax = int(40 / nd) if nd > 0 else 40
        for i in range(1, np_lag + 1):
            for j in range(nd):
                coluna_nome = df.columns[3 + j]
                lag_inicial = lags[j] - int(nmax / 2)
                lag_final   = lags[j] + int(nmax / 2)
                if nmax % 2 == 0:
                    lag_final -= 1
                if lags[j] == 0:
                    lag_final = nmax
                if lag_inicial < 1:
                    lag_inicial = 1
                    lag_final = nmax
                for lag in range(lag_inicial, lag_final + 1):
                    coluna_deslocada = df[coluna_nome].shift(lag)
                    correlacao = coluna_deslocada.corr(target)
                    nova_linha = pd.DataFrame({
                        'i': [i],
                        'coluna': [coluna_nome],
                        'lag': [lag],
                        'correlacao': [correlacao]
                    }).dropna(axis=1, how='all')
                    if not nova_linha.empty:
                        nova_linha = nova_linha.dropna(axis=1, how='all')
                        df_correlacoes = (
                            nova_linha.copy() if df_correlacoes.empty
                            else pd.concat([df_correlacoes, nova_linha], ignore_index=True)
                        )
        return df_correlacoes

    def _get_varx_header_cols(self):
        """
        Retorna lista de nomes de colunas do Varx.txt (pulando as 3 primeiras).
        Varx.txt tem cabeçalho entre aspas e separado por vírgulas.
        """
        varx_path = BASE_PATH / "varx.txt"
        if not varx_path.exists():
            return []
        with varx_path.open("r", encoding="latin1") as f:
            first_line = f.readline().strip()
        # Cabeçalho está como: "col1","col2","col3",...
        if first_line.startswith('"') and first_line.endswith('"'):
            cols = [c.strip('"') for c in first_line.split(',')]
        else:
            cols = [c.strip() for c in first_line.split(',')]
        # Pula as 3 primeiras
        return cols[3:] if len(cols) > 3 else []

    def monta_confx(self, lags, np_lag, nd, colunas_nomes, caminho_csv, nome_ultima_coluna):
        q = [0] * nd
        p = [0] * nd
        nmax = int(40 / nd) if nd > 0 else 40
        a = self.ntit.get()
        ilag = self.v9.get()
        if ilag == 1:
            alag = "lag_geral"
        elif ilag == 2:
            alag = "lag_acudir"
        elif ilag == 3:
            alag = "lag_pearson"
        else:
            alag = "lag_kendall"
        diretorio_csv = Path(caminho_csv).parent
        nome_arquivo_saida = f"config_auto_{nome_ultima_coluna}_{alag}.csv"
        caminho_saida = diretorio_csv / nome_arquivo_saida
        caminho_confx = BASE_PATH / "confx.txt"
        ibeta1 = self.ibeta.get()
        lambda1 = self.lambdat.get()
        icrit_str = str(self.v8.get())
        lambda_str = str(lambda1).replace('.', ',')
        
        try:
            with caminho_confx.open('w', encoding="latin1") as f_txt, caminho_saida.open('w', encoding="latin1") as f_csv:
                f_txt.write(f"{a}\n")
                f_txt.write(f"{nd} {np_lag}\n")
                f_csv.write(f"{nd};{np_lag}\n")
                f_csv.write(''.join([f"{colunas_nomes[j]};;" for j in range(nd)]) + ';\n')
                f_csv.write(''.join(['ini;fim;' for _ in range(nd)]) + 'ibeta;Ridge;icrit;h\n') #titulos
                for k in range(nd, 0, -1):
                    j = k - 1
                    q[j] = lags[j] - int(nmax / 2)
                    p[j] = lags[j] + int(nmax / 2)
                    if nmax % 2 == 0:
                        p[j] -= 1
                    if lags[j] == 0:
                        p[j] = nmax
                    if q[j] < 1:
                        q[j] = 1
                        p[j] = nmax
                for h in range(1, np_lag + 1):
                    f_txt.write(' '.join([f"{q[j]} {p[j]}" for j in range(nd)]) + f" {ibeta1} {lambda1} {icrit_str} {h}\n")
                    linha_csv = ''.join([f"{q[j]};{p[j]};" for j in range(nd)]) + f"{ibeta1};{lambda_str};{icrit_str};{h}\n"
                    f_csv.write(linha_csv)
                    for j in range(nd):
                        q[j] -= 1
                        p[j] -= 1
                        if q[j] < 1:
                            q[j] = 1
                        if p[j] < nmax:
                            p[j] = nmax
                #f_csv.write(f"{a};\n\n")

                header_cols = self._get_varx_header_cols()
                if not header_cols:
                    header_cols = colunas_nomes  # fallback seguro
                # Formato: uma linha com os nomes separados por ponto-e-vírgula (ou espaço)
                f_txt.write("\nDados de entrada:   ")
                f_txt.write(", ".join(header_cols) + "\n")
                f_csv.write("\nDados de entrada:   ")
                f_csv.write(", ".join(header_cols) + "\n")                
                f_csv.write("ibeta 0 = Considera o intercepto.\nibeta 1 = Não considera o intercepto.\n\n")
                f_csv.write("icrit 1 = Critério de seleção Dmin.\n")
                f_csv.write("icrit 2 = Critério de seleção RMSE.\n")
                f_csv.write("icrit 3 = Critério de seleção Pearson.\n")
                f_csv.write("icrit 4 = Critério de seleção Nash.\n\n")
                f_csv.write("Pode fazer anotações daqui para baixo.\n")
                f_txt.write("ibeta 0 = Considera o intercepto.\nibeta 1 = Não considera o intercepto.\n\n")
                f_txt.write("icrit 1 = Critério de seleção Dmin.\n")
                f_txt.write("icrit 2 = Critério de seleção RMSE.\n")
                f_txt.write("icrit 3 = Critério de seleção Pearson.\n")
                f_txt.write("icrit 4 = Critério de seleção Nash.\n\n")
        except PermissionError:
            messagebox.showerror(
                "Arquivo em uso",
                f"Não foi possível salvar os arquivos:\n\n"
                f"{caminho_confx}\n{caminho_saida}\n\n"
                f"Verifique se eles estão abertos em outro programa (como o Excel) e feche-os antes de continuar."
            )
            return
        
        self.Conf.set(str(caminho_saida))
        self.vpath3 = str(caminho_saida)
        #self._save_paths() --> não vou gravar aqui pq a confx muda sempre
        self.txtRun.insert(tk.END, f"  Configuração salva em: {caminho_saida}\n")
        self.txtRun.update_idletasks()
        self.varconf.set(1)  # ✅ marca o checkbox
        self.checkconf()

    def fazconf(self):
        try:
            import pandas as pd
            import numpy as np
        except Exception as e:
            messagebox.showerror("Erro", f"Falha ao carregar pandas/numpy:\n{e}")
            return
        src = self.Arq.get()
        if not src or not Path(src).is_file():
            messagebox.showerror("Erro", "Falta o arquivo de dados!")
            return
        df = pd.read_csv(src, delimiter=';', decimal=',', encoding='latin1')
        num_colunas = len(df.columns)
        num_colunas_menos_3 = num_colunas - 3
        ultima_coluna = df.iloc[:, -1]
        try:
            max_lag = int(self.nprev.get())
        except Exception:
            max_lag = 7
        lags = []
        for i in range(3, num_colunas):
            coluna_atual = df.iloc[:, i]
            lag = self.calcular_lag(ultima_coluna, coluna_atual, max_lag)
            lags.append(lag)
        colunas_nomes = df.columns[3:num_colunas].tolist()
        nome_ultima_coluna = df.columns[-1]
        df_correlacoes = self.calcular_correlacoes(df, lags, max_lag, num_colunas_menos_3, ultima_coluna)
        ilag = self.v9.get()
        if ilag == 1:
            alag = "lag_geral"
        elif ilag == 2:
            alag = "lag_acudir"
        elif ilag == 3:
            alag = "lag_pearson"
        else:
            alag = "lag_kendall"
        nome_arquivo_correlacoes = f"correlacao_{alag}_{nome_ultima_coluna}.csv"
        diretorio_csv = Path(src).parent
        caminho_correlacoes = diretorio_csv / nome_arquivo_correlacoes
        df_correlacoes.to_csv(caminho_correlacoes, sep=';', decimal=',', index=False)
        self.txtRun.insert(tk.END, f"  Correlações salvas em: {caminho_correlacoes}\n")
        self.txtRun.update_idletasks()
        self.txtRun.insert(tk.END, "  Montando lags...\n")
        self.txtRun.update_idletasks()
        self.monta_confx(lags, max_lag, num_colunas_menos_3, colunas_nomes, src, nome_ultima_coluna)
    # ---> FIM BLOCO DE CÁLCULO DE LAGS/CONF <---

    def arquivo6(self, nome1: str):
        caminho = BASE_PATH / nome1
        with caminho.open("w", encoding="latin1") as f:
            f.write("Varx.txt\n")
            f.write(f"{self.nprev.get()}\n")
            f.write(str(int(self.Cam.get())) + '\n')

    def resumo(self):
        Per = self.v3.get()
        Tip = self.v1.get()
        if Per == 1:
            nome2 = "resumouc.txt" if (Tip == 1) else "resumout.txt"
        elif Per == 2:
            nome2 = "resumosc.txt" if (Tip == 1) else "resumost.txt"
        elif Per == 3:
            nome2 = "resumotc.txt" if (Tip == 1) else "resumott.txt"
        else:
            return
        caminho_resumo = BASE_PATH / "relat" / nome2
        if caminho_resumo.exists():
            open_system_file(caminho_resumo)
        else:
            messagebox.showerror("Erro", f"Arquivo de resumo não encontrado:\n{caminho_resumo}")

    def resultado(self):
        Per = self.v3.get()
        Tip = self.v1.get()        
        nome2 = None
        if Tip == 1:
            nome2 = "calibrauc.html" if Per == 1 else "calibrasc.html" if Per == 2 else "calibratc.html"
        elif Tip == 2:
            nome2 = "calibraut.html" if Per == 1 else "calibrast.html" if Per == 2 else "calibratt.html"
        elif Tip == 3:
            nome2 = "relatprev.html"
        if not nome2:
            messagebox.showerror("Erro", "Tipo ou Período inválido.")
            return
        caminho_html = BASE_PATH / "relat" / nome2
        if caminho_html.exists():
            messagebox.showinfo("Lembrete:", "Imprima ou salve o arquivo de resultados em sua pasta!")
            open_system_file(caminho_html)
        else:
            messagebox.showerror("Erro", f"Arquivo não encontrado:\n{caminho_html}")

    def calibrar(self):
        self.btnResultado.state(["disabled"])
        self.btnResumo.state(["disabled"])
        self.btnExportar.state(["disabled"])
        self.btnArvore.state(["disabled"])
        self.txtRun.delete("1.0", "end")
        self.txtRun.insert(tk.END, "  AGUARDE...\n")
        self.txtRun.update_idletasks()
        run_exe("C.exe", self.txtRun)
        self.btnResultado.state(["!disabled"])
        self.btnResumo.state(["!disabled"])
        self.btnExportar.state(["!disabled"])
        self.btnArvore.state(["!disabled"])
        self.btnConf.config(
        text="Abrir",
        command=self.abrir_arquivo
        )

    def previsao(self):
        Per = self.v3.get()
        config_dir = BASE_PATH / "config"
        coef_dest = BASE_PATH / "coef.txt"
        confx_src = BASE_PATH / "confx.txt"
        config_txt = BASE_PATH / "config.txt"
        if Per == 1:
            coef_src = config_dir / "coefu.txt"
        elif Per == 2:
            coef_src = config_dir / "coefs.txt"
        elif Per == 3:
            coef_src = config_dir / "coeft.txt"
        else:
            messagebox.showerror("Erro", "Período inválido")
            return
        try:
            shutil.copyfile(str(coef_src), str(coef_dest))
            shutil.copyfile(str(confx_src), str(config_txt))
        except Exception as e:
            messagebox.showerror("Erro", f"Falha ao preparar previsão:\n{e}")
            return
        temp_path = BASE_PATH / "temp.txt"
        with temp_path.open("w", encoding="latin1") as f:
            f.write("10000 10000  ")
            f.write('1' if self.v6.get() == 1 else '0')
            f.write("  0 0 \n")
            f.write("0")
        self.diminuivarx()
        self.btnResultado.state(["disabled"])
        self.btnResumo.state(["disabled"])
        self.btnExportar.state(["disabled"])
        self.txtRun.delete("1.0", "end")
        self.txtRun.insert(tk.END, "  AGUARDE...\n")
        self.txtRun.update_idletasks()
        run_exe("P.exe", self.txtRun)
        self.btnResultado.state(["!disabled"])

    def diminuivarx(self):
        self.lercsv1()
        varx_path = BASE_PATH / "varx.txt"
        varxc_path = BASE_PATH / "varxC.txt"
        if varxc_path.exists():
            varxc_path.unlink(missing_ok=True)
        if not varx_path.exists() or varx_path.stat().st_size == 0:
            messagebox.showerror("Previsão", "Não existe calibração!")
            raise RuntimeError("Parando execução por falta de varx.txt")
        varx_path.rename(varxc_path)
        with varxc_path.open("r", encoding="latin1") as fin:
            linhas = fin.readlines()
        if varx_path.exists():
            varx_path.unlink(missing_ok=True)
        i = len(linhas)
        ii = 99 if i >= 100 else i
        with varx_path.open("w", encoding="latin1") as fout:
            for j, l in enumerate(linhas, start=1):
                if j == 1 or j >= i - ii:
                    fout.write(l)

    def escreve(self):
        arqtext = self.Arq.get().strip()
        if not arqtext or not Path(arqtext).is_file():
            messagebox.showerror("Erro!", "Não existe arquivo de dados.")
            return
        if self.v1.get() == 3:
            self.previsao()
            return
        self.Tol.set(self.Tol.get() or "0.0005")
        self.Ntrei.set(self.Ntrei.get() or "70")
        self.Ntest.set(self.Ntest.get() or "100")
        self.arquivo4()
        if self.v1.get() == 2:
            self.lercsv1()
            self.calibrar()
            return
        i = sum(v.get() == 1 for v in self.month_vars)
        self.periodo(i)
        self.lercsv1()
        self.lercsv2()
        self.calibrar()

    def exportar(self):
        confx_path = BASE_PATH / 'confx.txt'
        pares_path = BASE_PATH / "config" / "pares.txt"

        if not confx_path.is_file():
            messagebox.showerror("Exportar", "Não existe calibração")
            return
        Per = self.v3.get()
        vpath = filedialog.askdirectory(title="Selecionar pasta para exportar") or ""
        if not vpath:
            return
        resp = messagebox.askokcancel("Selecionar pasta", f"Exportar para a pasta \n{vpath}?", icon=messagebox.QUESTION)
        if not resp:
            return
        vpath_dir = Path(vpath)
        if Per == 1:
            messagebox.showinfo("Exportar", "Exportando configurações e coeficientes \npara período ÚMIDO: \nConfigU.txt, CoefU.txt e ParesU.txt")
            shutil.copyfile(str(pares_path), str(vpath_dir / "paresu.txt"))
            shutil.copyfile(str(confx_path), str(vpath_dir / "configu.txt"))
            coef_path = BASE_PATH / "config" / "coefu.txt"
            
            if not coef_path.is_file():
                messagebox.showerror("Exportar", "Não existe coeficiente\nCoefU.txt")
                return
            shutil.copyfile(str(coef_path), str(vpath_dir / "coefu.txt"))
        elif Per == 2:
            messagebox.showinfo("Exportar", "Exportando configurações e coeficientes \npara período SECO: \nConfigS.txt, CoefS.txt e ParesS.txt")
            shutil.copyfile(str(confx_path), str(vpath_dir / "configs.txt"))
            shutil.copyfile(str(pares_path), str(vpath_dir / "paress.txt"))
            coef_path = BASE_PATH / "config" / "coefs.txt"
            if not coef_path.is_file():
                messagebox.showerror("Exportar", "Não existe coeficiente\nCoefS.txt")
                return
            shutil.copyfile(str(coef_path), str(vpath_dir / "coefs.txt"))
        elif Per == 3:
            messagebox.showinfo("Exportar", "Exportando configurações e coeficientes \npara período TOTAL: \nConfigT.txt, CoefT.txt e ParesT.txt")
            shutil.copyfile(str(confx_path), str(vpath_dir / "configt.txt"))
            shutil.copyfile(str(pares_path), str(vpath_dir / "parest.txt"))
            coef_path = BASE_PATH / "config" / "coeft.txt"            
            if not coef_path.is_file():
                messagebox.showerror("Exportar", "Não existe coeficiente\ncoeft.txt")
                return
            shutil.copyfile(str(coef_path), str(vpath_dir / "coeft.txt"))

    def avaliar_previsoes(self):
        try:
            import os
            import numpy as np
            import pandas as pd
            from scipy.stats import pearsonr
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
            from matplotlib.backends.backend_pdf import PdfPages
        except Exception as e:
            messagebox.showerror("Erro", f"Falha ao carregar bibliotecas para avaliação:\n{e}")
            return
        os.makedirs(BASE_PATH / "graficos", exist_ok=True)
        resumo_final = []
        saida = BASE_PATH / "plan" / "avaliacao_previsoes.txt"
        v = self.v3.get()
        nprevs = int(self.nprev.get())
        suffix_map = {1: 'u', 2: 's', 3: 't'}
        suffix = suffix_map.get(v)
        if suffix is None:
            messagebox.showerror("Erro", "Valor de v3 inválido. Deve ser 1, 2 ou 3.")
            return
        t = suffix
        try:
            with saida.open("w", encoding="latin1") as f_out, PdfPages(BASE_PATH / "graficos" / f"relatorio_{t}.pdf") as pdf:
                for i in range(1, nprevs + 1):
                    nome_arquivo = BASE_PATH / "plan" / f"grupoteste{t}{i:02d}.csv"
                    try:
                        import pandas as pd
                        df = pd.read_csv(nome_arquivo, sep=";", decimal=",", encoding='latin1')
                        for col in df.columns:
                            df[col] = (
                                df[col].astype(str)
                                      .str.replace(",", ".", regex=False)
                                      .str.strip()
                                      .replace("", np.nan)
                                      .astype(float)
                            )
                        if df.shape[1] < 2:
                            f_out.write(f"{nome_arquivo} não possui colunas suficientes.\n\n")
                            continue
                        obs = df.iloc[:, 0].values
                        tempo = np.arange(len(obs))
                        f_out.write(f"Arquivo: {nome_arquivo}\n")
                        rmses, maes, mapes, rs = [], [], [], []
                        labels = []
                        plt.figure(figsize=(12, 5))
                        plt.plot(tempo, obs, label="Observado", color="black", linewidth=2)
                        from scipy.stats import pearsonr
                        for j in range(1, df.shape[1]):
                            prev = df.iloc[:, j].values
                            mask = ~np.isnan(obs) & ~np.isnan(prev)
                            obs_valid = obs[mask]
                            prev_valid = prev[mask]
                            if len(obs_valid) == 0:
                                f_out.write(f"  Previsão {j}: Sem dados válidos.\n")
                                continue
                            mae = np.mean(np.abs(obs_valid - prev_valid))
                            rmse = np.sqrt(np.mean((obs_valid - prev_valid) ** 2))
                            mape = (np.mean(np.abs((obs_valid - prev_valid) / obs_valid)) * 100
                                    if np.all(obs_valid != 0) else np.nan)
                            r, _ = pearsonr(obs_valid, prev_valid)
                            f_out.write(f"  Previsão {j}:\n")
                            f_out.write(f"    MAE   = {mae:.4f}\n")
                            f_out.write(f"    RMSE  = {rmse:.4f}\n")
                            f_out.write(f"    MAPE  = {mape:.2f}%\n")
                            f_out.write(f"    r     = {r:.4f}\n")
                            labels.append(f"Prev {j}")
                            rmses.append(rmse)
                            maes.append(mae)
                            mapes.append(mape)
                            rs.append(r)
                            plt.plot(tempo, prev, label=f"Prev {j}", linestyle="--")
                        plt.title(f"Comparação de Previsões - Arquivo {i}")
                        plt.xlabel("Tempo"); plt.ylabel("Valor")
                        #plt.title(f"Observado vs {res.get('etiqueta_prev_plot','Previsão')} (Histórico e Futuro)")
                        plt.legend(); plt.tight_layout(); pdf.savefig(); plt.close()
                        def plot_barras(valores, nome, ylabel):
                            plt.figure(figsize=(6, 4))
                            plt.bar(labels, valores, color='cornflowerblue')
                            plt.title(f"{nome} por Previsão - Arquivo {i}")
                            plt.ylabel(ylabel)
                            plt.tight_layout()
                            pdf.savefig(); plt.close()
                        if labels:
                            plot_barras(rmses, "RMSE", "RMSE")
                            plot_barras(maes,  "MAE",  "MAE")
                            plot_barras(mapes, "MAPE", "MAPE (%)")
                            plot_barras(rs,    "Correlação", "r")
                            import numpy as np
                            melhor_rmse = labels[int(np.argmin(rmses))]
                            melhor_mae  = labels[int(np.argmin(maes))]
                            melhor_mape = labels[int(np.argmin(mapes))]
                            melhor_r    = labels[int(np.argmax(rs))]
                            resumo_final.append(
                                f"Arquivo {i}:\n"
                                f"  Melhor RMSE: {melhor_rmse}\n"
                                f"  Melhor MAE : {melhor_mae}\n"
                                f"  Melhor MAPE: {melhor_mape}\n"
                                f"  Maior r    : {melhor_r}\n"
                            )
                        f_out.write("\n")
                    except FileNotFoundError:
                        f_out.write(f"{nome_arquivo} não encontrado.\n\n")
                    except Exception as e:
                        f_out.write(f"Erro ao processar {nome_arquivo}: {e}\n\n")
                f_out.write("\nResumo Final:\n")
                f_out.write("\n".join(resumo_final))
        except Exception as e:
            messagebox.showerror("Erro", f"Falha ao avaliar previsões:\n{e}")
            return
        self.resumo()

    def lercsv2(self):
        xl = 0
        if self.varconf.get() == 1:
            src = self.Conf.get()
            if not src or not Path(src).is_file():
                messagebox.showerror("Erro", "Falta o arquivo de configurações!")
                return
            caminho_confx = BASE_PATH / "confx.txt"
            arquivo5 = Path(self.vpath3)
            with caminho_confx.open("w", encoding="latin1") as fconfx, arquivo5.open("r", encoding="latin1") as fcsv:
                j = 1
                fconfx.write(self.ntit.get() + '\n')
                for l in fcsv:
                    l = l.strip()
                    if j != 2 and j != 3:
                        l = l.replace(',', '.').replace(';', ' ')
                        if j == 1:
                            xl_str = l.split()[0]
                            try:
                                xl = int(xl_str)
                            except Exception:
                                xl = 0
                            fconfx.write(f"{xl},{self.nprev.get()}\n")
                        else:
                            fconfx.write(l + '\n')
                    j += 1
                
                # 2) >>> NOVO: cabeçalho do Varx.txt (pulando 3 colunas) <<<
                header_cols = self._get_varx_header_cols()
                if not header_cols:
                    header_cols = []  # se não achou Varx.txt, opcionalmente pula a linha
                if header_cols:
                    fconfx.write("\nDados de entrada:   ")
                    fconfx.write(";".join(header_cols) + "\n")
        else:
            self.txtRun.delete("1.0", "end")
            self.txtRun.insert(tk.END, "  Calculando lags...\n")
            self.txtRun.update_idletasks()
            self.fazconf()
        Per = self.v3.get()
        config_dir = BASE_PATH / "config"
        caminho_confx = BASE_PATH / "confx.txt"
        if Per == 1:
            shutil_dst = config_dir / "configu.txt"
        elif Per == 2:
            shutil_dst = config_dir / "configs.txt"
        else:
            shutil_dst = config_dir / "configt.txt"
        try:
            shutil.copyfile(str(caminho_confx), str(shutil_dst))
        except Exception as e:
            messagebox.showerror("Erro", f"Falha ao salvar configuração:\n{e}")
    def ajuda(self):
        path = BASE_PATH / "manuais" / "manual-previa-C.html"
        if path.exists():
            open_system_file(path)
        else:
            messagebox.showerror("Erro", f"Ajuda não encontrada:\n{path}")
# ======================================================================
# Aba 2: PrevIA-P (versão completa adaptada)
# ======================================================================
class PrevIAPPage(tb.Frame):
    def __init__(self, master):
        super().__init__(master)
        ensure_dirs()
        self._build_vars()
        self._load_paths()
        self._build_ui()

    def _build_vars(self):
        self.v0 = tk.IntVar(value=1)  # Reservatório
        self.v1 = tk.IntVar(value=3)  # Passo de tempo
        self.v3 = tk.IntVar(value=3)  # Período
        self.v4 = tk.IntVar(value=0)
        self.v6 = tk.IntVar(value=0)
        self.asc = tk.StringVar(value="10000")
        self.dsc = tk.StringVar(value="10000")
        self.ArqCSV = tk.StringVar(value="")

        # -------------------------------
        # CONTROLE CORRETO DE MEMÓRIA
        # -------------------------------
        self.caminhos_personalizados = {}

        self.unidades = {
            1: "USB",
            2: "UIT",
            3: "UBE",
            4: "UPE",
            5: "UTM",
            6: "IUSB"
        }

        self.tempos = {
            1: "Mensal",
            3: "Diária"
        }

        # Guarda estado anterior
        self._last_v0 = self.v0.get()
        self._last_v1 = self.v1.get()

        # Caminho inicial
        self.atualizar_caminho()    

    def _load_paths(self):
        """Carrega os caminhos salvos para esta aba."""
        paths = load_file_paths().get("prev_ia_p", {})
        if "custom_paths" in paths:
            # Converte as chaves de volta para tuplas (v0, v1)
            for key, val in paths["custom_paths"].items():
                if val and Path(val).exists():
                    try:
                        k0, k1 = map(int, key.split('_'))
                        self.caminhos_personalizados[(k0, k1)] = val
                    except:
                        pass
        # Atualiza o campo com o caminho da combinação atual
        self.atualizar_caminho()

    def _save_paths(self):
        """Salva os caminhos personalizados no arquivo de configuração."""
        paths = load_file_paths()
        # Converte dicionário com tuplas para string
        custom = {f"{k0}_{k1}": v for (k0, k1), v in self.caminhos_personalizados.items()}
        paths["prev_ia_p"] = {"custom_paths": custom}
        save_file_paths(paths)

    def mudanome(self):

        nomeres = self.unidades[self.v0.get()]
        tempo = self.tempos[self.v1.get()]    
        opath = BASE_PATH / "relat" / "relatprev.html"
        path = BASE_PATH / "relat" / f"relatprev_{nomeres}_{tempo}.html"
        self.log(f"Renomeando arquivo {path}")
        shutil.copy(opath, path)
        opath = BASE_PATH / "plan" / f"relatprev.csv"
        path = BASE_PATH / "plan" / f"relatprev_{nomeres}_{tempo}.csv"
        shutil.copy(opath, path)
        self.log(f"Renomeando arquivo {path}")

    def seltempo(self):
        self._troca_radio()

    def selpasso(self):
        self._troca_radio()

    def _troca_radio(self):
        # Salva usando estado anterior
        chave_antiga = (self._last_v0, self._last_v1)
        self.caminhos_personalizados[chave_antiga] = self.ArqCSV.get()

        # Atualiza estado atual
        self._last_v0 = self.v0.get()
        self._last_v1 = self.v1.get()

        # Atualiza campo
        self.atualizar_caminho()
        self._save_paths()   # <-- NOVO: salvar após troca

    def obter_caminho_padrao(self):
        unidade = self.unidades[self.v0.get()]
        tempo = self.tempos[self.v1.get()]
        return f"dados/{unidade}/Dados_Previsão_{tempo}_{unidade}.csv"

    def atualizar_caminho(self):
        chave = (self.v0.get(), self.v1.get())

        if chave in self.caminhos_personalizados:
            self.ArqCSV.set(self.caminhos_personalizados[chave])
        else:
            self.ArqCSV.set(self.obter_caminho_padrao())

    def _build_ui(self):
        frame_left = tb.Frame(self, padding=2)
        frame_left.grid(row=0, column=0, sticky="nsew")
        frame_right = tb.Frame(self, padding=2)
        frame_right.grid(row=0, column=1, sticky="nsew")
        self.columnconfigure(0, weight=2)
        self.columnconfigure(1, weight=3)
        self.rowconfigure(0, weight=1)

        tb.Label(frame_left, text="PrevIA-P", font=("Segoe UI", 22, "bold")).grid(row=0, column=0, pady=(0, 8), sticky="ew")
        tb.Label(frame_left, text="Modelo de Inteligência Artificial GMDH para Previsão de Vazões").grid(row=1, column=0, sticky="w")
        
        tb.Label(frame_left, text="Arquivo CSV com os últimos dados observados:").grid(row=5, column=0, sticky="w",pady=(8,0))
        row_csv = tb.Frame(frame_left)
        row_csv.grid(row=6, column=0, sticky="ew", pady=5)
        row_csv.columnconfigure(0, weight=1)
        self.txtCSV = tb.Entry(row_csv, textvariable=self.ArqCSV, width=70)
        self.txtCSV.grid(row=0, column=0, sticky="ew")
        tb.Button(row_csv, text="Buscar", bootstyle="primary", command=self.select_csv).grid(row=0, column=1, padx=6)
        tb.Button(row_csv, text="Abrir ", bootstyle="primary", command=self.abredados).grid(row=0, column=2, padx=6)

        reserv = tb.Labelframe(frame_left, text="Reservatório")
        reserv.grid(row=3, column=0,columnspan=4, sticky="ew", pady=10)
        opts_res = [("Sobradinho",1), ("Itaparica",2), ("Boa Esperança",3), ("Pedra",4), ("Três Marias",5), ("Sobradinho Incremental",6)]
        for i, (txt, val) in enumerate(opts_res):
            tb.Radiobutton(reserv, text=txt, variable=self.v0, value=val,
                           bootstyle="primary", command=self.seltempo)\
              .grid(padx=8, pady=4, sticky="w")

        tempo = tb.Labelframe(frame_left, text="Passo de Tempo")
        tempo.grid(row=4, column=0, sticky="ew", pady=10)
        for i, (txt, val) in enumerate([ ("Diária",3), ("Mensal",1)]):
            tb.Radiobutton(tempo, text=txt, variable=self.v1, value=val,
                           bootstyle="info",command=self.selpasso)\
              .grid(row=0, column=i, padx=10, pady=4)

        periodo = tb.Labelframe(frame_left, text="Período")
        periodo.grid(row=5, column=0, sticky="ew", pady=10)
        for i, (txt, val) in enumerate([("Período Total  ",3), ("Período Seco  ",2), ("Período Úmido  ",1)]):
            tb.Radiobutton(periodo, text=txt, variable=self.v3, value=val,
                           bootstyle="success")\
              .grid(row=0, column=i, padx=10, pady=4)

        taxas = tb.Labelframe(frame_left, text="Taxas de Controle")
        taxas.grid(row=7, column=0, sticky="ew", pady=10)
        tb.Label(taxas, text="Ascensão (%):").grid(row=0, column=0, padx=5, sticky="e")
        tb.Entry(taxas, textvariable=self.asc, width=10).grid(row=0, column=1, padx=5, sticky="w")
        tb.Label(taxas, text="Recessão (%):").grid(row=0, column=2, padx=5, sticky="e")
        tb.Entry(taxas, textvariable=self.dsc, width=10).grid(row=0, column=3, padx=5, sticky="w")

        imp_row = tb.Frame(frame_left)
        imp_row.grid(row=8, column=0, sticky="ew", pady=10)

       # ⬇️ Crie o botão e GUARDE em self.btnImport
        self.btnImport = tb.Button(
            imp_row,
            text="Importar Configuração",
            bootstyle="warning",
            command=self.open_import_window
        )
        self.btnImport.grid(row=1, column=1)

        # Começa desabilitado (estado inicial coerente com v4=0)
        self.btnImport.state(["disabled"])

        # ⬇️ Checkbox que controla o estado do botão
        tb.Checkbutton(
            imp_row,
            text="Importar Calibração",
            variable=self.v4,
            bootstyle="danger",
            command=self.toggle_import  # chama ao marcar/desmarcar
        ).grid(row=1, column=0, padx=(0,10))

        # ⬇️ NOVO: botão "Consultar calibração" sempre habilitado, logo abaixo do Importar
        self.btnConsultar = tb.Button(
            imp_row,
            text="Consultar calibração",
            bootstyle="warning",  # pode mudar para "info" se preferir
            command=self.ver_calibracao
        )
        
        self.btnConsultar.grid(row=0, column=0, pady=(6, 6), sticky="w")

        self.btn_arvore = tb.Button(imp_row,text="Árvore de dependências", command=self.executar_analise_gmdh, bootstyle="warning")
        self.btn_arvore.grid(row=0, column=1, pady=(6, 6))

        tb.Label(frame_right, text="Log de Execução", font=("Segoe UI", 14, "bold")).grid(row=0, column=0, sticky="w")
        self.txtRun = ScrolledText(frame_right, height=25, width=70)
        self.txtRun.configure(font=("Courier", 10))
        self.txtRun.grid(row=1, column=0, sticky="nsew", pady=10)
        # --- Tags de formatação para o Log de Execução ---
        self.txtRun.tag_configure("bold", font=("Courier", 10, "bold"))
        self.txtRun.tag_configure("info", foreground="#0d6efd")      # azul (Bootstrap 'primary')
        self.txtRun.tag_configure("success", foreground="#198754")    # verde (Bootstrap 'success')
        self.txtRun.tag_configure("warning", foreground="#ffc107")    # amarelo
        self.txtRun.tag_configure("danger", foreground="#dc3545")     # vermelho
        self.txtRun.tag_configure("muted", foreground="#6c757d")      # cinza
        self.txtRun.tag_configure("header", foreground="#0d6efd", font=("Courier", 10, "bold"))
        self.txtRun.tag_configure("mono", font=("Courier", 10))


        frame_right.rowconfigure(1, weight=1)

        btns = tb.Frame(frame_right)
        btns.grid(row=2, column=0, pady=10)
        tb.Button(btns, text="Previsão", command=self.escreve, bootstyle="primary").grid(row=0, column=0, padx=5)
        self.btn_relatorio = tb.Button(btns, text="Relatório", command=self.resultado, bootstyle="success",state="disabled")
        self.btn_relatorio.grid(row=0, column=1, padx=5)
        self.btn_planilha = tb.Button(btns, text="Planilha", command=self.planilha, bootstyle="info",state="disabled")
        self.btn_planilha.grid(row=0, column=2, padx=5)
        tb.Button(btns, text="Ajuda", command=self.ajuda, bootstyle="dark").grid(row=0, column=3, padx=5)
        self.btnFechar = tb.Button(btns, text="Fechar",
                                    command=lambda: self.winfo_toplevel().destroy(),  # fecha a janela atual
                                    bootstyle="danger")           # cor vermelha para destacar
        self.btnFechar.grid(row=0, column=4, padx=5)
        self.seltempo()

    def executar_analise_gmdh(self):
        """
        Executa a análise do modelo GMDH para a configuração atual,
        gerando os relatórios de dependências (texto e HTML interativo).
        """
        # Obtém os códigos para formar o nome do arquivo de pares
        res = self._reserv_code(self.v0.get())
        tp = self._tempo_code(self.v1.get())
        pr = self._period_code(self.v3.get())
        pares_file = BASE_PATH / "config" / f"pares{res}{tp}{pr}"

        if not pares_file.exists():
            self.log(f"Arquivo de pares não encontrado: {pares_file}", "bold", "danger")
            messagebox.showerror("Erro", f"Arquivo de pares não encontrado:\n{pares_file}")
            return

        try:
            # Instancia o parser com o arquivo de pares
            parser = GMDHModelParser(str(pares_file))
            parser.parse()

            # Opcional: exibe resumo no log
            self.log("=== Análise do modelo GMDH ===", "header")
            # O resumo pode ser capturado e enviado para o log, mas vamos apenas gerar os arquivos

            # Define os caminhos de saída (pode ser dentro da pasta do projeto)
            output_dir = BASE_PATH / "analise_gmdh"
            output_dir.mkdir(exist_ok=True)

            rastreamento_txt = output_dir / f"rastreamento_{res}{tp}{pr}.txt"
            penultima_txt = output_dir / f"arvore_camada_{res}{tp}{pr}.txt"
            penultima_html = output_dir / f"arvore_camada_{res}{tp}{pr}.html"

            # Gera os arquivos
            parser.exportar_rastreamento(str(rastreamento_txt))
            parser.exportar_penultima_camada(str(penultima_txt))
            parser.exportar_penultima_camada_html(str(penultima_html))

            self.log(f"Rastreamento completo gerado em: {rastreamento_txt}", "success")
            self.log(f"Penúltima camada (texto) gerada em: {penultima_txt}", "success")
            self.log(f"Diagrama interativo gerado em: {penultima_html}", "success")

            # Abre o HTML automaticamente
            if penultima_html.exists():
                open_system_file(str(penultima_html))

        except Exception as e:
            self.log(f"Erro na análise GMDH: {e}", "bold", "danger")
            messagebox.showerror("Erro", f"Falha ao processar o modelo:\n{e}")


    def obter_caminho_padrao(self):
        unidade = self.unidades[self.v0.get()]
        tempo = self.tempos[self.v1.get()]
        return f"dados/{unidade}/Dados_Previsão_{tempo}_{unidade}.csv"
    def salvar_caminho_atual(self):
        chave = (self.v0.get(), self.v1.get())
        self.caminhos_personalizados[chave] = self.ArqCSV.get()    
    def atualizar_caminho(self):
        chave = (self.v0.get(), self.v1.get())

        if chave in self.caminhos_personalizados:
            self.ArqCSV.set(self.caminhos_personalizados[chave])
        else:
            self.ArqCSV.set(self.obter_caminho_padrao())    
    def diminuivarx(self):
        varx_path = BASE_PATH / "varx.txt"
        varxc_path = BASE_PATH / "varxc.txt"
        if varxc_path.exists():
            varxc_path.unlink(missing_ok=True)
        if not varx_path.exists() or varx_path.stat().st_size == 0:
            messagebox.showerror("Previsão", "Não existe calibração!")
            raise RuntimeError("Parando execução por falta de varx.txt")
        varx_path.rename(varxc_path)
        with varxc_path.open("r", encoding="latin1") as fin:
            linhas = fin.readlines()
        if varx_path.exists():
            varx_path.unlink(missing_ok=True)
        i = len(linhas)
        ii = 99 if i >= 100 else i
        with varx_path.open("w", encoding="latin1") as fout:
            for j, l in enumerate(linhas, start=1):
                if j == 1 or j >= i - ii:
                    fout.write(l)

    # Helpers de mapeamento
    @staticmethod
    def _reserv_code(v0):
        return {1: "usb", 2: "uit", 3: "ube", 4: "upe", 5: "utm", 6: "usbi"}[v0]

    @staticmethod
    def _tempo_code(v1):
        return {1: "m", 2: "s", 3: "d"}[v1]

    @staticmethod
    def _period_code(v3):
        return {1: "u", 2: "s", 3: "t"}[v3]

    @staticmethod
    def _period_labels(v3):
        if v3 == 1: return ("coefu.txt", "configu.txt", "paresu.txt", "Período Úmido")
        if v3 == 2: return ("coefs.txt", "configs.txt", "paress.txt","Período Seco")
        return ("coeft.txt", "configt.txt","parest.txt", "Período Total")

    def _dest_paths(self):
        res = self._reserv_code(self.v0.get())
        tp  = self._tempo_code(self.v1.get())
        pr  = self._period_code(self.v3.get())
        coef_src  = BASE_PATH / "config" / f"coef{res}{tp}{pr}"
        config_src= BASE_PATH / "config" / f"config{res}{tp}{pr}"
        return (coef_src, config_src)

    # Ações principais

    def log(self, texto: str, *tags):
        """Escreve no Log de Execução com horário e tags opcionais."""

        from datetime import datetime

        t = datetime.now().strftime("%H:%M:%S")

        if hasattr(self, "txtRun") and self.txtRun:

            msg = f"[{t}] {texto}"

            if tags:
                self.txtRun.insert(tk.END, msg, tags)
            else:
                self.txtRun.insert(tk.END, msg)

            if not texto.endswith("\n"):
                self.txtRun.insert(tk.END, "\n")

            self.txtRun.see(tk.END)

    def ver_calibracao(self):
        """
        Consulta a calibração atual, exibe reservatório/tempo/período, mostra os caminhos,
        registra o CONTEÚDO do arquivo de configuração no Log de Execução e
        explicita:
        - o maior número inteiro (ignorando a 1ª linha e ignorando inteiros que façam parte de decimais);
        - os "Dados de entrada:" (itens separados por ';');
        - para cada horizonte no arquivo de coeficientes, o número de camada
        (maior camada encontrada abaixo do horizonte menos 1).
        """
        try:
            from datetime import datetime
            import re
            from pathlib import Path
            import tkinter as tk
            from tkinter import messagebox

            # Monta caminhos atuais
            coef_src, config_src = self._dest_paths()

            # Texto do reservatório / período / tempo
            reserv_txt = {
                1: "Sobradinho",
                2: "Itaparica",
                3: "Boa Esperança",
                4: "Pedra",
                5: "Três Marias",
                6: "Sobradinho Incremental",
            }[self.v0.get()]
            _, _, _, periodo_txt = self._period_labels(self.v3.get())
            tempo_txt = {1: "Mensal", 3: "Diária", 2: "Semanal"}[self.v1.get()]

            # Caixa de mensagem com contexto
            messagebox.showinfo(
                "Consultar calibração",
                (
                    f"{reserv_txt} • {tempo_txt} • {periodo_txt}\n\n"
                    f"Arquivos de calibração esperados:\n\n"
                    f"Coeficientes: {coef_src}\n"
                    f"Configuração: {config_src}"
                )
            )

            # ================= LEITURA DO ARQUIVO DE CONFIGURAÇÃO =================
            if not Path(config_src).exists():
                messagebox.showwarning(
                    "Aviso",
                    f"Arquivo de configuração não encontrado:\n{config_src}"
                )
                if hasattr(self, "log"):
                    self.log(f"[AVISO] Configuração não encontrada: {config_src}", "bold", "warning")
                return

            content = None
            for enc in ("latin1", "utf-8"):
                try:
                    with open(config_src, "r", encoding=enc, errors="ignore") as f:
                        content = f.read()
                    break
                except Exception:
                    continue

            if content is None:
                raise IOError(f"Não foi possível ler o conteúdo de {config_src}.")

            # ================= LOG DO CONTEÚDO =================
            ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if hasattr(self, "log"):
                self.log(f"{ts} • Conteúdo de configuração ({config_src}):", "header")
                self.log("-" * 60, "muted")
                self.log(content, "mono")
                self.log("-" * 60, "muted")

            # ================= MAIOR NÚMERO INTEIRO =================
            parts = re.split(r'\r?\n', content, maxsplit=1)
            text_without_first_line = parts[1] if len(parts) > 1 else ""

            ints = []
            for m in re.finditer(r'-?\d+', text_without_first_line):
                end = m.end()
                if end < len(text_without_first_line) and text_without_first_line[end] == '.':
                    continue
                ints.append(int(m.group()))

            max_int = max(ints) if ints else None

            # ================= DADOS DE ENTRADA =================
            dados_entrada_items = None
            re_de = re.compile(
                r'^\s*dados\s+de\s+entrada\s*:\s*(.*)$',
                re.IGNORECASE
            )

            for ln in content.splitlines():
                m = re_de.match(ln)
                if m:
                    after = m.group(1).strip()
                    dados_entrada_items = [
                        x.strip() for x in after.split(";") if x.strip()
                    ]
                    break

            # ================= ANÁLISE DO ARQUIVO DE COEFICIENTES =================
            horizonte_camadas = []

            if Path(coef_src).exists():
                with open(coef_src, "r", encoding="latin1", errors="ignore") as f:
                    coef_content = f.read()

                lines = coef_content.splitlines()
                i = 0

                while i < len(lines):
                    line = lines[i]

                    if re.search(r'\bhorizonte\b', line, re.IGNORECASE):
                        camadas = []
                        i += 1

                        while i < len(lines) and not re.search(
                            r'\bhorizonte\b', lines[i], re.IGNORECASE
                        ):
                            m = re.search(
                                r'\b(\d+)\s+camada\(s\)',
                                lines[i],
                                re.IGNORECASE
                            )

                            if m:
                                camadas.append(int(m.group(1)))
                            i += 1

                        if camadas:
                            horizonte_camadas.append(max(camadas))
                        else:
                            horizonte_camadas.append(None)
                    else:
                        i += 1

            # ================= LOG DOS RESULTADOS =================
            if hasattr(self, "log"):
                if max_int is not None:
                    self.log(
                        f"Número mínimo de dados observados= {max_int}",
                        "bold",
                        "success"
                    )
                else:
                    self.log(
                        "Número mínimo de dados observados= (não encontrado)",
                        "bold",
                        "warning"
                    )

                if dados_entrada_items:
                    self.log(
                        f"Dados de entrada = {'; '.join(dados_entrada_items)}",
                        "bold",
                        "info"
                    )
                else:
                    self.log(
                        "Dados de entrada = (linha não encontrada)",
                        "bold",
                        "danger"
                    )

                if horizonte_camadas:
                    for idx, ch in enumerate(horizonte_camadas, start=1):
                        if ch is not None:
                            self.log(
                                f"Horizonte {idx}: número de camada = {ch}",
                                "bold",
                                "info"
                            )
                        else:
                            self.log(
                                f"Horizonte {idx}: nenhuma camada encontrada",
                                "bold",
                                "warning"
                            )
                else:
                    self.log(
                        "Nenhum horizonte encontrado no arquivo de coeficientes.",
                        "bold",
                        "warning"
                    )

                self.log("")

        except Exception as e:
            messagebox.showerror(
                "Erro",
                f"Falha ao consultar calibração:\n{e}"
            )
            if hasattr(self, "log"):
                self.log(f"[ERRO] {e}", "bold", "danger")

    def select_csv(self):
        sel = pick_file("Selecionar arquivo CSV", (("CSV", "*.csv"), ("Todos", "*.*")))
        if sel:
            self.ArqCSV.set(sel)
            chave = (self.v0.get(), self.v1.get())
            self.caminhos_personalizados[chave] = sel
            self._save_paths()   # <-- NOVO

    def escreve(self):
        
        vpath2 = BASE_PATH / self.ArqCSV.get().strip()
        self.log(f"Montando caso.")
        
        if not vpath2 or not Path(vpath2).is_file():
            messagebox.showerror("Erro", "Selecione um arquivo CSV válido!")
            return        
        self.lercsv1(vpath2)
        asc1 = self.asc.get().strip() or "10000"
        dsc1 = self.dsc.get().strip() or "10000"
        with open(BASE_PATH / "temp.txt", "w", encoding="latin1") as f:
            f.write(f"{asc1} {dsc1} {'1' if self.v6.get() == 1 else '0'}")
            f.write(f" {self.v1.get()} {self.v0.get()}\n {self.v3.get()}")
        coef_src, config_src = self._dest_paths()
        if not coef_src.exists() or not config_src.exists():
            messagebox.showerror("Erro", f"Arquivos de calibração não encontrados:\n{coef_src}\n{config_src}")
            return
        shutil.copyfile(str(coef_src), str(BASE_PATH / "coef.txt"))
        shutil.copyfile(str(config_src), str(BASE_PATH / "config.txt"))
        self.rodar(vpath2)

    def lercsv1(self, vpath2):
        self.log(f"Lendo arquivo {vpath2}.")
        with open(BASE_PATH / "varx.txt", "w", encoding="latin1") as fout, \
             open(vpath2, "r", encoding="latin1") as fin:
            for l in fin:
                l = l.strip().replace(",", ".").replace(";", ",")
                fout.write(l + "\n")
        self.diminuivarx()

    def rodar(self,vpath2):
        #self.txtRun.delete("1.0", "end")
        self.txtRun.insert (tk.END,"\n") 
        self.txtRun.insert (tk.END,vpath2)
        self.txtRun.insert (tk.END,"\n")
        self.txtRun.insert(tk.END, "AGUARDE...\n")
        self.txtRun.update_idletasks()
        run_exe("P.exe", self.txtRun)
        self.btn_planilha.config(state="normal")
        self.btn_relatorio.config(state="normal")
        self.mudanome()

    def resultado(self):
        
        nomeres = self.unidades[self.v0.get()]
        tempo = self.tempos[self.v1.get()]    

        #opath = BASE_PATH / "relat" / "relatprev.html"
        
        path = BASE_PATH / "relat" / f"relatprev_{nomeres}_{tempo}.html"
        self.log(f"Abrindo arquivo {path}.")
        #shutil.copy(opath, path)

        if path.exists():
            messagebox.showinfo("Lembrete:", "Imprima ou salve o arquivo de resultados em sua pasta!")
            open_system_file(path)
        else:
            messagebox.showerror("Erro", f"Relatório não encontrado:\n{path}")

    def planilha(self):

        nomeres = self.unidades[self.v0.get()]
        tempo = self.tempos[self.v1.get()]  
        #opath = BASE_PATH / "plan" / f"relatprev.csv"
        path = BASE_PATH / "plan" / f"relatprev_{nomeres}_{tempo}.csv"
        #shutil.copy(opath, path)
        if path.exists():
            open_system_file(path)
        else:
            messagebox.showerror("Erro", f"Planilha não encontrada:\n{path}")
    
    def abredados(self):
        path = BASE_PATH / self.txtCSV.get()
        if path.exists():
            open_system_file(path)
        else:
            messagebox.showerror("Erro", f"Planilha não encontrada:\n{path}")        

    def ajuda(self):
        path = BASE_PATH / "manuais" / "manual-previa-P.html"
        if path.exists():
            open_system_file(path)
        else:
            messagebox.showerror("Erro", f"Ajuda não encontrada:\n{path}")

    def toggle_import(self):
        if self.v4.get() == 1:
            self.btnImport.state(["!disabled"])
            messagebox.showinfo("Importar Calibração", "Selecione abaixo o Reservatório, Passo de Tempo e Período, depois clique em 'Importar Configuração'.")
        else:
            self.btnImport.state(["disabled"])
            messagebox.showinfo("Importar Calibração", "Importação desativada.")

    def open_import_window(self):
        coef_src, config_src = self._dest_paths()
        coef_lbl, conf_lbl, pares_lbl, periodo_txt= self._period_labels(self.v3.get())
        reserv_txt = {1:"Sobradinho",2:"Itaparica",3:"Boa Esperança",4:"Pedra",5:"Três Marias",6:"Sobradinho Incremental"}[self.v0.get()]
        tempo_txt  = {1:"Mensal",2:"Semanal",3:"Diária"}[self.v1.get()]
        ok = messagebox.askokcancel(
            "Importar configurações",
            f"Importar configurações para\n{reserv_txt} {tempo_txt}\n{periodo_txt}?",
            icon=messagebox.QUESTION
        )
        if not ok:
            return

        win = tb.Toplevel(self)
        win.title("Importar dados de calibração")
        safe_set_icon(win, "config/previa.ico")
        win.geometry("750x420")

        # --- Modificações: remover topmost, manter transient + grab_set ---
        win.transient(self)              # vincula como diálogo da janela principal
        win.grab_set()                   # torna modal (bloqueia interação na principal)
        # NÃO usar win.attributes('-topmost', True) - isso faz o filedialog ficar atrás

        # Encerramento seguro: libera o grab antes de destruir
        def _on_close():
            try:
                win.grab_release()
            except Exception:
                pass
            win.destroy()
        win.protocol("WM_DELETE_WINDOW", _on_close)

        # Atalho: Esc fecha a janela
        win.bind('<Escape>', lambda e: _on_close())

        # --- Função para abrir o filedialog, sempre com parent=win (se suportado) ---
        def _pick_file_front(title, filetypes):
            # Se pick_file aceitar parent, usamos; senão, chamamos sem
            try:
                # Tenta chamar com o argumento parent
                return pick_file(title, filetypes, parent=win)
            except TypeError:
                # Fallback: chama sem parent; o diálogo ainda será modal para win
                return pick_file(title, filetypes)

        # Construção da interface (igual, apenas usando a função modificada)
        tb.Label(win, text="Importar PrevIA-P", font=("Segoe UI", 18, "bold"),
                bootstyle="info").grid(row=0, column=0, columnspan=3, sticky="ew", pady=(8,2),padx=10)
        tb.Label(win, text=f"{reserv_txt} • {tempo_txt} • {periodo_txt}",
                bootstyle="primary").grid(row=1, column=0, columnspan=3, sticky="w", padx=10, pady=(0,8))
        tb.Label(win, text=f"Arquivo de coeficientes (Fonte: {coef_lbl}):").grid(row=2, column=0, sticky="w", padx=10)
        coef_var = tk.StringVar()
        coef_entry = tb.Entry(win, textvariable=coef_var, width=58)
        coef_entry.grid(row=3, column=0, sticky="ew", padx=8)
        tb.Button(win, text="Buscar", bootstyle="primary",
                command=lambda: coef_var.set(_pick_file_front("Selecionar coeficiente (*.txt)", (("TXT", "*.txt"),("Todos","*.*"))))
                ).grid(row=3, column=1, padx=10)
        tb.Label(win, text=f"Arquivo de configuração (Fonte: {conf_lbl}):").grid(row=4, column=0, sticky="w", padx=10, pady=(8,0))
        conf_var = tk.StringVar()
        conf_entry = tb.Entry(win, textvariable=conf_var, width=58)
        conf_entry.grid(row=5, column=0, sticky="ew", padx=10)
        tb.Button(win, text="Buscar", bootstyle="primary",
                command=lambda: conf_var.set(_pick_file_front("Selecionar configuração (*.txt)", (("TXT", "*.txt"),("Todos","*.*"))))
                ).grid(row=5, column=1, padx=10)
        # Pares
        tb.Label(win, text=f"Arquivo de pares (Fonte: {pares_lbl}):").grid(row=6, column=0, sticky="w", padx=10, pady=(8,0))
        pares_var = tk.StringVar()
        pares_entry = tb.Entry(win, textvariable=pares_var, width=58)
        pares_entry.grid(row=7, column=0, sticky="ew", padx=10)
        tb.Button(win, text="Buscar", bootstyle="primary",
                command=lambda: pares_var.set(_pick_file_front("Selecionar pares (*.txt)", (("TXT", "*.txt"),("Todos","*.*"))))
                ).grid(row=7, column=1, padx=10)        

        def do_import():
            src_coef = coef_var.get().strip()
            src_conf = conf_var.get().strip()
            src_pares = pares_var.get().strip()

            res = self._reserv_code(self.v0.get())
            tp = self._tempo_code(self.v1.get())
            pr = self._period_code(self.v3.get())
            dest_pares_repo = BASE_PATH / "config" / f"pares{res}{tp}{pr}"

            if not src_coef or not Path(src_coef).is_file():
                messagebox.showerror("Erro", "Selecione um arquivo de coeficientes válido (.txt)!")
                return
            if not src_conf or not Path(src_conf).is_file():
                messagebox.showerror("Erro", "Selecione um arquivo de configuração válido (.txt)!")
                return
            if src_pares and not Path(src_pares).is_file():
                messagebox.showerror("Erro", "Selecione um arquivo de pares válido (.txt)!")
                return            
            dest_coef_repo = coef_src
            dest_conf_repo = config_src

            for dest in (dest_coef_repo, dest_conf_repo, dest_pares_repo):
                old = Path(str(dest) + "old")
                try:
                    if old.exists():
                        old.unlink(missing_ok=True)
                    if dest.exists():
                        dest.rename(old)
                except Exception as e:
                    messagebox.showwarning("Aviso", f"Não foi possível mover backup para {old}:\n{e}")
            try:
                shutil.copyfile(src_coef, dest_coef_repo)
                shutil.copyfile(src_conf, dest_conf_repo)
                shutil.copyfile(src_pares, dest_pares_repo)
            except Exception as e:
                messagebox.showerror("Erro", f"Falha ao copiar para repositório:\n{e}")
                return
            try:
                shutil.copyfile(dest_coef_repo, BASE_PATH / "coef.txt")
                shutil.copyfile(dest_conf_repo, BASE_PATH / "config.txt")
            except Exception as e:
                messagebox.showwarning("Aviso", f"Copiado ao repositório, mas não atualizado coef.txt/config.txt:\n{e}")
            messagebox.showinfo("Sucesso", "Importado com sucesso!")
            _on_close()

        buttons = tb.Frame(win)
        buttons.grid(row=8, column=0, columnspan=3, pady=12)
        tb.Button(buttons, text="Importar", bootstyle="success", command=do_import).grid(row=0, column=0, padx=8)
        tb.Button(buttons, text="Fechar", bootstyle="primary", command=_on_close).grid(row=0, column=1, padx=8)

        for c in range(3):
            win.columnconfigure(c, weight=1)

# ======================================================================
# Aba 3: PrevIA-PP (versão completa adaptada)
# ======================================================================
class PrevIAPPPage(tb.Frame):
    def __init__(self, master):
        super().__init__(master)
        ensure_dirs()
        self._build_vars()
        self._load_paths()
        self._build_ui()

    def _build_vars(self):
        self.var_reserv = tk.IntVar(value=1)
        self.var_inc_mode = tk.IntVar(value=1)
        self.var_inc_period = tk.IntVar(value=3)
        self.var_prev_montante = tk.IntVar(value=0)
        self.var_prev_inc = tk.IntVar(value=0)
        self.var_prev_mont = tk.IntVar(value=0)

        self.asc = tk.StringVar(value="10000")
        self.dsc = tk.StringVar(value="10000")

        self.ArqDados = tk.StringVar(value="")
        self.ArqInc = tk.StringVar(value="")
        self.ArqProp = tk.StringVar(value="")

        # -------------------------
        # MEMÓRIA PERSONALIZADA
        # -------------------------
        self.mem_dados = {}
        self.mem_prop = {}

        self._last_reserv = self.var_reserv.get()

        self._atualizar_caminhos()

    def _load_paths(self):
        """Carrega os caminhos salvos para esta aba."""
        paths = load_file_paths().get("prev_ia_pp", {})
        if "dados_mem" in paths:
            for k, v in paths["dados_mem"].items():
                if v and Path(v).exists():
                    self.mem_dados[int(k)] = v
        if "prop_mem" in paths:
            for k, v in paths["prop_mem"].items():
                if v and Path(v).exists():
                    self.mem_prop[int(k)] = v
        if "inc" in paths and Path(paths["inc"]).exists():
            self.ArqInc.set(paths["inc"])
        self._atualizar_caminhos()

    def _save_paths(self):
        """Salva os caminhos personalizados no arquivo de configuração."""
        paths = load_file_paths()
        paths["prev_ia_pp"] = {
            "dados_mem": {str(k): v for k, v in self.mem_dados.items()},
            "prop_mem": {str(k): v for k, v in self.mem_prop.items()},
            "inc": self.ArqInc.get()
        }
        save_file_paths(paths)

    def _build_ui(self):
        frame_left = tb.Frame(self, padding=2)
        frame_left.grid(row=0, column=0, sticky="nsew")
        frame_right = tb.Frame(self, padding=2)
        frame_right.grid(row=0, column=1, sticky="nsew")
        self.columnconfigure(0, weight=3)
        self.columnconfigure(1, weight=2)
        self.rowconfigure(0, weight=1)

        tb.Label(frame_left, text="PrevIA-PP", font=("Segoe UI", 22, "bold")).grid(row=0, column=0, pady=(0, 10), sticky="ew")
        tb.Label(frame_left, text="Modelo Híbrido para Previsão de Vazões").grid(row=1, column=0, pady=(0, 10), sticky="w")

        reserv = tb.Labelframe(frame_left, text="Reservatório")
        reserv.grid(row=2, column=0, sticky="ew", pady=10)
        opts_res = [("Sobradinho",1), ("Itaparica",2), ("Boa Esperança",3), ("Pedra",4)]
        for i, (txt, val) in enumerate(opts_res):
            tb.Radiobutton(reserv, text=txt, variable=self.var_reserv, value=val,
                           bootstyle="primary", command = self.selcaminho)\
            .grid(padx=8, pady=4, sticky="w")
        self.selcaminho()
        tb.Label(frame_left, text="Arquivo CSV com os últimos dados observados:").grid(row=3, column=0, sticky="w")
        row_dados = tb.Frame(frame_left)
        row_dados.grid(row=4, column=0, sticky="ew", pady=5)
        row_dados.columnconfigure(0, weight=1)
        txtCSV = tb.Entry(row_dados, textvariable=self.ArqDados, width=70)
        txtCSV.grid(row=0, column=0, sticky="ew")
        tb.Button(row_dados, text="Buscar", bootstyle="primary", command=self.select_dados).grid(row=0, column=1, padx=6)
        tb.Button(row_dados, text="Abrir ", bootstyle="primary", command=self.abredados1).grid(row=0, column=2, padx=6)

        prop_frame = tb.Labelframe(frame_left, text="Propagar Montante")
        prop_frame.grid(row=5, column=0, sticky="ew", pady=10)
        tb.Checkbutton(prop_frame, text="Prever Montante", variable=self.var_prev_montante, bootstyle="danger", command=self.toggle_propagar).grid(row=0, column=0, padx=5,sticky="w")
        row_prop = tb.Frame(prop_frame)
        row_prop.grid(row=1, column=0, sticky="ew", pady=5)
        row_prop.columnconfigure(0, weight=1)
        Apropagar = tb.Entry(row_prop, textvariable=self.ArqProp, width = 70)
        Apropagar.grid(row=0, column=0, sticky="ew")
        self.btnProp = tb.Button(row_prop, text="Buscar", bootstyle="primary", command=self.select_propagar)
        self.btnProp.grid(row=0, column=1, padx=6)
        self.btnAProp = tb.Button(row_prop, text="Abrir ", bootstyle="primary", command=self.abredados2)
        self.btnAProp.grid(row=0, column=2, padx=6)        

        inc_frame = tb.Labelframe(frame_left, text="Incrementais")
        inc_frame.grid(row=6, column=0, sticky="ew", pady=10)
        tb.Radiobutton(inc_frame, text="Automática", variable=self.var_inc_mode, value=1, bootstyle="success", command=self.toggle_incremental).grid(row=0, column=0, padx=5, sticky="w")
        tb.Radiobutton(inc_frame, text="Manual", variable=self.var_inc_mode, value=2, bootstyle="warning", command=self.toggle_incremental).grid(row=0, column=1, padx=5, sticky="w")

        # --- Período dos Incrementais ---
        self.var_inc_period = tb.IntVar(value=3)

        per_frame = tb.Frame(inc_frame)
        per_frame.grid(row=1, column=0, columnspan=2, sticky="w", padx=0, pady=(5, 0))

        self.rb_per_total = tb.Radiobutton(
            per_frame, text="Período Total  ",
            variable=self.var_inc_period, value=3,
            state="disabled"
        )
        self.rb_per_total.grid(row=1, column=0, padx=5, sticky="e")

        self.rb_per_seco = tb.Radiobutton(
            per_frame, text="Período Seco  ",
            variable=self.var_inc_period, value=2,
            state="disabled"
        )
        self.rb_per_seco.grid(row=1, column=1, padx=5, sticky="e")

        self.rb_per_umido = tb.Radiobutton(
            per_frame, text="Período Úmido  ",
            variable=self.var_inc_period, value=1,
            state="disabled"
        )
        self.rb_per_umido.grid(row=1, column=2, padx=5, sticky="e")
        
        row_inc = tb.Frame(inc_frame)
        row_inc.grid(row=2, column=0, columnspan=2, sticky="ew", pady=5)
        row_inc.columnconfigure(0, weight=1)
        tb.Entry(row_inc, textvariable=self.ArqInc, width = 70).grid(row=0, column=0, sticky="ew")
        self.btnInc = tb.Button(row_inc, text="Buscar", bootstyle="primary", command=self.select_incremental)
        self.btnInc.grid(row=0, column=1, padx=6)
        self.btnIncA = tb.Button(row_inc, text="Abrir ", bootstyle="primary", command=self.abreinc)
        self.btnIncA.grid(row=0, column=2, padx=6)        

        taxas = tb.Labelframe(frame_left, text="Taxas de Controle")
        taxas.grid(row=7, column=0, sticky="ew", pady=10)
        tb.Label(taxas, text="Ascensão (%):").grid(row=0, column=0, padx=5, sticky="e")
        self.txtAsc = tb.Entry(taxas, textvariable=self.asc, width=10)
        self.txtAsc.grid(row=0, column=1, padx=5, sticky="w")
        tb.Label(taxas, text="Recessão (%):").grid(row=0, column=2, padx=5, sticky="e")
        self.txtDsc = tb.Entry(taxas, textvariable=self.dsc, width=10)
        self.txtDsc.grid(row=0, column=3, padx=5, sticky="w")


        tb.Label(frame_right, text="Log de Execução", font=("Segoe UI", 14, "bold")).grid(row=0, column=0, sticky="w")
        self.txtRun = ScrolledText(frame_right, height=25, width=70)
        self.txtRun.configure(font=("Courier", 10))
        self.txtRun.grid(row=1, column=0, sticky="nsew", pady=10)


        # --- Tags de formatação para o Log de Execução ---
        self.txtRun.tag_configure("bold", font=("Courier", 10, "bold"))
        self.txtRun.tag_configure("info", foreground="#0d6efd")      # azul (Bootstrap 'primary')
        self.txtRun.tag_configure("success", foreground="#198754")    # verde (Bootstrap 'success')
        self.txtRun.tag_configure("warning", foreground="#ffc107")    # amarelo
        self.txtRun.tag_configure("danger", foreground="#dc3545")     # vermelho
        self.txtRun.tag_configure("muted", foreground="#6c757d")      # cinza
        self.txtRun.tag_configure("header", foreground="#0d6efd", font=("Courier", 10, "bold"))
        self.txtRun.tag_configure("mono", font=("Courier", 10))


        frame_right.rowconfigure(1, weight=1)

        btns_right = tb.Frame(frame_right)
        btns_right.grid(row=2, column=0, pady=10)

        #tb.Button(btns_right, text="Montar", bootstyle="primary", command=self.montar).grid(row=0, column=0, padx=5)
        self.btnRodar = tb.Button(btns_right, text="Previsão", bootstyle="primary", command=self.rodar, state="normal")
        self.btnRodar.grid(row=0, column=1, padx=5)
        self.btnRel  = tb.Button(btns_right, text="Relatório", bootstyle="success", command=self.relatorio, state="disabled"); self.btnRel.grid(row=0, column=2, padx=5)
        self.btnPlan = tb.Button(btns_right, text="Planilha",  bootstyle="info", command=self.planilha,  state="disabled"); self.btnPlan.grid(row=0, column=3, padx=5)
        tb.Button(btns_right, text="Ajuda", bootstyle="dark", command=self.ajuda).grid(row=0, column=4, padx=5)
        self.btnFechar = tb.Button(btns_right, text="Fechar",
                                    command=lambda: self.winfo_toplevel().destroy(),  # fecha a janela atual
                                    bootstyle="danger")           # cor vermelha para destacar
        self.btnFechar.grid(row=0, column=5, padx=5)
        self.toggle_incremental()
        self.toggle_propagar()

    def log(self, msg: str, tag=None):
        from datetime import datetime
        t = datetime.now().strftime("%H:%M:%S")         
        self.txtRun.insert(tk.END, f"[{t}] {msg}\n", tag)
        self.txtRun.see(tk.END)
        self.txtRun.update_idletasks()       
    
    def abredados1(self):
        path = BASE_PATH / self.ArqDados.get()
        if path.exists():
            open_system_file(path)
        else:
            messagebox.showerror("Erro", f"Planilha não encontrada:\n{path}")  
    def abredados2(self):
        
        path = BASE_PATH / self.ArqProp.get()
        self.log(f"Abrindo arquivo {path}")
        if path.exists():
            open_system_file(path)
        else:
            messagebox.showerror("Erro", f"Planilha não encontrada:\n{path}")    

    def abreinc(self):
        path = BASE_PATH / self.ArqInc.get()
        self.log(f"Abrindo arquivo {path}")
        if path.exists():
            open_system_file(path)
        else:
            messagebox.showerror("Erro", f"Planilha não encontrada:\n{path}") 
    def selcaminho(self):
        self._troca_reservatorio()

    def _troca_reservatorio(self):
        # Salva caminhos do reservatório anterior
        reserv_ant = self._last_reserv

        self.mem_dados[reserv_ant] = self.ArqDados.get()
        self.mem_prop[reserv_ant] = self.ArqProp.get()

        # Atualiza estado atual
        self._last_reserv = self.var_reserv.get()

        # Atualiza campos
        self._atualizar_caminhos()
        self._save_paths() 

    def _atualizar_caminhos(self):
        reserv = self.var_reserv.get()

        mapa = {
            1: "USB",
            2: "UIT",
            3: "UBE",
            4: "UPE"
        }

        sigla = mapa[reserv]

        # Dados observados
        if reserv in self.mem_dados:
            self.ArqDados.set(self.mem_dados[reserv])
        else:
            self.ArqDados.set(f"dados/{sigla}/Dados_Previsão_Diária_{sigla}.csv")

        # Montante
        if reserv in self.mem_prop:
            self.ArqProp.set(self.mem_prop[reserv])
        else:
            self.ArqProp.set(f"dados/{sigla}/Montante_{sigla}.csv")                                   

    def select_dados(self):
        sel = pick_file("Selecionar arquivo de dados", (("CSV", "*.csv"),))
        if sel:
            self.ArqDados.set(sel)
            reserv = self.var_reserv.get()
            self.mem_dados[reserv] = sel
            self._save_paths()   # <-- NOVO


    def select_incremental(self):
        sel = pick_file("Selecionar arquivo de incrementais", (("CSV", "*.csv"),))
        if sel:
            self.ArqInc.set(sel)
            self._save_paths()   # <-- NOVO

    def select_propagar(self):
        sel = pick_file("Selecionar arquivo para propagar", (("CSV", "*.csv"),))
        if sel:
            self.ArqProp.set(sel)
            reserv = self.var_reserv.get()
            self.mem_prop[reserv] = sel
            self._save_paths()   # <-- NOVO

    def toggle_incremental(self):
        modo = self.var_inc_mode.get()

        if modo == 1:  # Automática
            estado_rb = "normal"
          
            self.btnInc.configure(state="disabled")
            self.btnIncA.configure(state="disabled")
            self.ArqInc.set("relat/inc-auto.csv") #é o fortran que gera
#            if self.var_reserv.get() == 1:
#                self.ArqInc.set("dados/usb/inc_auto_usb.csv")
#            if self.var_reserv.get() == 2:
#                self.ArqInc.set("dados/uit/inc_auto_uit.csv")
#            if self.var_reserv.get() == 3:
#                self.ArqInc.set("dados/ube/inc_auto_ube.csv")
#            if self.var_reserv.get() == 4:
#                self.ArqInc.set("dados/upe/inc_auto_upe.csv")                                                  
        else:  # Manual
            estado_rb = "disabled"

            self.btnInc.configure(state="normal")
            self.btnIncA.configure(state="normal")


        # Habilita / desabilita os períodos
        for rb in (self.rb_per_total, self.rb_per_seco, self.rb_per_umido):
            rb.configure(state=estado_rb)

    def toggle_propagar(self):     

        if self.var_prev_montante.get() == 1:
            self.btnProp.state(["disabled"])
            #self.ArqProp.set("relat/propagar-auto.csv")
        else:
            self.btnProp.state(["!disabled"])

    def lercsv(self, arq, path):
        self.log(f"Lendo arquivo {BASE_PATH / path}")
        with open(BASE_PATH / arq, "w") as fout, open(BASE_PATH / path, "r") as fin:
            for l in fin:
                l = l.strip().replace(",", ".").replace(";", ",").strip(",")
                fout.write(l + "\n") 

    def diminuivarx(self):

        varx_path = BASE_PATH / "varx.txt"
        varxc_path = BASE_PATH / "varxc.txt"
        if varxc_path.exists():
            varxc_path.unlink(missing_ok=True)
        if not varx_path.exists() or varx_path.stat().st_size == 0:
            messagebox.showerror("Previsão", "Não existe calibração!")
            raise RuntimeError("Parando execução por falta de varx.txt")
        varx_path.rename(varxc_path)
        with varxc_path.open("r", encoding="latin1") as fin:
            linhas = fin.readlines()
        if varx_path.exists():
            varx_path.unlink(missing_ok=True)
        i = len(linhas)
        ii = 99 if i >= 100 else i
        with varx_path.open("w", encoding="latin1") as fout:
            for j, l in enumerate(linhas, start=1):
                if j == 1 or j >= i - ii:
                    fout.write(l)

    def montar(self):

        self.log("Montando caso.")
        self.lercsv("varx.txt", self.ArqDados.get())

        # =========================
        # Montante
        # =========================
        prever_mont = self.var_prev_montante.get()
        arq_prop = BASE_PATH / self.ArqProp.get().strip()
        if not arq_prop.is_absolute():
            arq_prop = BASE_PATH / arq_prop
        if prever_mont == 0:
            if not arq_prop.is_file():
                messagebox.showerror("Erro", "Falta indicar os dados para propagar!")
                return
            self.log(f"Arquivo de montante: {arq_prop}")
            self.lercsv("propagar.txt", arq_prop)

        # =========================
        # Incrementais
        # =========================
        modo_inc = self.var_inc_mode.get()
        arq_inc = BASE_PATH / Path(self.ArqInc.get())
        if not arq_inc.is_absolute():
            arq_inc = BASE_PATH / arq_inc

        if modo_inc == 2:  # Manual
            if not arq_inc.is_file():
                messagebox.showerror("Erro", "Falta indicar as incrementais!")
                return
            self.log(f"Arquivo de incrementais: {arq_inc}")            
            self.lercsv("inc.txt", arq_inc)

        # =========================
        # incprop.txt
        # =========================
        with open(BASE_PATH / "incprop.txt", "w") as f:

            # Incrementais
            if modo_inc == 2:
                f.write("0\n0\n")
            else:
                f.write("1\n")
                f.write(f"{self.var_inc_period.get()}\n")

            # Prever montante
            f.write("1\n" if prever_mont == 1 else "0\n")

            # Previsão incremental
            f.write("1\n" if self.var_prev_inc.get() == 1 else "0\n")

            # Previsão montante
            f.write("1\n" if self.var_prev_mont.get() == 1 else "0\n")

        # =========================
        # temp.txt
        # =========================
        with open(BASE_PATH / "temp.txt", "w") as f:
            f.write(f"{self.asc.get()}  {self.dsc.get()}")

        # =========================
        # Tabelas / Configuração
        # =========================
        reserv_map = {1: "usb", 2: "uit", 3: "ube", 4: "upe"}
        res_code = reserv_map[self.var_reserv.get()]

        tab_src  = BASE_PATH / "tabelas"    / f"tabelasqtv{res_code}.txt"
        conf_src = BASE_PATH / "configprop" / f"configprop{res_code}.txt"

        if not tab_src.exists():
            messagebox.showerror(
                "Erro",
                f"Tabelas de tempo de viagem não encontradas para {res_code}!"
            )
            return
        if not conf_src.exists():
            messagebox.showerror(
                "Erro",
                f"Arquivos de configuração não encontrados para {res_code}!"
            )
            return        

        shutil.copyfile(tab_src,  BASE_PATH / "tabelasqtv.txt")
        shutil.copyfile(conf_src, BASE_PATH / "configprop.txt")

        # =========================
        # Finalização
        # =========================
        #self.txtRun.delete("1.0", "end")
        self.txtRun.insert(tk.END, "\n")
        self.txtRun.insert(tk.END, "Arquivos montados.\n")
        self.btnRodar.state(["!disabled"])


    def rodar(self):

        # =========================
        # Dados anteriores
        # =========================
        path = BASE_PATH / self.ArqDados.get()       
        if not Path(path).is_file():
            messagebox.showerror("Erro", "Falta indicar os dados de entrada!")
            return
        self.montar()
        #self.txtRun.delete("1.0", "end")
        self.txtRun.insert (tk.END,path)
        self.txtRun.insert(tk.END, "\n")
        self.txtRun.insert(tk.END, "AGUARDE...\n")
        self.txtRun.update_idletasks()
        if not (BASE_PATH /"mostratudo.txt").is_file:
            self.diminuivarx()
        run_exe("PP.exe", self.txtRun)
        self.btnRel.state(["!disabled"])
        self.btnPlan.state(["!disabled"]) 
        self.mudanome()      

    def mudanome(self):
        
        if self.var_reserv.get()==1:
            nomeres = 'USB'
        if self.var_reserv.get()==2:
            nomeres = 'UIT'
        if self.var_reserv.get()==3:
            nomeres = 'UBE'
        if self.var_reserv.get()==4:
            nomeres = 'UPE' 
      
        opath = BASE_PATH / "relat" / "propaga.html"
        path = BASE_PATH / "relat" / f"propaga_{nomeres}.html"
        shutil.copy(opath, path)
        self.log(f"Renomeando arquivo {path}")
        opath = BASE_PATH / "plan" / "relat_propaga.csv"                    
        path = BASE_PATH / "plan" / f"relat_propaga_{nomeres}.csv"
        shutil.copy(opath, path)
        self.log(f"Renomeando arquivo {path}")        
    
    def relatorio(self):
        if self.var_reserv.get()==1:
            nomeres = 'USB'
        if self.var_reserv.get()==2:
            nomeres = 'UIT'
        if self.var_reserv.get()==3:
            nomeres = 'UBE'
        if self.var_reserv.get()==4:
            nomeres = 'UPE' 
      
        #opath = BASE_PATH / "relat" / "propaga.html"
        path = BASE_PATH / "relat" / f"propaga_{nomeres}.html"
        #shutil.copy(opath, path)

        if path.exists():
            messagebox.showinfo("Lembrete:", "Imprima ou salve o arquivo de resultados em sua pasta!")
            open_system_file(path)
        else:
            messagebox.showerror("Erro", f"Relatório não encontrado:\n{path}")

    def planilha(self):
        
        if self.var_reserv.get()==1:
            nomeres = 'USB'
        if self.var_reserv.get()==2:
            nomeres = 'UIT'
        if self.var_reserv.get()==3:
            nomeres = 'UBE'
        if self.var_reserv.get()==4:
            nomeres = 'UPE' 

        #opath = BASE_PATH / "plan" / "relat_propaga.csv"                    
        path = BASE_PATH / "plan" / f"relat_propaga_{nomeres}.csv"
        #shutil.copy(opath, path)

        if path.exists():
            open_system_file(path)
        else:
            messagebox.showerror("Erro", f"Planilha não encontrada:\n{path}")

    def ajuda(self):
        path = BASE_PATH / "manuais" / "manual-previa-PP.html"
        if path.exists():
            open_system_file(path)
        else:
            messagebox.showerror("Erro", f"Ajuda não encontrada:\n{path}")

import json
from pathlib import Path

CONFIG_FILE = Path("config/app_config.json")


def load_theme(default="lumen"):
    """
    Carrega o tema salvo no arquivo de configuração.
    Retorna 'default' se o arquivo não existir ou ocorrer erro.
    """
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data.get("theme", default)
        except Exception:
            pass
    return default


def save_theme(theme):
    """
    Salva o tema escolhido pelo usuário no arquivo de configuração.
    """
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump({"theme": theme}, f, indent=4)

def load_file_paths():
    """Carrega o dicionário de caminhos salvos do arquivo de configuração."""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data.get("file_paths", {})
        except Exception:
            pass
    return {}

def save_file_paths(file_paths):
    """Salva o dicionário de caminhos no arquivo de configuração."""
    data = {}
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = {}
    data["file_paths"] = file_paths
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

# ======================================================================
# Aba 5: Consolidação de resultados (USB, UBE, UIT, UPE)
# ======================================================================
class ConsolidacaoPage(tb.Frame):

    reservatorios = ["USB","UBE","UIT","UPE","IUSB","UTM"]
    colunas_indices = [1,2,3,4,5]

    def __init__(self, master):

        super().__init__(master)

        ensure_dirs()

        self._build_ui()


    # --------------------------------------------------
    # INTERFACE
    # --------------------------------------------------

    def _build_ui(self):

        frame = tb.Frame(self, padding=10)
        frame.grid(row=0, column=0, sticky="nsew")

        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        frame.columnconfigure(1, weight=1)
        frame.rowconfigure(1, weight=1)

        # --------------------------------------------------
        # Título
        # --------------------------------------------------

        titulo = tb.Label(
            frame,
            text="Log de execução",
            font=("Segoe UI", 20, "bold")
        )
        titulo.grid(row=0, column=0, columnspan=2, pady=(0,20))

        # --------------------------------------------------
        # Frame ESQUERDO (botões)
        # --------------------------------------------------

        frame_botoes = tb.Frame(frame)
        frame_botoes.grid(row=1, column=0, sticky="ns", padx=(0,15))

        frame_botoes.columnconfigure(0, weight=1)

        btn_diaria = tb.Button(
            frame_botoes,
            text="Executar Consolidação DIÁRIA",
            command=self.consolidar_diaria,
            bootstyle="success",
            width=28
        )
        btn_diaria.grid(row=0, column=0, padx=15, pady=5, sticky="ew")

        btn_mensal = tb.Button(
            frame_botoes,
            text="Executar Consolidação MENSAL",
            command=self.consolidar_mensal,
            bootstyle="primary",
            width=28
        )
        btn_mensal.grid(row=1, column=0, padx=15, pady=5, sticky="ew")

        btn_importar = tb.Button(
            frame_botoes,
            text="Importar TXT do ISDARH",
            command=self.selecionar_e_validar_txt,
            bootstyle="info",
            width=28
        )
        btn_importar.grid(row=2, column=0, padx=15, pady=(20,5), sticky="ew")

        btn_fechar = tb.Button(
            frame_botoes,
            text="Fechar",
            command=lambda: self.winfo_toplevel().destroy(),
            bootstyle="danger",
            width=28
        )
        btn_fechar.grid(row=3, column=0, padx=15, pady=(30,5), sticky="ew")

        # --------------------------------------------------
        # Frame DIREITO (log)
        # --------------------------------------------------

        frame_log = tb.Frame(frame)
        frame_log.grid(row=1, column=1, sticky="nsew")

        frame_log.columnconfigure(0, weight=1)
        frame_log.rowconfigure(0, weight=1)

        self.log_box = ScrolledText(frame_log, height=25)
        self.log_box.grid(row=0, column=0, sticky="nsew")

    def selecionar_e_validar_txt(self):
        from tkinter import filedialog

        caminho_txt = filedialog.askopenfilename(
            title="Selecione o arquivo TXT",
            filetypes=[("Arquivos TXT", "*.txt")]
        )

        if not caminho_txt:
            self.log("Nenhum arquivo selecionado.", "warning")
            return

        self.validar_e_converter_txt(caminho_txt)

    def validar_e_converter_txt(self, caminho_txt):

        import os
        import pandas as pd
        from datetime import datetime, timedelta

        self.log(f"\n🔎 Validando arquivo: {caminho_txt}")

        erros = []
        dados_validos = []
        datas_lidas = []

        try:
            with open(caminho_txt, "r", encoding="latin1") as f:
                linhas = f.readlines()

            if not linhas:
                self.log("  Arquivo vazio.", "warning")
                return False

            cabecalho = linhas[0].strip().split()
            n_colunas = len(cabecalho)

            for i, linha in enumerate(linhas[1:], start=2):

                # 🔹 Ignora linha completamente vazia
                if not linha.strip():
                    continue

                partes = linha.strip().split()

                if len(partes) != n_colunas:
                    erros.append(
                        f"Linha {i}: número incorreto de colunas "
                        f"(esperado {n_colunas}, encontrado {len(partes)})"
                    )
                    continue

                try:
                    dia = int(partes[0])
                    mes = int(partes[1])
                    ano = int(partes[2])
                    data = datetime(ano, mes, dia)
                except ValueError:
                    erros.append(
                        f"Linha {i}: data inválida "
                        f"({partes[0]}/{partes[1]}/{partes[2]})"
                    )
                    continue

                if data in datas_lidas:
                    erros.append(
                        f"Linha {i}: data duplicada ({data.strftime('%d/%m/%Y')})"
                    )

                datas_lidas.append(data)

                linha_convertida = partes[:3]

                for j, valor in enumerate(partes[3:], start=4):
                    try:
                        float(valor.replace(",", "."))
                        linha_convertida.append(valor)
                    except ValueError:
                        erros.append(
                            f"Linha {i}: valor inválido na coluna {j} "
                            f"(Data: {data.strftime('%d/%m/%Y')})"
                        )

                dados_validos.append(linha_convertida)

            # 🔹 Verifica ordem e continuidade das datas
            for i in range(1, len(datas_lidas)):

                if datas_lidas[i] < datas_lidas[i - 1]:
                    erros.append(
                        f"Data fora de ordem: "
                        f"{datas_lidas[i].strftime('%d/%m/%Y')} "
                        f"aparece após "
                        f"{datas_lidas[i-1].strftime('%d/%m/%Y')}"
                    )

                # 🔹 EXIGE continuidade diária
                if datas_lidas[i] != datas_lidas[i - 1] + timedelta(days=1):
                    erros.append(
                        f"Data descontínua: "
                        f"{datas_lidas[i-1].strftime('%d/%m/%Y')} "
                        f"não é seguida por "
                        f"{datas_lidas[i].strftime('%d/%m/%Y')}"
                    )

            if erros:
                caminho_relatorio = os.path.splitext(caminho_txt)[0] + "_relatorio_erros.txt"

                with open(caminho_relatorio, "w", encoding="latin1") as r:
                    r.write("RELATÓRIO DE ERROS\n")
                    r.write("===================\n\n")
                    for erro in erros:
                        r.write(erro + "\n")

                self.log("\n==============================", "danger")
                self.log("RELATÓRIO DE ERROS ENCONTRADOS", "danger")
                self.log("==============================\n", "danger")

                for erro in erros:
                    self.log(f"• {erro}", "danger")

                self.log("\n--------------------------------", "warning")
                self.log(f"⚠ Total de erros: {len(erros)}", "warning")
                self.log("❌ Conversão cancelada.", "danger")
                self.log(f"Relatório salvo em: {caminho_relatorio}\n", "warning")

                return False

            df = pd.DataFrame(dados_validos, columns=cabecalho)
            caminho_csv = os.path.splitext(caminho_txt)[0] + ".csv"

            df.to_csv(
                caminho_csv,
                sep=";",
                decimal=",",
                index=False,
                encoding="latin1"
            )

            self.log(f"  ✅ Arquivo validado e convertido: {caminho_csv}", "success")
            return True

        except Exception as e:
            self.log(f"  ❌ Erro durante validação: {e}", "danger")
            return False

    def log(self,msg, tipo=None):


        from datetime import datetime

        t = datetime.now().strftime("%H:%M:%S")

        self.log_box.insert(tk.END,f"[{t}] {msg}\n")
        self.log_box.see(tk.END)


    # --------------------------------------------------
    # LEITURA PREVIA P
    # --------------------------------------------------

    def _ler_previap(self, arquivo, idx):

        valores = []
        titulo = f"P{idx}"

        try:

            with open(arquivo, encoding="latin1") as f:
                linhas = f.readlines()

            if len(linhas) > 10:

                cab = linhas[10].split(";")

                if len(cab) > idx:
                    titulo = cab[idx].strip()

            for linha in linhas[11:]:

                partes = linha.strip().split(";")

                if len(partes) <= idx:
                    continue

                try:
                    v = float(partes[idx].replace(",", "."))
                    valores.append(v)
                except:
                    break

        except Exception as e:

            self.log(f"Erro lendo {arquivo}: {e}")

        return valores, titulo


    # --------------------------------------------------
    # LEITURA PREVIA PP
    # --------------------------------------------------

    def _ler_previapp(self,arquivo):

        import re

        valores=[]

        try:

            with open(arquivo,encoding="latin1") as f:
                linhas=f.readlines()

            inicio=None

            for i,l in enumerate(linhas):

                if re.match(r'^T\+\s*1$',l.split(";")[0].strip()):
                    inicio=i
                    break

            if inicio is None:
                return []

            for linha in linhas[inicio:]:

                partes=linha.split(";")

                if len(partes)<19:
                    continue

                try:

                    v=float(partes[18].replace(",","."))
                    valores.append(v)

                except:
                    break

        except Exception as e:

            self.log(f"Erro lendo PP {arquivo}: {e}")

        return valores


    # --------------------------------------------------
    # GRÁFICO
    # --------------------------------------------------

    def _grafico_reservatorio(self,writer,nome_aba,df):

        from openpyxl.chart import LineChart, Reference
        from openpyxl.chart.axis import ChartLines
        from openpyxl.chart.shapes import GraphicalProperties
        from openpyxl.drawing.line import LineProperties
        from openpyxl.chart.layout import Layout, ManualLayout

        ws = writer.book[nome_aba]


        chart = LineChart()
        chart.title = f"Comparação de Previsões - {nome_aba}"
     
        chart.y_axis.title = "Vazão"
        chart.x_axis.title = "Horizonte"

        # garantir que os eixos apareçam
        chart.x_axis.delete = False
        chart.y_axis.delete = False

        # mostrar rótulos dos eixos
        chart.x_axis.tickLblPos = "nextTo"
        chart.y_axis.tickLblPos = "nextTo"

        # marcas de escala
        chart.x_axis.majorTickMark = "in"
        chart.y_axis.majorTickMark = "in"

        # linhas de grade horizontais
        chart.y_axis.majorGridlines = ChartLines()
        # linhas de grade verticais
        chart.x_axis.majorGridlines = ChartLines()
        #legendas
        chart.legend.graphicalProperties = GraphicalProperties(solidFill="FFFFFF",ln=LineProperties(solidFill="000000"))
        

        data = Reference(
            ws,
            min_col=2,
            max_col=len(df.columns),
            min_row=1,
            max_row=len(df)+1
        )

        cats = Reference(
            ws,
            min_col=1,
            min_row=2,
            max_row=len(df)+1
        )

        chart.add_data(data, titles_from_data=True)
        chart.set_categories(cats)

        ws.add_chart(chart,"J2")

    # --------------------------------------------------
    # CONSOLIDAÇÃO DIÁRIA
    # --------------------------------------------------

    def consolidar_diaria(self):

        import pandas as pd
        import numpy as np

        self.log("\n"+"="*60)
        self.log("Nova consolidação diária iniciada")


        dados = {}

        for res in self.reservatorios:

            self.log(f"Lendo reservatório {res}")
            dados[res] = {}

            arq_p = BASE_PATH/"plan"/f"relatprev_{res}_Diária.csv"

            if not arq_p.exists():
                self.log(f"Arquivo não encontrado: {arq_p.name}")
            
            if arq_p.exists():

                for idx in self.colunas_indices:

                    vals, titulo = self._ler_previap(arq_p, idx)
                    dados[res][titulo] = vals

            arq_pp = BASE_PATH/"plan"/f"relat_propaga_{res}.csv"

            if not arq_pp.exists():

                self.log(f"Arquivo PP não encontrado: {arq_pp.name}")

            if arq_pp.exists():

                dados[res]["PP"] = self._ler_previapp(arq_pp)

            else:

                dados[res]["PP"] = []


        self._gerar_excel(dados,"consolidacao_modelos_diaria.xlsx")

        self.log("Consolidação diária finalizada.")


    # --------------------------------------------------
    # CONSOLIDAÇÃO MENSAL
    # --------------------------------------------------

    def consolidar_mensal(self):

        import pandas as pd

        self.log("\n"+"="*60)
        self.log("Nova consolidação diária iniciada")

        dados = {}

        for res in self.reservatorios:

            dados[res] = {}

            arq_p = BASE_PATH/"plan"/f"relatprev_{res}_Mensal.csv"

            if not arq_p.exists():

                self.log(f"Arquivo P não encontrado: {arq_p.name}")            

            if arq_p.exists():

                for idx in self.colunas_indices:

                    vals, titulo = self._ler_previap(arq_p, idx)
                    dados[res][titulo] = vals


        self._gerar_excel(dados,"consolidacao_modelos_mensal.xlsx")

        self.log("Consolidação mensal finalizada.")

    # --------------------------------------------------
    # GERAÇÃO EXCEL
    # --------------------------------------------------

    def _gerar_excel(self,dados,nome_arquivo):

        import pandas as pd
        import numpy as np
        import os

        caminho = BASE_PATH/"plan"/nome_arquivo
        
        self.log(f"\nGerando arquivo Excel: {nome_arquivo}")
        self.log(f"Caminho: {caminho}")

        try:

            with pd.ExcelWriter(caminho, engine="openpyxl") as writer:

                # ======================================================
                # ABAS POR RESERVATÓRIO
                # ======================================================

                for res in self.reservatorios:
                    
                    self.log(f"Criando aba {res}")
                    previsoes = dados.get(res,{})

                    max_len = max([len(v) for v in previsoes.values()] + [0])

                    tabela = {
                        "Horizonte":[f"t+{i+1}" for i in range(max_len)]
                    }

                    for nome,serie in previsoes.items():

                        serie=list(serie)

                        tabela[nome]=serie+[np.nan]*(max_len-len(serie))

                    df=pd.DataFrame(tabela)

                    df.to_excel(writer,sheet_name=res,index=False)

                    if len(df.columns)>1:

                        self._grafico_reservatorio(writer,res,df)


                # ======================================================
                # RESUMO GERAL
                # ======================================================

                max_len_global = 0
                self.log("Gerando aba RESUMO_GERAL")

                for res in self.reservatorios:

                    for serie in dados.get(res,{}).values():

                        max_len_global=max(max_len_global,len(serie))


                tabela={"Horizonte":[f"t+{i+1}" for i in range(max_len_global)]}

                for res in self.reservatorios:

                    previsoes=dados.get(res,{})

                    for nome,serie in previsoes.items():

                        serie=list(serie)

                        col=f"{res}_{nome}"

                        tabela[col]=serie+[np.nan]*(max_len_global-len(serie))


                df_resumo=pd.DataFrame(tabela)

                df_resumo.to_excel(writer,"RESUMO_GERAL",index=False)

        except PermissionError:

            self.log("❌ ERRO: Não foi possível salvar o arquivo Excel.", "danger")
            self.log("O arquivo parece estar aberto no Excel.", "warning")
            self.log("Feche a planilha e tente novamente.", "warning")
            self.log(f"Arquivo: {caminho}", "muted")

            return

        except Exception as e:

            self.log(f"❌ Erro inesperado ao gerar Excel: {e}", "danger")
            return


        self.log("Arquivo Excel gerado com sucesso.", "success")
        self.log("Abrindo planilha gerada")
        open_system_file(caminho)
        
# ======================================================================
# Janela principal com Notebook e seletor de tema único
# ======================================================================
def main():
    # ==========================================================
    # Carrega tema salvo (ou lumen como padrão)
    # ==========================================================
    saved_theme = load_theme("lumen")

    root = tb.Window(themename=saved_theme)
    root.title(APP_NAME)

    # ==========================================================
    # Janela proporcional ao monitor
    # ==========================================================
    screen_w = root.winfo_screenwidth()
    screen_h = root.winfo_screenheight()

    w = int(screen_w * 0.9)
    h = int(screen_h * 0.9)
    x = int((screen_w - w) / 2)
    y = int((screen_h - h) / 2)

    root.geometry(f"{w}x{h}+{x}+{y}")

    # Tenta maximizar (Windows / Linux)
    try:
        root.state("zoomed")
    except:
        pass

    # ==========================================================
    # Ícone e diretórios
    # ==========================================================
    safe_set_icon(root, "config/previa.ico")
    ensure_dirs()
    root.iconbitmap(default='')

    # ==========================================================
    # Notebook principal
    # ==========================================================
    notebook = tb.Notebook(root, bootstyle="primary")
    notebook.pack(fill="both", expand=True, padx=10, pady=2)


    tab1 = PrevIACPage(notebook)
    tab2 = PrevIAPPage(notebook)
    tab3 = PrevIAPPPage(notebook)
    tab4 = PrevSazPage(notebook)
    tab5 = ConsolidacaoPage(notebook)   # <-- NOVA ABA    


    notebook.add(tab2, text="       PrevIA-P        ")
    notebook.add(tab3, text="       PrevIA-PP       ")
    notebook.add(tab1, text="       PrevIA-C        ")
    notebook.add(tab4, text="       Prev-Saz        ")
    notebook.add(tab5, text="Consolidação e Importação")   # <-- ABA ADICIONADA

    # ==========================================================
    # Seletor de tema global (persistente)
    # ==========================================================
    theme_frame = tb.Frame(root)
    theme_frame.pack(pady=2)

    tb.Label(theme_frame, text="Tema:").pack(side="left", padx=5)

    theme_combo = tb.Combobox(
        theme_frame,
        values=root.style.theme_names(),
        width=18,
        state="readonly"
    )
    theme_combo.set(saved_theme)
    theme_combo.pack(side="left", padx=5)

    def on_theme_change(event):
        theme = theme_combo.get()
        root.style.theme_use(theme)
        save_theme(theme)

    theme_combo.bind("<<ComboboxSelected>>", on_theme_change)

    # ==========================================================
    # Loop principal
    # ==========================================================
    root.mainloop()

if __name__ == "__main__":
    main()
