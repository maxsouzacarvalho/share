!------------------------------------------------------------------------------------
!  ABERTURA DO ARQUIVO DE LICENÇA
!------------------------------------------------------------------------------------


      SUBROUTINE LE_LICENCA(EMPRESA,FTIPO)
      
      INTEGER    I,J,K,DI,DF,MI,MF,AI,AF,FLAG,FLAG_OK,K2,DF2,MF2,AF2
      INTEGER    FTIPO
      INTEGER    YEAR,MONTH,DAY  
      CHARACTER*149 EMPRESA
      CHARACTER*1   AUX(149)
      CHARACTER*10  TIPO
      CHARACTER*4   MODELO
      CHARACTER*26    AUX2
      CHARACTER*1   AUX3(3)

      OPEN (11,FILE='..\CCHEIAS.LIC',FORM='UNFORMATTED',
     *      ACCESS='DIRECT',RECL=149,STATUS='OLD',ERR=10)     
      
      OPEN (12,FILE='..\AUXILIAR',FORM='FORMATTED',
     *      STATUS='UNKNOWN')
     
      READ(11,REC=1)AUX2
      WRITE(12,17)AUX2
      
      READ(11,REC=2)AUX2
      WRITE(12,17)AUX2
      
      READ(11,REC=3)AUX2
      WRITE(12,17)AUX2
      
      READ(11,REC=4)(AUX(I),I=1,149)
      READ(11,REC=5)DF2,MF2,AF2
c      READ(11,REC=6)FTIPO
      
      CLOSE(12)
      
      OPEN (12,FILE='..\AUXILIAR',FORM='FORMATTED',
     *      STATUS='UNKNOWN')
     
      READ(12,13)AUX3(1),AUX3(2),AUX3(3)     
      READ(12,14)K2,AI,MI,DI
      READ(12,18)DF,MF,AF,FLAG      

      FTIPO = FLAG

13    FORMAT(5X,A1,7X,A1,11X,A1)
14    FORMAT(I3,2X,I4,3X,I2,10X,I2)
18    FORMAT(10X,I2,4X,I2,5X,I2,I1)
15    FORMAT(149A1)
16    FORMAT(I2,I2,I4)
17    FORMAT(A26)

      CLOSE(UNIT=12, STATUS='DELETE')     
      
C ---- VERIFICA�AO SE ARQUIVO SINV.LIC ESTA CORRETO

      FLAG_OK=1  
      
      IF(AUX(1).NE.AUX3(1)) FLAG_OK=0  
      IF(AUX(4).NE.AUX3(2)) FLAG_OK=0
      IF(AUX(100).NE.AUX3(3)) FLAG_OK=0
      
      K=0
      DO I=1,149
        IF(AUX(I).EQ.' ') K=K+1
      END DO       

      WRITE(EMPRESA,15)(AUX(I),I=1,149)

      IF(K2.NE.K) FLAG_OK=0
      
      MI=MI-60
      MF=MF-40
      AF=AF+2015
      
      IF(MF.NE.MF2) FLAG_OK=0
      IF(AF.NE.AF2) FLAG_OK=0
      
      IF(FLAG_OK.EQ.0) THEN
        WRITE(*,19)
        
C ---------- INICIO RUNSTATE

      OPEN (99,FILE='..\SISTEM\RUNSTATE.DAT',FORM='FORMATTED',
     *      ACCESS='SEQUENTIAL', STATUS='UNKNOWN')
      WRITE(99,99)
      CLOSE(99)   

C ---------- FIM RUNSTATE                         
        
        STOP
      END IF
      
19    FORMAT(//,2X,'ERRO:',//,
     * 2X,'ARQUIVO DE LICENCA CORROMPIDO',//,
     * 2X,'ENTRAR EM CONTATO COM O CEPEL PELO E-MAIL:',//,
     * 2X,'CHEIAS@CEPEL.BR',//) 
      
C ---- VERIFICACAO SE VERSAO EXPIROU OU NAO

      CALL GETDAT(YEAR,MONTH,DAY)
      
      IF(YEAR.GT.AF) FLAG_OK=0
      IF((YEAR.EQ.AF).AND.(MONTH.GT.MF)) FLAG_OK=0
      
      IF(FLAG_OK.EQ.0) THEN
        WRITE(*,20)MF,AF
        
C ---------- INICIO RUNSTATE

      OPEN (99,FILE='..\SISTEM\RUNSTATE.DAT',FORM='FORMATTED',
     *      ACCESS='SEQUENTIAL', STATUS='UNKNOWN')
      WRITE(99,99)
      CLOSE(99)   

C ---------- FIM RUNSTATE        
        
        STOP
      END IF
      
20    FORMAT(//,2X,'ERRO:',//,
     * 2X,'LICENCA EXPIRADA EM ',I2,'/',I4,//,
     * 2X,'ENTRAR EM CONTATO COM O CEPEL PARA RENOVACAO',
     * ' DA LICENCA',//,
     * 2X,'E-MAIL DE CONTATO: DEA_ACADEMICO@CEPEL.BR',//)   
     
99    FORMAT(4X,'2000')   
      RETURN
10    WRITE(*,'(//,2X,''FALTA O ARQUIVO DE LICENCA: PREVICHESF.LIC'')')
      STOP

      END           
