﻿        PROGRAM MAIN
        include 'paramrede.dim'
        dimension ysave(nmd),yp(nmd),graf1(nmd,nmp)
        dimension graf2(nmd,nmp),d95(nmp)
        integer*2 iprev,n1,d2,nsim,icam,HORA,MINUTO,SEG,DECSEG
        integer*2 iprint,d1,nn,ip,iaux,n3,n4,ANO,MES,DIA,iopt
        integer*4 ngraf
        integer ftipo,imix
        character*2 prev
        character*30 arq,linha,arq2
        real yy,yk
        character*2 hh,mm,dd,ms
        character*4 aa
        character*1 p,tip
        CHARACTER*149 EMPRESA
        CHARACTER*80 titcaso,titteste
        character*12 filename
        
        CALL GETTIM(HORA,MINUTO,SEG,DECSEG)
        CALL GETDAT(ANO,MES,DIA)
        
        write(hh,'(i2)')hora
        write(mm,'(i2)')minuto
        write(dd,'(i2)')dia
        write(ms,'(i2)')mes
        write(aa,'(i4)')ano

        call LE_LICENCA(empresa,ftipo)
        close(11)
        close(12)
        open (unit=9,file='entrada.txt',status='old',err=9009)
        
        icrit = 1 !seta o padrão de critério como mínimos quadrados.
        
        iread9=1
        read(9,'(a15)',err=2091)arq 
        iread9=iread9+1 
        read(9,*,err=2009)d2 
        iread9=iread9+1      
        read(9,*,err=2009)icam
        iread9=iread9+1
        read(9,*,err=2009)iopt
        iread9=iread9+1
        read(9,'(a1)',err=2009)p  
        iread9=iread9+1 
        read(9,*,err=2009)tol
        iread9=iread9+1
        read(9,*,err=2009)ntrei
        iread9=iread9+1
        read(9,*,err=2009)ngraf
        if(ngraf.gt.nmg)ngraf=nmg
        iread9=iread9+1
        read(9,*,err=2009)imix
        iread9=iread9+1
        read(9,'(a80)',err=2009)titteste
        iread9=iread9+1
        read(9,*,err=2009)inorm
        iread9=iread9+1
        read(9,*,err=2009)usaprev   
        iread9=iread9+1
        read(9,*,end=2009)nkfold   
        iread9=iread9+1        
        
       if(iopt.eq.2)then
          tip='t'
        else
          tip='c'
        end if        
        
        close(9)
               
        open (unit=44,file='relat\defasagem'//p//tip//'.txt')
        open (unit=12,file='relat\calibra'//p//tip//'.html')
        
        write(44,*)'Aqui estao impressos os R^2 do teste de defasagem.'
        write(44,*)'O maior valor indica a possivel defasagem de pico:'
        write(44,*)
        write(44,*)'GRUPO CALIBRACAO'
      
        OPEN (unit=7,file='confx.txt')
        
        open (unit=10,file='relat/rodada.txt')
        if(iopt.eq.1)open (unit=15, file='config\pares.txt') !para nao sobrescrever a calibração
        
        if(iopt.eq.1)write(15,*)'**************************'
        if(iopt.eq.1)write(15,*)'Numero dos dados nos pares'
        if(iopt.eq.1)write(15,*)'**************************'
        

        write(12,*)'<html><head>'
        write(12,*)'<link rel="stylesheet" type="text/css" ',
     *   'href="..\config\classec.css" media="screen" />'
        write(12,*)'<script src="../config/grafico.js"></script>'
        write(12,*)'</head>'
        write(12,*)'<body>'
        write(12,*)'<br><hr>'
        write(12,*)'<h1>PrevIA-C</H1>'
        write(12,*)'<h3>Desenvolvido pelo Centro de Pesquisas de Energia 
     *   El&eacute;trica - CEPEL</H3>'
        write(12,*)'<hr><font size=2>Data: '
        write(12,*)dia,'/',mes,'/',ano, '<br>Hora:'
        write(12,'(2(i2,a1),i2,a4)')hora,':',minuto,':',seg,'<br>'
        
                       
       
c        write(6,'(/,4x,''Horizontes de previsao:'',i5)')d2
c        write(6,*)
        
        iread7=1
        read(7,'(a80)',err=100)titcaso
        iread7=2
        read(7,*,err=100)nn,nm
        
        if(nm.lt.d2)d2=nm  !se colocar pra fazer mais previsoes do que esta no arquivo de configuracao
        
        
        open (unit=2, file=arq, status='old',err=9002)
        iread2=1
        read(2,*,err=2002)(sigla(isig),isig=1,nn+3)  !  pula o titulo 
        iread2=iread2+1
        backspace(2)        
        
        write(*,*)
               
        do idia = 1, d2 
            
         read(2,*,err=2002)
         iread2=iread2+1 
                                 
         d1 = idia        
         aux = 0       
         if(id2.eq.d2)then
           do i = 1, id2
             read(7,*,err=100)
           end do
         end if
        
c        read(2,*)
        write(*,'(a24,i4)')'    Montando horizonte: ',d1
        call postos (n1,d1,nn,d2,icam,iprint,
     *  nnt,n3,iprev,ip,sigla,iopt)
                                               
         
        end do
        if(iopt.eq.1)write(15,*)'**************************'
        if(iopt.eq.1)write(15,*)'Pares que entraram na rede'
        if(iopt.eq.1)write(15,*)'**************************'
        write(*,*)
         close(2)
         close(7)
c       stop        
        call chamasorede(d2,sigla,titcaso,iopt,p,ngraf,imix,
     *  titteste,icam)
        
        write(6,*)'    Fim'
        write(10,*)'Fim'
        close(10)
        
        stop

100    continue
        write(12,*)'<h1>Erro no arquivo de configura&ccedil;&atilde;o
     *  </h1>'
        write(*,*)'Erro no arquivo de configuracao. Linha: ',iread7
        stop 

 9009   write(*,*)'Erro abrindo arquivo entrada.txt. Use a interface.' 
        stop
 2009   write(*,*)'Erro lendo arquivo entrada.txt. Linha: ',iread9
        write(*,*)'Use a interface.'
        stop
 9091   write(*,*)'Erro abrindo arquivo entrada.txt. Use a interface.' 
        write(12,*)'<h3>Erro abrindo arquivo entrada.txt.<br>
     *  Use a interface.</h3>'
        stop
 2091   write(*,*)'Erro lendo arquivo ',filename, '. Linha: ',iread91
        write(12,*)'<h3>Erro lendo arquivo ',filename, ' . Linha: ',
     *  iread91,'</h3>'
        stop
 9002   write(*,*)'Erro abrindo arquivo ',arq
        write(*,*)'Use a interface.' 
        write(12,*)'<h3>Erro abrindo arquivo entrada.txt.<br>
     *  Use a interface.</h3>'
        stop
 2002   write(*,*)'Erro lendo arquivo ',arq, '. Linha: ',iread2
        write(12,*)'<h3>Erro lendo arquivo ',arq, ' . Linha: ',
     *  iread2,'</h3>'
        stop        


        end
        
      SUBROUTINE SUBVIRG(NUMERO_REAL)
      CHARACTER*20 NUMERO_REAL
      CHARACTER*20 NUMERO_SUBSTITUIDO
      INTEGER*4 I, N
      
      N = LEN(NUMERO_REAL)
      
      DO 10 I = 1, N
         IF(NUMERO_REAL(I:I).EQ.'.') THEN
            NUMERO_SUBSTITUIDO(I:I) = ','
         ELSE
            NUMERO_SUBSTITUIDO(I:I) = NUMERO_REAL(I:I)
         END IF
 10   CONTINUE
 
      NUMERO_REAL = NUMERO_SUBSTITUIDO      
     
      RETURN
      END 
 
      SUBROUTINE lag(Observed, Predicted, n, 
     * LagMaisProvavel, CorrelacaoMax)
  
      INTEGER, INTENT(IN) :: n            ! N mero de observa  es
      INTEGER  MaxLag       ! M ximo lag a ser considerado
      REAL Observed(n)     ! Valores observados
      REAL Predicted(n)    ! Valores previstos
      INTEGER LagMaisProvavel ! Lag mais prov vel
      REAL CorrelacaoMax  ! Maior valor de correla
      REAL MediaObs, MediaPred,x(n),y(n)
  
      INTEGER i, j, k
      REAL  Correlacao
  
      CorrelacaoMax = -1.0  ! Inicializa a maior correla  o como um valor negativo
      MaxLag = 0
  
      DO k = 0, MaxLag
      Correlacao = 0.0  ! Inicializa a correla  o para o lag atual
      
    
      DO i = 1, n - k
          
          x(i)=observed(i)
          y(i)=Predicted(i+k)
c         Correlacao = Correlacao + Observed(i) * Predicted(i + k)          
          
      END DO
      
      
      MediaObs = SUM(x)/ REAL(n-k)
      MediaPred = SUM(y)/ REAL(n-k)
      
      CovXY = SUM((x - MediaObs) * 
     * (y - MediaPred)) / REAL(N-k)
      
      VarX = SUM((X - MediaObs)**2) / REAL(N-k)
      VarY = SUM((Y - MediaPred)**2) / REAL(N-k)      
         
      Correlacao = CovXY / SQRT(VarX * VarY)
    
    ! Normaliza a correla  o
c      Correlacao = Correlacao / REAL(n)
      
      write(44,*)'Lag ',k,':', correlacao
    
      IF (Correlacao.gt.CorrelacaoMax) THEN
          CorrelacaoMax = Correlacao  !(menos 1 pra ficar do menor pro maior)
          LagMaisProvavel = k
      END IF
      END DO
      
      CorrelacaoMax = CorrelacaoMax**2
      CorrelacaoMax = (1-CorrelacaoMax)/real(n-lagmaisprovavel)
  
      END
      SUBROUTINE loess_smoothing(y, n, smooth_y)
      include 'paramrede.dim'
      INTEGER*4 n
      Dimension x(n), y(n),smooth_y(n)
      INTEGER i, j
      REAL dist, weight, sum_weight, sum_weighted_y,span            
      span = 3      
      DO i = 1, n
         sum_weighted_y = 0.0
         sum_weight = 0.0
         DO j = 1, n
c            dist = ABS(x(j) - x(i))
            dist = ABS(j - i)!x(j) e x(i) vao ser exatamente j e i.
            IF (dist .LT. span) THEN
               weight = (1.0 - (dist/span)**3)**3 ! Tri-cube weighting function
               sum_weighted_y = sum_weighted_y + weight * y(j)
               sum_weight = sum_weight + weight
            END IF
         END DO
         smooth_y(i) = sum_weighted_y / sum_weight
      END DO
         
         
      END 
        
         Subroutine trocadado (x, y, n, m)
         include 'paramrede.dim' 
         dimension x(nmd,mmax),y(nmd)
         dimension xa(nmd,mmax),ya(nmd)
         integer*4 n
         integer*2 m
                  
         do i = 1, n          
            ya(i) = y(i)                              
            do j = 1, m
                xa(i,j)=x(i,j)
            end do                
         end do
         
         do i=1,n
         
          k = i
          ir = mod(i,2)
          
          if (ir.eq.0)k=n-(i-1)
          
          y(i)=ya(k)
          
          
              do j = 1, m
                  x(i,j)=xa(k,j)
              end do
                  
          end do
         end     
         
         
        subroutine stat1(n,y,xx,st)
        include 'paramrede.dim'
        dimension y(n),x(n),xx(n)
        real yb,xb,xm2,ym2,xym,r,rst
        integer st,j
        integer*2 maxlag
        
        st=0
        rst = 0
               
        do j = 0, nmp          
            
        xb = 0.
        yb = 0.
        xm2 = 0.
        ym2 = 0.
        xym = 0.
            
c        write (55+j,*)n-j
                
        do i = 1, n-j
            x(i)=xx(i+j)
c            write(55+j,*)y(i),x(i)
        end do
        
c        close(55+j)
        
        do i = 1, n - j
            xb = xb+ x(i)
            yb = yb+ y(i)
        end do
        
        xb = xb/(n-j)
        yb = yb/(n-j)
        
        do i = 1,n - j        
           xym = xym + (x(i)-xb)*(y(i)-yb)
           xm2 = xm2+(x(i)-xb)**2
           ym2 = ym2+(y(i)-yb)**2                      
        end do
          
        r = (xym/sqrt(xm2*ym2))
        
        write(44,'(''Defasagem '',i4, '', R^2: '',f7.4)')j,r
        
        if(r.gt.rst)st=j
        if(r.gt.rst)rst = r
        
        end do
          
        return
      end 

      subroutine Estatisticas(n,ysave,y,somaa,eabsm,L95,r2,pic)
      include 'paramrede.dim'
      dimension y(n), ysave(n), e95(n)
      real media, L95, soma, eabsm, somaa,r2,nash,erm,max_corr
      integer*4 n
      integer pic
   
         call desvpad (n, ysave, y, eabsm, L95,emq)
        
    !para ver a defasagem
         !call stat1(n,ysave,y,pic)
         CALL CALCULA_LAG(ysave, y, N, pic, NMP, MAX_CORR)
         call PearsonCorrelation(n,ysave,y,r2)
         Call NashSutcliffe(ysave, y, n, nash)
         Call ErroPercentual(ysave, y, n, erm)
         write(11,27)n,n,nash,eabsm,r2,ibeta,ymax,ymin,pic,erm
27       format(I10,1X,I10,1X,F12.5,1X,F12.5,1X,F10.7,1x,I4,1X,F10.3,1X,
     *   F10.3,1X,I4,1x,F10.3)
               
      end 
      
      subroutine PearsonCorrelation(n,x, y, correlation)
      include 'paramrede.dim'
      integer n
      integer  i
      dimension x(n), y(n)
      real    correlation
      real  sum_x, sum_y, sum_xy, sum_x_squared, sum_y_squared
      real   mean_x, mean_y, numerator, denominator

    ! Inicializando as somas e contadores
      sum_x = 0.0
      sum_y = 0.0
      sum_xy = 0.0
      sum_x_squared = 0.0
      sum_y_squared = 0.0

    ! Calculando as somas necessárias
      do i = 1, n
          sum_x = sum_x + x(i)
          sum_y = sum_y + y(i)
          sum_xy = sum_xy + x(i) * y(i)
          sum_x_squared = sum_x_squared + x(i) ** 2
          sum_y_squared = sum_y_squared + y(i) ** 2
      end do

    ! Calculando as médias
      mean_x = sum_x / real(n)
      mean_y = sum_y / real(n)

    ! Calculando o numerador e o denominador do coeficiente de correlação de Pearson
      numerator = n * sum_xy - sum_x * sum_y
      denominator = sqrt((n * sum_x_squared - sum_x ** 2) * 
     * (n * sum_y_squared - sum_y ** 2))

    ! Calculando o coeficiente de correlação de Pearson
      if (denominator /= 0.0) then
          correlation = numerator / denominator
      else
          correlation = 0.0 ! Evita divisão por zero
      endif
      end 

      subroutine escreveplanilha (n, ngraf, ysave, smooth_y,y,ym,limes,
     *           vies_mensal)
      include 'paramrede.dim'
      dimension smooth_y(nmd), ysave(nmd),y(nmd),ym(nmd),vies_mensal(12)
      integer*4 n, ngraf
      integer*2 limes(nmd)
      character*20 A1, A2, A3,A4, A5
      
      if(n.gt.0)write(33,*)'OBS;PREV;SUAVE;MEDIA;RVIES'
      do i = 1, n
           WRITE(A1,'(F20.8)')ysave(i)
           WRITE(A2,'(F20.8)')y(i)
           WRITE(A3,'(F20.8)')smooth_y(i)
           WRITE(A4,'(F20.8)')Ym(i) 
           if (vies_mensal(limes(i)).eq.(-1))vies_mensal(limes(i))=0   ! multiplicativo
           WRITE(A5,'(F20.8)')smooth_y(i)/(1+vies_mensal(limes(i)))    ! multiplicativo
           CALL SUBVIRG(A1)
           CALL SUBVIRG(A2)
           CALL SUBVIRG(A3) 
           CALL SUBVIRG(A4)
           CALL SUBVIRG(A5)
           write(33,*)A1,';',A2,
     x     ';',A3,';',A4,';',A5
      end do
      close(33)
      write(4,*)'OBS;PREV;SUAVE;MEDIA;RVIES'
      do i = n+1, n+ngraf
           WRITE(A1,'(F20.8)')ysave(i)
           WRITE(A2,'(F20.8)')y(i)
           WRITE(A3,'(F20.8)')smooth_y(i) 
           WRITE(A4,'(F20.8)')Ym(i)
           if (vies_mensal(limes(i)).eq.(-1))vies_mensal(limes(i))=0   ! multiplicativo
           WRITE(A5,'(F20.8)')smooth_y(i)/(1+vies_mensal(limes(i)))    ! multiplicativo
           CALL SUBVIRG(A1)
           CALL SUBVIRG(A2)
           CALL SUBVIRG(A3)
           CALL SUBVIRG(A4)
           CALL SUBVIRG(A5)
           write(4,*)A1,';',A2,
     x     ';',A3,';',A4,';',A5
           write(13,*)ysave(i),y(i),smooth_y(i),Ym(i),limes(i)
      end do
      close(4)
      end
      
C--- ESCO --------------------------------------------------------------
      SUBROUTINE ESCO (NSER,A,IND,XAVE,N,JESCO,IESCO)
C     FUNCAO: ORDENACAO DO VETOR "A" DE COMPRIMENTO "NSER".
C-----------------------------------------------------------------------
C
      DIMENSION          A(NSER)
      INTEGER*2          IND(NSER)
      DO 01 I = 1,NSER
         IND(I) = I
   01 CONTINUE
      L      = NSER/2+1
      M      = NSER
      NL     = NSER-N
   02 IF (L .EQ. 01) GO TO 03
      L      = L-1
      IR     = IND(L)
      XK     = A(IR)*XAVE
      GO TO 04
   03 IR     = IND(M)
      XK     = A(IR)*XAVE
      IND(M) = IND(1)
      M      = M-1
      JESCO  = IR
      IF (M .EQ.  1) IND(1) = IR
      IF (M .EQ. NL) JESCO  = IND(M+1)
      IF (M .EQ. NL) IESCO  = IND(M+2)
      IF (M .EQ. NL .OR. M .EQ. 1) RETURN
   04 J      = L
   05 I      = J
      J      = 2*J
      IF (J-M) 10,15,20
   10 A1     = A(IND(J))*XAVE
      A2     = A(IND(J+1))*XAVE
      IF (A1 .LT. A2) J = J+1
   15 A3     = A(IND(J))*XAVE
      IF (XK .GE. A3) GO TO 20
      IND(I) = IND(J)
      GO TO 05
   20 IND(I) = IR
      GO TO 02
      END

      subroutine NashSutcliffe(observed, simulated, n, nash)
      implicit none
      integer*4 n
      real observed(n), simulated(n)
      real  nash
      real  sum_observed, mean_observed, numerator, denominator
      integer  i

    ! Calculando a média das observações
      sum_observed = 0.0
      do i = 1, n
          sum_observed = sum_observed + observed(i)
      end do
      mean_observed = sum_observed / real(n)

    ! Calculando o numerador e o denominador do coeficiente de Nash-Sutcliffe
      numerator = 0.0
      denominator = 0.0
      do i = 1, n
          numerator = numerator + (observed(i) - simulated(i)) ** 2
          denominator = denominator + (observed(i) - mean_observed) ** 2
      end do

    ! Calculando o coeficiente de Nash-Sutcliffe
      if (denominator /= 0.0) then
        nash = 1.0 - numerator / denominator
      else
        nash = 0.0 ! Evita divisão por zero
      endif
      end 
      
      subroutine desvpad (n, ysave, y, mediaa, desv,emq)
      dimension ysave(n), y(n), e(n)
      real L95, mediaa,emq
      
        ! Calculando o erro     
          do i = 1, n
              e(i)=ysave(i)-y(i)
          end do
          
  ! Calculando a média dos erros
          
          soma = 0.0
          somaa = 0.0
          emq = 0.0
          do i = 1, n
              soma = soma + e(i)
              somaa = somaa + abs(e(i))
              emq = emq + e(i)**2
          end do
          media = soma / real(n)
          mediaa = somaa/real(n)
          emq = emq/real(n)
    
    ! Calculando a soma dos quadrados das diferenças
          soma = 0.0
          do i = 1, n
              soma = soma + (e(i) - media)**2
          end do
    
    ! Calculando o desvio padrão
         desv = sqrt(soma / real(n))
 
      end
      
      SUBROUTINE Calcula_EP(y, y_hat, n, EP)
      INTEGER  n
      REAL  y(n), y_hat(n)
      REAL EP
      INTEGER  i
      REAL  soma

      soma = 0.0

      ! Calculando a soma dos quadrados das diferenças
      DO i = 1, n
          soma = soma + (y(i) - y_hat(i))**2
      END DO

      ! Calculando o Erro Padrão de Predição
      EP = SQRT(soma / n)

      END
      
      SUBROUTINE Calcula_Tendencia(y, y_hat, n, tendencia, 
     * y_medio, x_medio)
      INTEGER  n
      REAL  y(n), y_hat(n)
      REAL  tendencia
      INTEGER  i
      REAL  soma_x, soma_y, soma_xy, soma_x2
      REAL  x_medio, y_medio

      soma_x = 0.0
      soma_y = 0.0
      soma_xy = 0.0
      soma_x2 = 0.0

    ! Calculando somatórias necessárias para a tendência linear
      DO i = 1, n
        soma_x = soma_x + y_hat(i)
        soma_y = soma_y + y(i)
        soma_xy = soma_xy + y_hat(i) * y(i)
        soma_x2 = soma_x2 + y_hat(i) ** 2
      END DO

    ! Calculando as médias de x e y
       x_medio = soma_x / REAL(n)
       y_medio = soma_y / REAL(n)

    ! Calculando o coeficiente angular da reta de tendência
      tendencia = (soma_xy - n * x_medio * y_medio) / 
     * (soma_x2 - n * x_medio ** 2)

      END 
      subroutine ErroPercentual(yobs, yprev, n, media_erro)
      
      INTEGER n
      REAL  yobs(n), yprev(n), erro_percentual(n)
      REAL  soma_erro, media_erro
      INTEGER i, count

      ! Inicialização das variáveis
      soma_erro = 0.0
      count = 0

      ! Cálculo do erro percentual
      DO i = 1, n
         IF (yobs(i) /= 0.0) THEN
            erro_percentual(i) = ABS((yobs(i) - yprev(i)) / yobs(i))
     *                          * 100.0
            soma_erro = soma_erro + erro_percentual(i)
            count = count + 1
         END IF
      END DO

      ! Cálculo da média dos erros percentuais
      IF (count > 0) THEN
         media_erro = soma_erro / count
      ELSE
         media_erro = 99
      END IF

      END
      
      SUBROUTINE EmbaralharVetor(vetor, tamanho, index)
      include 'paramrede.dim'
      INTEGER tamanho      
      REAL vetor(tamanho)
      dimension index(nmm)
      INTEGER i, j
      REAL  temp, rand_val

        DO i = tamanho, 2, -1
           CALL RANDOM_NUMBER(rand_val)
           j = INT(rand_val * i) + 1

           ! Troca os elementos vetor(i) e vetor(j)
           temp_val = vetor(i)
           vetor(i) = vetor(j)
           vetor(j) = temp_val

           ! Troca os elementos index(i) e index(j)
           temp_idx = index(i)
           index(i) = index(j)
           index(j) = temp_idx
        END DO
       end        
      
      Subroutine CALC_DP (n, y_obs, y_prev, limes,desvpad)
      dimension Y_OBS(n), Y_PREV(n), erro(n)
      dimension MEDIAS(12), DESVPAD(12)
      INTEGER*2 limes(n), I, MES
      INTEGER*4 N,CONTAGEM(12)
      
      nmeses = 12
      
C     Inicializar arrays
      DO 20 MES = 1, NMESES
          MEDIAS(MES) = 0.0
          CONTAGEM(MES) = 0
20    CONTINUE
      
C     Calcular médias por mês
      DO 30 I = 1, N
          MES = INT(LIMES(I))
          ERRO(I) = (Y_PREV(I)-Y_OBS(I))
          IF (MES.GE.1 .AND. MES.LE.12) THEN
              MEDIAS(MES) = MEDIAS(MES)+ ERRO(I)
              CONTAGEM(MES) = CONTAGEM(MES) + 1
          ENDIF
30    CONTINUE
      
      DO 40 MES = 1, NMESES
          IF (CONTAGEM(MES).GT.0) THEN
              MEDIAS(MES) = MEDIAS(MES) / CONTAGEM(MES)
          ENDIF
40    CONTINUE
      
C     Calcular desvios padrão por mês
      DO 50 MES = 1, NMESES
          DESVPAD(MES) = 0.0
50    CONTINUE
      
      DO 60 I = 1, N
          MES = INT(LIMES(I))
          IF (MES.GE.1 .AND. MES.LE.12 .AND. CONTAGEM(MES).GT.0) THEN
              DESVPAD(MES) = DESVPAD(MES) + 
     &                       (ERRO(I) - MEDIAS(MES))**2
          ENDIF
60    CONTINUE
      
      DO 70 MES = 1, NMESES
          IF (CONTAGEM(MES).GT.1) THEN
              DESVPAD(MES) = SQRT(DESVPAD(MES) / (CONTAGEM(MES)-1))
          ELSE
              DESVPAD(MES) = 0.0
          ENDIF
70    CONTINUE

      END        

      SUBROUTINE CALCULA_LAG(OBS,PREV,N,MELHOR_LAG,LAG_MAX,MELHOR_ACUR)
      INTEGER*4 N
      INTEGER LAG_MAX, MELHOR_LAG, L, T, ACERTOS, TOTAL
      REAL  MELHOR_ACUR, ACUR, DIR_OBS, DIR_PREV
      DIMENSION OBS(N), PREV(N)

      MELHOR_ACUR = -1.0
      MELHOR_LAG = 0

      DO L = 0, LAG_MAX
         ACERTOS = 0
         TOTAL = 0

         DO T = 2 , N-L
            DIR_OBS = OBS(T) - OBS(T-1)
            DIR_PREV = PREV(T+L) - PREV(T+L-1)

            IF ((DIR_OBS * DIR_PREV) .GT. 0.0) THEN
               ACERTOS = ACERTOS + 1
            END IF
            TOTAL = TOTAL + 1
         END DO

         IF (TOTAL .GT. 0) THEN
            ACUR = 100.0 * ACERTOS / TOTAL
            IF (ACUR .GT. MELHOR_ACUR) THEN
               MELHOR_ACUR = ACUR
               MELHOR_LAG = L
            END IF
         END IF
      END DO

      RETURN
      END
      
      SUBROUTINE CALC_VIES_MENSAL(PREV, OBS, MES, N, VIES_MENSAL)
      
C
C     CÁLCULO DO VIÉS MÉDIO PARA CADA MÊS (1 A 12)
C
      REAL PREV(N), OBS(N)
      INTEGER*2 MES(N)
      REAL VIES_MENSAL(12)
      REAL SOMA(12)
      INTEGER CONT(12)
      INTEGER I, M

C     INICIALIZAÇÃO DOS VETORES SOMA E CONTAGEM
      DO 5 M = 1, 12
         SOMA(M) = 0.0
         CONT(M) = 0
         VIES_MENSAL(M) = 0.0
 5    CONTINUE

C     ACUMULA ERROS POR MÊS
      DO 10 I = 1, N
         M = MES(I)
         IF (M .GE. 1 .AND. M .LE. 12) THEN
            SOMA(M) = SOMA(M) + (PREV(I) - OBS(I))
            CONT(M) = CONT(M) + 1
         ENDIF
 10   CONTINUE

C     CALCULA O VIÉS MÉDIO POR MÊS
      DO 20 M = 1, 12
         IF (CONT(M) .GT. 0) THEN
            VIES_MENSAL(M) = SOMA(M) / FLOAT(CONT(M))
         ELSE
            VIES_MENSAL(M) = 0.0
         ENDIF
 20   CONTINUE

      RETURN
      END
      SUBROUTINE KENDALLTAU(X, Y, N, TAU, PROB, IER)
C
C     CORREÇÃO: Fórmula do Tau de Kendall ajustada para evitar |τ| > 1

      INTEGER N, IER
      DIMENSION X(N), Y(N)
      INTEGER I, J, CONCORDANT, DISCORDANT, TI, TJ
      real*8 VAR, Z, TOTAL_PAIRS
      real*8 TAU, PROB
C
C     Inicializa contadores
      CONCORDANT = 0
      DISCORDANT = 0
      TI = 0
      TJ = 0
      IER = 0
C
C     Verifica tamanho da amostra
      IF (N .LT. 2) THEN
          IER = 1  ! Erro: N insuficiente
          RETURN
      END IF
C
C     Conta pares concordantes, discordantes e empates
      DO 100 I = 1, N-1
          DO 200 J = I+1, N
              IF (X(I) .LT. X(J) .AND. Y(I) .LT. Y(J)) THEN
                  CONCORDANT = CONCORDANT + 1
              ELSE IF (X(I) .GT. X(J) .AND. Y(I) .GT. Y(J)) THEN
                  CONCORDANT = CONCORDANT + 1
              ELSE IF (X(I) .LT. X(J) .AND. Y(I) .GT. Y(J)) THEN
                  DISCORDANT = DISCORDANT + 1
              ELSE IF (X(I) .GT. X(J) .AND. Y(I) .LT. Y(J)) THEN
                  DISCORDANT = DISCORDANT + 1
              ELSE
                  IF (X(I) .EQ. X(J)) TI = TI + 1  ! Empate em X
                  IF (Y(I) .EQ. Y(J)) TJ = TJ + 1  ! Empate em Y
              END IF
200       CONTINUE
100   CONTINUE
C
C     Fórmula Tau-b correta (equivalente ao Python)
      IF (CONCORDANT + DISCORDANT + TI .GT. 0 .AND.
     *    CONCORDANT + DISCORDANT + TJ .GT. 0) THEN
          TAU = DBLE(CONCORDANT - DISCORDANT) / 
     *          SQRT(DBLE(CONCORDANT + DISCORDANT + TI) *
     *               DBLE(CONCORDANT + DISCORDANT + TJ))
      ELSE
          TAU = 0.0
          IER = 2
      END IF
C
C     Cálculo do valor-p (aproximação normal para N grande)
      IF (N .GT. 10) THEN
          VAR = (4.0D0 * N + 10.0D0) / (9.0D0 * N * (N - 1.0D0))
          Z = TAU / SQRT(VAR)
          PROB = ERFC(ABS(Z) / SQRT(2.0D0))  ! Função erro complementar
      ELSE
          PROB = 1.0D0  ! Para N pequeno, use tabelas exatas
      END IF
C
      RETURN
      END
      
      SUBROUTINE CALC_VIES_MENSAL_MULT(PREV, OBS, MES, N, VIES_MENSAL)
      
C
C     CÁLCULO DO VIÉS MÉDIO MULTIPLICATIVO PARA CADA MÊS (1 A 12)
C     VIÉS MULTIPLICATIVO = (PREV/OBS) - 1
C
      REAL PREV(N), OBS(N)
      INTEGER*2 MES(N)
      REAL VIES_MENSAL(12)
      REAL SOMA(12)
      INTEGER CONT(12)
      INTEGER I, M

C     INICIALIZAÇÃO DOS VETORES SOMA E CONTAGEM
      DO 5 M = 1, 12
         SOMA(M) = 0.0
         CONT(M) = 0
         VIES_MENSAL(M) = 0.0
 5    CONTINUE

C     ACUMULA RATIOS POR MÊS (PREV/OBS)
      DO 10 I = 1, N
         M = MES(I)
         IF (M .GE. 1 .AND. M .LE. 12 .AND. OBS(I) .NE. 0.0) THEN
            SOMA(M) = SOMA(M) + (PREV(I) / OBS(I))
            CONT(M) = CONT(M) + 1
         ENDIF
 10   CONTINUE

C     CALCULA O VIÉS MULTIPLICATIVO MÉDIO POR MÊS
      DO 20 M = 1, 12
         IF (CONT(M) .GT. 0) THEN
            VIES_MENSAL(M) = (SOMA(M) / FLOAT(CONT(M))) - 1.0
         ELSE
            VIES_MENSAL(M) = 0.0
         ENDIF
 20   CONTINUE

      RETURN
      END      